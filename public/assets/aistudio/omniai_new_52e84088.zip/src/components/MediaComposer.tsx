import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ImagePlus, Loader2, Send, Wand2, X, Film } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { enhancePrompt } from "@/lib/ai.functions";

export type MediaRef = { url: string; mediaType: string; filename: string };
export const MEDIA_ACCEPT = "image/*,video/*";
export const MAX_FILES = 8;
export const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
export const MAX_VIDEO_BYTES = 20 * 1024 * 1024;

const readAsDataUrl = (file: File) => new Promise<string>((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(String(r.result)); r.onerror = () => reject(r.error); r.readAsDataURL(file); });

/** Prompt enhancer shared by every prompt box. */
export function EnhanceButton({ value, onChange, studio, disabled }: { value: string; onChange: (v: string) => void; studio: string; disabled?: boolean | undefined }) {
  const enhance = useServerFn(enhancePrompt); const [busy, setBusy] = useState(false);
  return <Button type="button" variant="outline" size="sm" disabled={disabled || busy || !value.trim()} title="Enhance prompt" onClick={async () => {
    setBusy(true);
    try { const r = await enhance({ data: { prompt: value, studio } }); if (r.prompt) onChange(r.prompt); } catch (e) { toast.error(e instanceof Error ? e.message : "Couldn't enhance prompt."); } finally { setBusy(false); }
  }}>{busy ? <Loader2 className="animate-spin" /> : <Wand2 />}Enhance</Button>;
}

export function MediaComposer({ placeholder, studio, disabled, onSubmit }: { placeholder: string; studio: string; disabled?: boolean; onSubmit: (prompt: string, refs: MediaRef[]) => void }) {
  const [prompt, setPrompt] = useState(""); const [refs, setRefs] = useState<MediaRef[]>([]);
  const input = useRef<HTMLInputElement>(null);
  async function add(files: FileList | null) {
    if (!files) return;
    const next: MediaRef[] = [];
    for (const f of Array.from(files)) {
      const video = f.type.startsWith("video/");
      if (!video && !f.type.startsWith("image/")) { toast.error(`${f.name} isn't an image or video.`); continue; }
      if (f.size > (video ? MAX_VIDEO_BYTES : MAX_IMAGE_BYTES)) { toast.error(`${f.name} is too large (max ${video ? 20 : 10} MB).`); continue; }
      next.push({ url: await readAsDataUrl(f), mediaType: f.type, filename: f.name });
    }
    setRefs((all) => { const merged = [...all, ...next]; if (merged.length > MAX_FILES) toast.error(`Up to ${MAX_FILES} files.`); return merged.slice(0, MAX_FILES); });
  }
  return <form className="border-t p-4" onSubmit={(e) => { e.preventDefault(); if (!prompt.trim() || disabled) return; onSubmit(prompt, refs); setPrompt(""); setRefs([]); }}>
    <div className="holo mx-auto max-w-3xl space-y-2 p-2" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); void add(e.dataTransfer.files); }}>
      {refs.length > 0 && <div className="flex flex-wrap gap-2 px-1 pt-1">{refs.map((r, i) => <div key={i} className="group relative size-16 overflow-hidden rounded-md border border-primary/30">
        {r.mediaType.startsWith("video/") ? <><video src={r.url} muted className="size-full object-cover" /><Film className="absolute bottom-1 left-1 size-3 text-primary" /></> : <img src={r.url} alt={r.filename} className="size-full object-cover" />}
        <button type="button" aria-label={`Remove ${r.filename}`} onClick={() => setRefs((all) => all.filter((_, j) => j !== i))} className="absolute right-0.5 top-0.5 rounded-full bg-background/80 p-0.5"><X className="size-3" /></button>
      </div>)}</div>}
      <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder={placeholder} rows={2} aria-label="Prompt"
        onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); e.currentTarget.form?.requestSubmit(); } }}
        className="w-full resize-none bg-transparent px-3 py-2 outline-none" />
      <div className="flex flex-wrap items-center gap-2">
        <input ref={input} type="file" accept={MEDIA_ACCEPT} multiple hidden onChange={(e) => { void add(e.target.files); e.target.value = ""; }} />
        <Button type="button" variant="outline" size="sm" onClick={() => input.current?.click()}><ImagePlus />Images / videos</Button>
        <EnhanceButton value={prompt} onChange={setPrompt} studio={studio} disabled={disabled} />
        <Button className="ml-auto" disabled={disabled || !prompt.trim()}>Generate <Send /></Button>
      </div>
    </div>
  </form>;
}
