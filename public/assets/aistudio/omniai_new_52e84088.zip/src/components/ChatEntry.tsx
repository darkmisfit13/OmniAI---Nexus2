import { useEffect, useRef } from "react";
import { useNavigate, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { listThreads, newThread } from "@/lib/private.functions";
import { useAccount } from "@/components/AccountProvider";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
export function ChatEntry() {
  const { user, loading } = useAccount(); const once = useRef(false); const list = useServerFn(listThreads), create = useServerFn(newThread), navigate = useNavigate();
  useEffect(() => { if (!user || once.current) return; once.current = true; void (async () => { const all = await list(); const thread = all[0] ?? await create(); await navigate({ to: "/chat/$threadId", params: { threadId: thread.id } }); })().catch((e) => { toast.error(e.message); once.current = false; }); }, [user, list, create, navigate]);
  return <div className="grid h-full place-items-center">{user || loading ? <p>Opening conversations…</p> : <Button asChild><Link to="/auth">Sign in to chat</Link></Button>}</div>;
}