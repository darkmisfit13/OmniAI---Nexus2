import { Component, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { ClientOnly } from "@tanstack/react-router";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { AdditiveBlending, Color, Group, ShaderMaterial, Vector2, type WebGLRenderer } from "three";
import { useWorkspaceState } from "./WorkspaceStateProvider";
import { orbDynamics } from "@/lib/orb-lifecycle";
import { Button } from "@/components/ui/button";
import { Play, Pause } from "lucide-react";
import { orbMotionPaused } from "@/lib/orb-motion";

// Raw 3D gradient Perlin noise, shared by the vertex and fragment stages.
const noiseGLSL = /* glsl */ `
vec3 hash3(vec3 p) {
  p = vec3(dot(p, vec3(127.1,311.7,74.7)), dot(p,vec3(269.5,183.3,246.1)), dot(p,vec3(113.5,271.9,124.6)));
  return -1.0 + 2.0 * fract(sin(p) * 43758.5453123);
}
float noise3(vec3 p) {
  vec3 i=floor(p), f=fract(p), u=f*f*f*(f*(f*6.0-15.0)+10.0);
  return mix(mix(mix(dot(hash3(i),f),dot(hash3(i+vec3(1,0,0)),f-vec3(1,0,0)),u.x),
    mix(dot(hash3(i+vec3(0,1,0)),f-vec3(0,1,0)),dot(hash3(i+vec3(1,1,0)),f-vec3(1,1,0)),u.x),u.y),
    mix(mix(dot(hash3(i+vec3(0,0,1)),f-vec3(0,0,1)),dot(hash3(i+vec3(1,0,1)),f-vec3(1,0,1)),u.x),
    mix(dot(hash3(i+vec3(0,1,1)),f-vec3(0,1,1)),dot(hash3(i+vec3(1,1,1)),f-vec3(1,1,1)),u.x),u.y),u.z);
}
float fbm(vec3 p) { return noise3(p)*0.57+noise3(p*2.03+3.1)*0.28+noise3(p*4.07+7.4)*0.15; }
`;

const vertexShader = /* glsl */ `
uniform float uTime, uTurbulence, uPulse, uHover;
uniform vec2 uPointer;
varying vec3 vPosition, vNormal, vView;
${noiseGLSL}
void main() {
  vec3 n=normalize(position);
  float flow=fbm(n*3.4+vec3(uTime*0.16,-uTime*0.21,uTime*0.09));
  vec3 pull=vec3(uPointer*0.8,0.75);
  float attraction=exp(-length(n.xy-uPointer*0.7)*3.0)*uHover;
  vec3 p=position*(1.0+flow*uTurbulence*0.28+sin(uTime*uPulse)*0.018);
  p+=pull*attraction*0.18;
  p.xy+=vec2(-n.y,n.x)*flow*uHover*0.13;
  vPosition=p; vNormal=normalize(normalMatrix*n);
  vec4 view=modelViewMatrix*vec4(p,1.0); vView=-view.xyz;
  gl_Position=projectionMatrix*view;
}`;

const fragmentShader = /* glsl */ `
uniform float uTime, uTurbulence, uPulse, uHover;
uniform vec2 uPointer;
uniform vec3 uCyan, uViolet, uTeal;
varying vec3 vPosition, vNormal, vView;
${noiseGLSL}
void main() {
  vec3 p=normalize(vPosition);
  vec3 q=p*3.1+vec3(uTime*0.13,-uTime*0.18,uTime*0.09);
  q.xy+=uPointer*uHover*0.32;
  float n=fbm(q+fbm(q+2.8)*(1.4+uTurbulence));
  float ribbon=pow(1.0-abs(sin(p.y*10.5+p.x*3.0+n*8.0-uTime*0.75)),10.0);
  float fine=pow(1.0-abs(sin(p.y*22.0-n*13.0+uTime*0.4)),22.0);
  float facing=max(dot(normalize(vNormal),normalize(vView)),0.0);
  float rim=pow(1.0-facing,2.7);
  float core=pow(facing,7.0)*(0.44+0.13*sin(uTime*uPulse));
  float tint=clamp(n*2.2+p.x*0.5+0.45,0.0,1.0);
  vec3 energy=mix(uTeal,uCyan,tint);
  energy=mix(energy,uViolet,smoothstep(0.15,0.7,p.x+n)*0.8);
  vec3 col=energy*(0.075+ribbon*1.6+fine*0.4+rim*0.75);
  col+=uCyan*core+mix(uCyan,uViolet,0.35)*pow(facing,24.0)*0.55;
  gl_FragColor=vec4(col,0.68+ribbon*0.25);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;

const particleVertex = /* glsl */ `
uniform float uTime, uBurst, uHover;
uniform vec2 uPointer;
attribute float aSeed;
varying float vSeed;
void main() {
  vSeed=aSeed;
  float surge=uBurst*(0.5+0.5*sin(uTime*1.6+aSeed*6.28));
  vec3 p=position*(1.0+surge*0.45);
  p.xy+=uPointer*uHover*0.09*sin(aSeed*14.0);
  p+=normalize(position)*sin(uTime*0.8+aSeed*20.0)*0.025;
  vec4 view=modelViewMatrix*vec4(p,1.0);
  gl_Position=projectionMatrix*view;
  gl_PointSize=(1.2+aSeed*1.6)*(3.8/-view.z);
}`;
const particleFragment = /* glsl */ `
uniform vec3 uCyan, uViolet, uTeal;
varying float vSeed;
void main() {
  float d=length(gl_PointCoord-0.5);
  if(d>0.5) discard;
  vec3 c=mix(uTeal,uCyan,vSeed); c=mix(c,uViolet,step(0.78,vSeed)*0.7);
  gl_FragColor=vec4(c,(1.0-smoothstep(0.05,0.5,d))*0.85);
  #include <colorspace_fragment>
}`;

function VectorFallback() {
  return <svg viewBox="0 0 120 120" role="img" aria-label="OmniAI identity" className="h-full w-full text-primary" fill="none">
    <circle cx="60" cy="60" r="30" stroke="currentColor" strokeWidth="1.5" />
    <path d="M22 60 60 22 98 60 60 98Z" stroke="currentColor" strokeWidth="1" />
    <path d="m47 60 13-13 13 13-13 13Z" fill="currentColor" />
  </svg>;
}

class OrbErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  override state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  override render() { return this.state.failed ? <VectorFallback /> : this.props.children; }
}

function ContextGuard({ onFailure }: { onFailure: () => void }) {
  const { gl } = useThree();
  useEffect(() => {
    const canvas = gl.domElement;
    const lost = (event: Event) => { event.preventDefault(); onFailure(); };
    canvas.addEventListener("webglcontextlost", lost);
    return () => canvas.removeEventListener("webglcontextlost", lost);
  }, [gl, onFailure]);
  return null;
}

function Plasma({ host, reduced }: { host: HTMLDivElement | null; reduced: boolean }) {
  const { phase } = useWorkspaceState();
  const group = useRef<Group>(null);
  const surface = useRef<ShaderMaterial>(null);
  const dust = useRef<ShaderMaterial>(null);
  const motion = useRef({ ...orbDynamics.idle });
  const targetPointer = useRef(new Vector2());
  const pointer = useRef(new Vector2());
  const hover = useRef(0), targetHover = useRef(0);
  const uniforms = useMemo(() => ({
    uTime: { value: 0 }, uTurbulence: { value: 0.14 }, uPulse: { value: 1.2 },
    uHover: { value: 0 }, uBurst: { value: 0 }, uPointer: { value: new Vector2() },
    uCyan: { value: new Color() }, uViolet: { value: new Color() }, uTeal: { value: new Color() },
  }), []);
  const particles = useMemo(() => {
    const count=720, positions=new Float32Array(count*3), seeds=new Float32Array(count);
    for(let i=0;i<count;i++) {
      const y=1-2*(i+0.5)/count, radius=Math.sqrt(1-y*y), angle=i*2.399963229728653;
      const shell=1.08+0.17*(0.5+0.5*Math.sin(i*18.31));
      positions.set([Math.cos(angle)*radius*shell,y*shell,Math.sin(angle)*radius*shell],i*3);
      seeds[i]=(i*0.61803398875)%1;
    }
    return { positions,seeds };
  }, []);
  useEffect(() => {
    if (!host) return;
    const style=getComputedStyle(host);
    // sRGB renderer colors live in CSS tokens, not hardcoded in the scene.
    uniforms.uCyan.value.set(style.getPropertyValue("--orb-cyan").trim());
    uniforms.uViolet.value.set(style.getPropertyValue("--orb-violet").trim());
    uniforms.uTeal.value.set(style.getPropertyValue("--orb-teal").trim());
    const move=(event: PointerEvent) => {
      const rect=host.getBoundingClientRect();
      targetPointer.current.set((event.clientX-rect.left)/Math.max(rect.width,1)*2-1,-((event.clientY-rect.top)/Math.max(rect.height,1)*2-1));
      targetHover.current=event.buttons ? 1.7 : 1;
    };
    const leave=() => { targetPointer.current.set(0,0); targetHover.current=0; };
    const down=(e: PointerEvent) => { if (e.target instanceof Element && e.target.closest("button")) return; host.setPointerCapture(e.pointerId); move(e); };
    const up=(e: PointerEvent) => { if(host.hasPointerCapture(e.pointerId)) host.releasePointerCapture(e.pointerId); targetHover.current=1; };
    host.addEventListener("pointermove",move); host.addEventListener("pointerleave",leave);
    host.addEventListener("pointerdown",down); host.addEventListener("pointerup",up); host.addEventListener("pointercancel",leave);
    return () => {
      host.removeEventListener("pointermove",move); host.removeEventListener("pointerleave",leave);
      host.removeEventListener("pointerdown",down); host.removeEventListener("pointerup",up); host.removeEventListener("pointercancel",leave);
    };
  }, [host, uniforms]);
  useFrame((_, rawDelta) => {
    const dt=Math.min(rawDelta,0.25), blend=1-Math.exp(-3*dt), goal=orbDynamics[phase];
    motion.current.pulse+=(goal.pulse-motion.current.pulse)*blend;
    motion.current.rotation+=(goal.rotation-motion.current.rotation)*blend;
    motion.current.turbulence+=(goal.turbulence-motion.current.turbulence)*blend;
    motion.current.burst+=(goal.burst-motion.current.burst)*blend;
    pointer.current.lerp(targetPointer.current,1-Math.exp(-5*dt));
    hover.current+=(targetHover.current-hover.current)*blend;
    uniforms.uTime.value+=reduced ? 0 : dt;
    uniforms.uPulse.value=motion.current.pulse;
    uniforms.uTurbulence.value=motion.current.turbulence;
    uniforms.uBurst.value=reduced ? 0 : motion.current.burst;
    uniforms.uHover.value=reduced ? 0 : hover.current;
    uniforms.uPointer.value.copy(pointer.current);
    if(group.current && !reduced) {
      group.current.rotation.y+=dt*motion.current.rotation;
      group.current.rotation.z+=dt*motion.current.rotation*0.17;
    }
    // Both materials share stable uniform objects; updates never trigger React renders.
    if(surface.current) surface.current.uniforms=uniforms;
    if(dust.current) dust.current.uniforms=uniforms;
  });
  return <group ref={group} rotation={[0.12,0.1,-0.18]}>
    <mesh><sphereGeometry args={[1,48,32]} /><shaderMaterial ref={surface} uniforms={uniforms} vertexShader={vertexShader} fragmentShader={fragmentShader} transparent depthWrite={false} /></mesh>
    <points><bufferGeometry><bufferAttribute attach="attributes-position" args={[particles.positions,3]} /><bufferAttribute attach="attributes-aSeed" args={[particles.seeds,1]} /></bufferGeometry><shaderMaterial ref={dust} uniforms={uniforms} vertexShader={particleVertex} fragmentShader={particleFragment} transparent depthWrite={false} blending={AdditiveBlending} /></points>
  </group>;
}

function OrbCanvas() {
  const { orbEnabled } = useWorkspaceState();
  const [host,setHost]=useState<HTMLDivElement | null>(null);
  const [failed,setFailed]=useState(false), [reduced,setReduced]=useState(false);
  const [motionOverride, setMotionOverride] = useState<boolean | null>(null);
  const paused = orbMotionPaused(orbEnabled, reduced, motionOverride);
  useEffect(() => {
    const query=window.matchMedia("(prefers-reduced-motion: reduce)");
    const update=() => setReduced(query.matches); update();
    query.addEventListener("change",update); return () => query.removeEventListener("change",update);
  }, []);
  const fail=useMemo(() => () => setFailed(true), []);
  function created({ gl }: { gl: WebGLRenderer }) {
    gl.debug.onShaderError=fail;
  }
  return <div ref={setHost} className="relative h-full w-full max-w-full overflow-hidden touch-pan-y">
    {failed ? <VectorFallback /> : <Canvas frameloop="always" camera={{ position:[0,0,4.3], fov:42 }} dpr={1} gl={{ antialias:false,alpha:true,powerPreference:"high-performance" }} onCreated={created} fallback={<VectorFallback />}>
      <ContextGuard onFailure={fail} /><Plasma host={host} reduced={paused} />
    </Canvas>}
    {!failed && reduced && orbEnabled && <Button variant="ghost" size="icon-xs" className="absolute bottom-1 right-1 z-10 bg-background/60 text-primary" title={paused ? "Animate orb" : "Pause orb animation"} aria-label={paused ? "Animate orb" : "Pause orb animation"} onPointerDown={(e) => e.stopPropagation()} onClick={(e) => { e.stopPropagation(); setMotionOverride(paused); }}>{paused ? <Play /> : <Pause />}</Button>}
  </div>;
}

export type HoloOrbProps = { className?: string };

export function HoloOrb({ className="" }: HoloOrbProps) {
  const { phase }=useWorkspaceState();
  return <div data-holo-orb data-phase={phase} role="img" aria-label={`OmniAI plasma identity — ${phase}`} className={`relative h-full w-full max-w-full overflow-hidden ${className}`}>
    <OrbErrorBoundary><ClientOnly fallback={<div className="h-full w-full" />}><OrbCanvas /></ClientOnly></OrbErrorBoundary>
  </div>;
}

export default HoloOrb;