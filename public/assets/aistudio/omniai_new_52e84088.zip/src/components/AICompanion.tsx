import { useEffect, useRef, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Send, Loader2, Wand2, Scan, Code2, Layers, Sparkles } from "lucide-react";
import { askModel } from "@/lib/ai.functions";
import { useAccount } from "@/components/AccountProvider";
import { useWorkspaceState } from "@/components/WorkspaceStateProvider";
import { OmniStatusGauge } from "@/components/OmniStatusGauge";
import { EnhanceButton } from "@/components/MediaComposer";
import { MessageResponse } from "@/components/ai-elements/message";
import { Button } from "@/components/ui/button";
import { studios } from "@/lib/studios";
import { listStudioActions, getStudioAction, parseCompanionReply } from "@/lib/studio-actions";

type Turn = { role: "user" | "assistant"; content: string };

/** Site-wide AI companion: a toggleable side panel with the live orb and a conversation about the current page. */
export function AICompanion() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { user } = useAccount();
  const { setPhase } = useWorkspaceState();
  const ask = useServerFn(askModel);
  const [input, setInput] = useState(""), [busy, setBusy] = useState(false);
  const [turns, setTurns] = useState<Turn[]>([]);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => { const el = end.current?.parentElement; if (el) el.scrollTop = el.scrollHeight; }, [turns, busy]);
  const studio = studios.find((s) => path === `/studio/${s.id}`);
  const place = studio ? `the ${studio.name} studio (${studio.tagline}; tools: ${studio.tools.join(", ")}${studio.id === "video" ? "; editor tabs: Basic, Speed, Adjust, Filters, Cutout, Audio, Animation, Text; timeline buttons: Split, Duplicate, Delete; Import media, Save, Export; aspect 16:9, 9:16, 1:1" : ""})` : path === "/" ? "the OmniAI home dashboard listing every studio" : `the ${path} page`;

  const imageStudio = studio?.id === "image" || studio?.id === "design";
  const builderStudio = ["code", "website", "app-builder"].includes(studio?.id ?? "");
  const quickActions = imageStudio ? [
    { label: "Isolate object", icon: Scan, prompt: "Isolate the main object in the selected image using remove-bg. Check the canvas state first." },
    { label: "Enhance composition", icon: Wand2, prompt: "Suggest an enhanced prompt composition for the current canvas. Check its state first; do not generate until I approve." },
    { label: "Add headline", icon: Layers, prompt: "Check the current design and add a fitting headline text layer." },
  ] : builderStudio ? [
    { label: "Inspect project", icon: Code2, prompt: "Inspect the current project and summarize its state and recent compilation errors." },
    { label: "Fix errors", icon: Wand2, prompt: "Fix the current terminal errors using the builder autofix control." },
    { label: "Mobile preview", icon: Scan, prompt: "Switch the builder to its mobile preview." },
  ] : studio?.id === "video" ? [
    { label: "Inspect timeline", icon: Scan, prompt: "Inspect my timeline and summarize the current edit." },
    { label: "Arrange media", icon: Layers, prompt: "Add all imported media to the timeline in order." },
    { label: "Cinematic grade", icon: Wand2, prompt: "Inspect my timeline and apply a suitable cinematic filter to the clips." },
  ] : [{ label: "Studio suggestions", icon: Sparkles, prompt: "Suggest a creative next step for this workspace using only its available controls." }];

  async function send(message = input) {
    const text = message.trim(); if (!text || busy || !user) return;
    const next = [...turns, { role: "user" as const, content: text }];
    setTurns(next); setInput(""); setBusy(true); setPhase("classified");
    try {
      setPhase("routed");
      const actions = listStudioActions();
      const controls = actions.length ? actions.map((a) => `- ${a.name}${a.args ? ` args ${a.args}` : ""}: ${a.description}`).join("\n") : "(none on this page)";
      const system = `You are OmniAI, the living intelligence inside the OmniAI creative hub. The user is currently in ${place}. You can operate this studio directly by calling its controls:\n${controls}\n\nReply ONLY with JSON: {"reply": string (markdown, concise, warm, confident), "actions": [{"name": string, "args": object}]}. When the user asks you to do, make, edit, build or change something, DO it with actions instead of explaining steps. Actions run in order. If you need to see current state first, call a *_describe action alone and say you're checking; you will receive its result and can continue. Never invent controls not listed. Use an empty actions array for pure questions.`;
      let convo = next.map((m) => ({ role: m.role, content: m.content }));
      for (let round = 0; round < 3; round++) {
        const r = await ask({ data: { model: "openai/gpt-6-astra", messages: convo, system } });
        const { reply, actions: calls } = parseCompanionReply(r.text);
        if (reply) setTurns((t) => [...t, { role: "assistant", content: reply }]);
        if (!calls.length) break;
        setPhase("streaming");
        const results: string[] = [];
        for (const c of calls) {
          const a = getStudioAction(c.name);
          if (!a) { results.push(`${c.name}: not available here`); continue; }
          setTurns((t) => [...t, { role: "assistant", content: `⚡ Running **${c.name.replace(/_/g, " ")}**…` }]);
          try { const out = await a.run(c.args ?? {}); results.push(`${c.name}: ${typeof out === "string" ? out : "done"}`); }
          catch (e) { results.push(`${c.name} FAILED: ${(e as Error).message}`); }
        }
        setTurns((t) => [...t, { role: "assistant", content: results.map((x) => `- ${x.length > 300 ? "✓ read studio state" : x}`).join("\n") }]);
        const onlyReads = calls.every((c) => c.name.endsWith("_describe") || c.name.endsWith("_list_saved"));
        const failed = results.some((x) => x.includes("FAILED"));
        if (!onlyReads && !failed) break;
        convo = [...convo, { role: "assistant", content: r.text }, { role: "user", content: `Action results:\n${results.join("\n")}\nContinue: perform the user's request now (or explain the failure).` }];
      }
      setPhase("succeeded");
    } catch (e) {
      setTurns((t) => [...t, { role: "assistant", content: `⚠️ ${(e as Error).message}` }]); setPhase("failed");
    } finally { setBusy(false); }
  }

  return <aside aria-label="AI Director" className="director-panel flex flex-col gap-3 overflow-hidden p-4">
      <div className="flex shrink-0 items-center justify-between gap-2"><h2 className="font-display text-sm font-bold text-primary">AI DIRECTOR</h2><span className="truncate text-xs text-muted-foreground">{studio?.name ?? "OmniAI"}</span></div>
      <div className="director-core flex shrink-0 flex-col gap-2"><OmniStatusGauge /></div>
      <div role="log" aria-label="Director conversation" aria-live="polite" className="min-h-0 flex-1 overflow-y-auto pr-1 text-sm">
        {turns.length === 0 && <div className="director-turn"><span className="mb-2 block text-xs font-mono text-teal">OMNI / STANDING BY</span><p className="text-muted-foreground">{studio?.name ?? "Workspace"} connected. Ready for your next direction.</p></div>}
        {turns.map((t, i) => <div key={i} className="director-turn"><span className={`mb-2 block text-[10px] font-mono uppercase ${t.role === "user" ? "text-teal" : "text-primary"}`}>{t.role === "user" ? "You" : "Omni Director"}</span>{t.role === "user" ? <p>{t.content}</p> : <MessageResponse>{t.content}</MessageResponse>}</div>)}
        {busy && <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="size-4 animate-spin" />Thinking…</div>}
        <div ref={end} />
      </div>
      <div className="director-tools shrink-0 space-y-2 border-t pt-3"><span className="text-[10px] font-mono uppercase text-teal">{studio?.name ?? "Workspace"} · Tool belt</span><div className="grid grid-cols-2 gap-2">{quickActions.map((a) => <Button key={a.label} variant="outline" size="xs" className="bevel border-primary/20" title={`Tell AI to ${a.label.toLowerCase()}`} disabled={busy || !user} onClick={() => void send(a.prompt)}><a.icon className="size-3 shrink-0" /><span>{a.label}</span></Button>)}</div></div>
      {!user ? <Button asChild><Link to="/auth">Sign in to talk to OmniAI</Link></Button> :
        <form className="recessed shrink-0 space-y-2 p-2" onSubmit={(e) => { e.preventDefault(); void send(); }}>
          <textarea value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void send(); } }} rows={2} placeholder="Direct your next move…" aria-label="Ask OmniAI" className="w-full resize-none bg-transparent px-1 text-sm outline-none placeholder:text-muted-foreground" />
          <div className="flex items-center justify-between"><EnhanceButton value={input} onChange={setInput} studio={studio?.id ?? "chat"} disabled={busy} /><Button type="submit" size="sm" disabled={busy || !input.trim()}><Send />Send</Button></div>
        </form>}
    </aside>;
}
