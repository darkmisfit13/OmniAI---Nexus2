import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { WorkspacePhase } from "@/lib/orb-lifecycle";

const WorkspaceContext = createContext<{ phase: WorkspacePhase; setPhase: (phase: WorkspacePhase) => void; orbEnabled: boolean }>({ phase: "idle", setPhase: () => {}, orbEnabled: true });

export function WorkspaceStateProvider({ children }: { children: ReactNode }) {
  const [phase, setPhase] = useState<WorkspacePhase>("idle");
  const settings = useQuery({ queryKey: ["orb-motion"], queryFn: async () => { const r = await supabase.from("workspace_settings").select("orb_enabled").eq("id", "global").maybeSingle(); if (r.error) throw r.error; return r.data?.orb_enabled ?? true; }, staleTime: 60000, refetchOnWindowFocus: true });
  const orbEnabled = settings.data ?? true;
  const value = useMemo(() => ({ phase, setPhase, orbEnabled }), [phase, orbEnabled]);
  return <WorkspaceContext.Provider value={value}>{children}</WorkspaceContext.Provider>;
}

export const useWorkspaceState = () => useContext(WorkspaceContext);