import { createContext, useContext, useRef, useState, type ReactNode } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ShieldCheck, Loader2, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { quoteStudioCredits, confirmStudioCredits } from "@/lib/studio-credit.functions";
import type { CreditRequest } from "@/lib/studio-credit";
import { useWorkspaceState } from "./WorkspaceStateProvider";
import { useOmniWallet } from "./AccountProvider";
type Quote = Awaited<ReturnType<typeof quoteStudioCredits>>;
const Context = createContext<(request: CreditRequest) => Promise<string>>(async () => { throw new Error("Credit approval unavailable."); });
export const useCreditApproval = () => useContext(Context);
export function CreditApprovalProvider({ children }: { children: ReactNode }) {
  const quote = useServerFn(quoteStudioCredits), confirm = useServerFn(confirmStudioCredits);
  const { setPhase } = useWorkspaceState();
  const { refreshWallet } = useOmniWallet();
  const [open, setOpen] = useState(false), [pricing, setPricing] = useState<Quote | null>(null), [error, setError] = useState(""), [busy, setBusy] = useState(false), [preview, setPreview] = useState(false);
  const pending = useRef<{ resolve: (id: string) => void; reject: (e: Error) => void } | null>(null);
  function cancel() { if (busy) return; pending.current?.reject(new Error("Credit authorization cancelled; no generation started.")); pending.current = null; setOpen(false); setPhase("idle"); }
  async function request(r: CreditRequest): Promise<string> {
    if (pending.current) throw new Error("Finish the current credit approval first.");
    setPricing(null); setError(""); setPreview(false); setOpen(true);
    return new Promise<string>((resolve, reject) => {
      pending.current = { resolve, reject };
      void quote({ data: r }).then(setPricing).catch((e) => setError(e instanceof Error ? e.message : "Quote unavailable."));
    });
  }
  const remaining = pricing ? pricing.balance - pricing.amount : 0;
  return <Context.Provider value={request}>{children}<Dialog open={open} onOpenChange={(v) => { if (!v) cancel(); }}><DialogContent className="credit-glass max-h-[90dvh] overflow-y-auto sm:max-w-lg" onEscapeKeyDown={(e) => { if (busy) e.preventDefault(); }} onPointerDownOutside={(e) => { if (busy) e.preventDefault(); }}>
    <div className="flex items-center gap-3 text-primary"><ShieldCheck className="size-7" /><span className="hud-label text-primary">Secure compute release</span></div>
    <DialogTitle className="text-2xl">{pricing?.preview ? "Authorize personalized high-tier preview" : "Authorize studio processing"}</DialogTitle>
    <DialogDescription>{pricing?.preview ? "A personalized high-tier preview requires a separate processing step and a separate charge. Your standard draft remains saved if you skip." : "Review this task before credits are deducted. Closing this window cancels authorization."}</DialogDescription>
    {!pricing && !error && <div className="flex items-center gap-2 py-8 text-primary"><Loader2 className="size-5 animate-spin" />Calculating server-pinned price…</div>}
    {pricing && <><p className="text-sm text-accent">{pricing.walletName} credit wallet</p><dl className="space-y-3 border-y py-4 text-sm"><div className="flex justify-between gap-3"><dt className="text-muted-foreground">Task</dt><dd className="text-right capitalize">{pricing.lineItem}</dd></div><div className="flex justify-between"><dt className="text-muted-foreground">Pinned rate</dt><dd>{pricing.operation === "video" ? `${pricing.units}s × 8 CR/sec` : pricing.operation === "music-pair" ? "2 songs × 24 CR" : `${pricing.amount} CR × 1 task`}</dd></div><div className="flex justify-between font-semibold"><dt>Total charge</dt><dd className="text-primary">{pricing.amount} CR</dd></div></dl>
    <div className="grid grid-cols-2 gap-4 font-mono"><div><p className="text-xs text-muted-foreground">Current Balance</p><p className="mt-2 text-2xl text-primary">{pricing.balance} CR</p></div><div><p className="text-xs text-muted-foreground">Remaining Balance After Charge</p><p className={`mt-2 text-2xl ${remaining < 0 ? "text-destructive" : "text-primary"}`}>{remaining < 0 ? "Insufficient" : `${remaining} CR`}</p></div></div>
    <div className="credit-meter" aria-hidden="true"><div style={{ transform: `scaleX(${preview && pricing.balance > 0 ? Math.max(0, remaining / pricing.balance) : 1})` }} /></div>
    <div className="credit-badge flex items-center justify-center gap-2 py-4 font-display text-xl text-primary"><Zap className="size-5" />Authorize {pricing.amount} CR for this generation</div>
    {remaining < 0 && <p role="status" className="text-sm text-destructive">Your balance needs {Math.abs(remaining)} more CR. Top off using an Omni Booster Pack. No credits will be deducted.</p>}
    <Button className="h-auto min-h-12 whitespace-normal shadow-glow" disabled={busy || remaining < 0} onMouseEnter={() => setPreview(true)} onMouseLeave={() => setPreview(false)} onFocus={() => setPreview(true)} onBlur={() => setPreview(false)} onClick={async () => { if (busy) return; setBusy(true); setError(""); try { const result = await confirm({ data: { id: pricing.id } }); await refreshWallet(); setPhase("routed"); pending.current?.resolve(result.approvalId); pending.current = null; setOpen(false); } catch (e) { setError(e instanceof Error ? e.message : "Authorization failed."); } finally { setBusy(false); } }}>{busy ? <Loader2 className="animate-spin" /> : <ShieldCheck />}{busy ? "Verifying & deducting…" : pricing.operation.startsWith("music-") || pricing.preview ? "Confirm & Authorize Stream" : "Confirm & Deduct Credits"}</Button></>}
    {error && <p role="alert" className="text-sm text-destructive">{error}</p>}<Button variant="ghost" disabled={busy} onClick={cancel}>{pricing?.preview ? "Skip and Keep Standard Draft" : "Cancel"}</Button>
  </DialogContent></Dialog></Context.Provider>;
}