import { Component, useMemo, useRef, type ReactNode } from "react";
import { ClientOnly } from "@tanstack/react-router";
import { Canvas, useFrame } from "@react-three/fiber";
import { AdditiveBlending, BufferAttribute, BufferGeometry, Color, Group, type LineSegments, type Points } from "three";
import { useWorkspaceState } from "./WorkspaceStateProvider";

const COUNT = 160;
const LINK = 1.35;
const SPEED: Record<string, number> = { idle: 1, classified: 2.2, routed: 3, streaming: 4, succeeded: 1.6, failed: 0.6 };

/** Drifting 3D neural lattice: nodes wander in a volume and synapses light up between near neighbours. */
function Lattice() {
  const { phase } = useWorkspaceState();
  const group = useRef<Group>(null), pts = useRef<Points>(null), lines = useRef<LineSegments>(null);
  const speed = useRef(1);
  const { pos, vel, pGeo, lGeo, pAttr, lpAttr, lcAttr } = useMemo(() => {
    const pos = new Float32Array(COUNT * 3), vel = new Float32Array(COUNT * 3);
    for (let i = 0; i < COUNT * 3; i++) { pos[i] = (Math.random() - 0.5) * (i % 3 === 2 ? 6 : 12); vel[i] = (Math.random() - 0.5) * 0.12; }
    const pAttr = new BufferAttribute(pos, 3), lpAttr = new BufferAttribute(new Float32Array(COUNT * 12 * 6), 3), lcAttr = new BufferAttribute(new Float32Array(COUNT * 12 * 6), 3);
    const pGeo = new BufferGeometry(); pGeo.setAttribute("position", pAttr);
    const lGeo = new BufferGeometry(); lGeo.setAttribute("position", lpAttr); lGeo.setAttribute("color", lcAttr);
    return { pos, vel, pGeo, lGeo, pAttr, lpAttr, lcAttr };
  }, []);
  const cyan = useMemo(() => new Color("#00f2fe"), []), violet = useMemo(() => new Color("#7f00ff"), []);
  useFrame((state, raw) => {
    const dt = Math.min(raw, 0.05);
    speed.current += ((SPEED[phase] ?? 1) - speed.current) * (1 - Math.exp(-3 * dt));
    const s = speed.current;
    for (let i = 0; i < COUNT * 3; i++) {
      const v = vel[i]!; pos[i] = pos[i]! + v * dt * s;
      const lim = i % 3 === 2 ? 3 : 6;
      if (pos[i]! > lim || pos[i]! < -lim) vel[i] = -v;
    }
    pAttr.needsUpdate = true;
    const lp = lpAttr.array as Float32Array, lc = lcAttr.array as Float32Array; const P = (i: number) => pos[i] ?? 0;
    let n = 0; const max = lp.length / 6;
    for (let a = 0; a < COUNT && n < max; a++) for (let b = a + 1; b < COUNT && n < max; b++) {
      const dx = P(a * 3) - P(b * 3), dy = P(a * 3 + 1) - P(b * 3 + 1), dz = P(a * 3 + 2) - P(b * 3 + 2);
      const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (d > LINK) continue;
      const k = (1 - d / LINK) * Math.min(1, 0.35 + s * 0.15), c = a % 2 ? cyan : violet;
      lp.set([P(a * 3), P(a * 3 + 1), P(a * 3 + 2), P(b * 3), P(b * 3 + 1), P(b * 3 + 2)], n * 6);
      lc.set([c.r * k, c.g * k, c.b * k, c.r * k, c.g * k, c.b * k], n * 6);
      n++;
    }
    lGeo.setDrawRange(0, n * 2);
    lpAttr.needsUpdate = true; lcAttr.needsUpdate = true;
    if (group.current) {
      group.current.rotation.y += dt * 0.03 * s;
      group.current.rotation.x += (state.pointer.y * 0.15 - group.current.rotation.x) * (1 - Math.exp(-2 * dt));
      group.current.rotation.z += (-state.pointer.x * 0.08 - group.current.rotation.z) * (1 - Math.exp(-2 * dt));
    }
  });
  return <group ref={group}>
    <points ref={pts} geometry={pGeo}><pointsMaterial color="#7fe9ff" size={0.05} sizeAttenuation transparent opacity={0.85} blending={AdditiveBlending} depthWrite={false} /></points>
    <lineSegments ref={lines} geometry={lGeo}><lineBasicMaterial vertexColors transparent opacity={0.55} blending={AdditiveBlending} depthWrite={false} /></lineSegments>
  </group>;
}

class Boundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  override state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  override render() { return this.state.failed ? null : this.props.children; }
}

/** Fixed full-screen WebGL backdrop shared by every page. Purely decorative; failure renders nothing. */
export function NeuralField() {
  return <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 opacity-70">
    <ClientOnly fallback={null}><Boundary>
      <Canvas dpr={[1, 1.5]} camera={{ position: [0, 0, 7], fov: 60 }} gl={{ antialias: false, alpha: true, powerPreference: "low-power" }}>
        <fog attach="fog" args={["#000000", 5, 13]} />
        <Lattice />
      </Canvas>
    </Boundary></ClientOnly>
  </div>;
}
