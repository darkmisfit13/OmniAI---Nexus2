import { HoloOrb } from "@/components/HoloOrb";
import { useWorkspaceState } from "@/components/WorkspaceStateProvider";
const LABELS = { idle: "Idle · listening", classified: "Understanding", routed: "Thinking", streaming: "Creating · responding", succeeded: "Complete · listening", failed: "Attention required" };
export function OmniStatusGauge() {
  const { phase } = useWorkspaceState();
  const active = phase !== "idle" && phase !== "succeeded" && phase !== "failed";
  return <><div className={`recessed scanline relative aspect-square w-full shrink-0 overflow-hidden p-2 ${active ? "glow-active" : ""}`}><HoloOrb /></div><div aria-label="Omni status gauge" role="status" className="recessed shrink-0 space-y-3 p-3"><div className="flex items-center justify-between gap-2"><span className="hud-label">Core status</span><span className={`size-2 rounded-full ${phase === "failed" ? "bg-destructive" : active ? "bg-primary animate-pulse" : "bg-success"}`} /></div><div className="grid grid-cols-12 gap-1" aria-hidden>{Array.from({ length: 12 }, (_, i) => <span key={i} className={`h-2 rounded-sm ${phase === "failed" ? "bg-destructive/60" : active ? "bg-primary animate-pulse" : i < 3 ? "bg-success" : "bg-secondary"}`} />)}</div><p className="text-xs font-mono text-primary">{LABELS[phase]}</p></div></>;
}