import { OMNI_PLANS, OMNI_BOOSTERS } from '@/lib/omni-plans';
import { useOmniWallet } from '@/components/AccountProvider';
import { Button } from '@/components/ui/button';
export function OmniPlans() {
  const { wallet } = useOmniWallet();
  return <section aria-label="Omni monthly plans" className="space-y-4 border-t pt-6"><h2 className="font-display text-2xl">Omni monthly plans</h2><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{OMNI_PLANS.map(p => <article key={p.id} className="wave-glass rounded-md border p-4"><h3 className="text-lg text-primary">{p.name}</h3><p className="mt-3 text-xl">${p.monthlyUsd}<span className="text-xs text-muted-foreground">/mo</span></p><p className="mt-3 font-mono text-accent">{p.monthlyCredits.toLocaleString()} CR monthly</p><p className="my-3 text-xs text-muted-foreground">{p.pro ? 'Lyria Pro · ' : 'Base generation · '}{p.priority} priority</p><Button className="h-auto w-full whitespace-normal" variant="outline" disabled>{wallet?.plan.id === p.id ? 'Current plan' : 'Purchases not connected'}</Button></article>)}</div><div className="flex flex-wrap gap-3">{OMNI_BOOSTERS.map(name => <span key={name} className="text-xs text-muted-foreground">{name} · coming soon</span>)}</div></section>;
}
