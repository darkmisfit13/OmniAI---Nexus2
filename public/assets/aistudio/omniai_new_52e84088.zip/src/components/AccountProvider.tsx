import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { User } from "@supabase/supabase-js";
import { useRouter, Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getOmniWallet } from "@/lib/omni-wallet.functions";
import { notifyWorkstationEvent } from "@/lib/notifications.functions";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { LogOut, UserRound } from "lucide-react";

const AccountContext = createContext<{ user: User | null; loading: boolean }>({ user: null, loading: true });
const WalletContext = createContext<{ wallet: Awaited<ReturnType<typeof getOmniWallet>> | undefined; walletError: string; refreshWallet: () => Promise<void> }>({ wallet: undefined, walletError: "", refreshWallet: async () => {} });
export const useOmniWallet = () => useContext(WalletContext);
export const useAccount = () => useContext(AccountContext);
export function AccountProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const queryClient = useQueryClient();
  const readWallet = useServerFn(getOmniWallet);
  const notify = useServerFn(notifyWorkstationEvent);
  const wallet = useQuery({ queryKey: ["omni-wallet", user?.id], queryFn: () => readWallet(), enabled: !!user, refetchInterval: 15000 });
  useEffect(() => {
    let alive = true;
    const { data: subscription } = supabase.auth.onAuthStateChange((event, session) => {
      if (alive) { setUser(session?.user ?? null); setLoading(false); }
      if (event === "SIGNED_IN" && session?.user) {
        const key = `omni-notified-session:${session.user.id}`;
        if (!sessionStorage.getItem(key)) {
          sessionStorage.setItem(key, "1");
          setTimeout(() => { void notify({ data: { event: "security", key: crypto.randomUUID() } }).catch(() => {}); }, 0);
        }
      }
      if (event === "SIGNED_OUT") { for (const key of Object.keys(sessionStorage)) if (key.startsWith("omni-notified-session:")) sessionStorage.removeItem(key); }
      if (!["SIGNED_IN", "SIGNED_OUT", "USER_UPDATED"].includes(event)) return;
      void router.invalidate();
      if (event !== "SIGNED_OUT") void queryClient.invalidateQueries();
    });
    void supabase.auth.getUser().then(({ data }) => { if (alive) { setUser(data.user); setLoading(false); } });
    return () => { alive = false; subscription.subscription.unsubscribe(); };
  }, [router, queryClient, notify]);
  return <AccountContext.Provider value={{ user, loading }}><WalletContext.Provider value={{ wallet: user ? wallet.data : undefined, walletError: wallet.error?.message ?? "", refreshWallet: async () => { await queryClient.invalidateQueries({ queryKey: ["omni-wallet"] }); } }}>{children}</WalletContext.Provider></AccountContext.Provider>;
}
export function AccountControl() {
  const { user, loading } = useAccount();
  const router = useRouter();
  const queryClient = useQueryClient();
  if (loading) return <span className="text-xs text-muted-foreground">Connecting…</span>;
  if (!user) return <Button asChild variant="outline" size="sm"><Link to="/auth"><UserRound /> Sign in</Link></Button>;
  return <div className="flex gap-1 items-center"><Button asChild variant="ghost" size="sm"><Link to="/account"><UserRound />My account</Link></Button><Button variant="ghost" size="icon-sm" title="Sign out" onClick={async () => {
    await queryClient.cancelQueries(); queryClient.clear(); await supabase.auth.signOut(); await router.navigate({ to: "/auth", replace: true });
  }}><LogOut /></Button></div>;
}