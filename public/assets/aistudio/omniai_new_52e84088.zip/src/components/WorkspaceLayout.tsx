import { createContext, useContext, useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { PanelLeft, PanelRight, Sparkles, ShieldCheck } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { councilAccess } from "@/lib/council.functions";
import { Button } from "@/components/ui/button";
import { AccountControl, useAccount, useOmniWallet } from "@/components/AccountProvider";
import { AICompanion } from "@/components/AICompanion";
import { studios } from "@/lib/studios";

const LayoutContext = createContext({ directorOpen: true });
export const useWorkspaceLayout = () => useContext(LayoutContext);

export function WorkspaceLayout({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [directorOpen, setDirectorOpen] = useState(true);
  const { user } = useAccount(); const checkAccess = useServerFn(councilAccess);
  const { wallet, walletError } = useOmniWallet();
  const permission = useQuery({ queryKey: ["council-access", user?.id], queryFn: () => checkAccess(), enabled: !!user });
  if (path.startsWith("/auth") || path.startsWith("/reset-password")) return children;
  const studio = studios.find((s) => path === `/studio/${s.id}`);
  return <LayoutContext.Provider value={{ directorOpen }}>
    <div className="workspace-layout flex h-dvh min-w-0 flex-col overflow-hidden bg-background">
      <header className="workspace-toolbar flex h-16 shrink-0 items-center gap-3 border-b px-3 sm:px-4">
        <Button variant="outline" size="icon" className="bevel shrink-0" title={sidebarOpen ? "Collapse studio sidebar" : "Expand studio sidebar"} aria-label="Toggle studio sidebar" aria-expanded={sidebarOpen} aria-controls="workspace-sidebar" onClick={() => { setSidebarOpen((v) => !v); if (!sidebarOpen && window.innerWidth <= 1100) setDirectorOpen(false); }}><PanelLeft /></Button>
        <Link to="/" className="flex min-w-0 items-center gap-2 font-display text-lg font-bold text-primary"><Sparkles className="size-5 shrink-0" />OmniAI</Link>
        <span className="hidden min-w-0 truncate border-l pl-3 text-xs text-muted-foreground sm:block">{studio?.name ?? (path.startsWith("/chat") ? "Intelligence" : path.startsWith("/music-video") ? "OmniBeat Production" : "Workspace")}</span>
        {user && <Link to="/account" aria-label="Omni Global Wallet" className="ml-auto min-w-0 text-right font-mono text-xs text-primary"><span className="hidden sm:block text-muted-foreground">Omni Global Wallet</span><span className="whitespace-nowrap">{walletError ? "Unavailable" : wallet ? `${wallet.balance.toLocaleString()} CR` : "Connecting…"}</span>{!!wallet?.reserved && <span className="block text-accent">{wallet.reserved} CR reserved</span>}</Link>}
        <div className="workspace-account ml-auto flex items-center gap-1">{permission.data?.admin && <Button asChild variant="ghost" size="icon-sm" title="Council administration"><Link to="/council" aria-label="Council administration"><ShieldCheck /></Link></Button>}<AccountControl /></div>
        <Button variant="outline" size="icon" className={`bevel shrink-0 ${directorOpen ? "border-primary/60 text-primary shadow-glow" : "text-muted-foreground"}`} title={directorOpen ? "Collapse AI Director" : "Expand AI Director"} aria-label="Toggle AI Director" aria-expanded={directorOpen} aria-controls="workspace-director" onClick={() => { setDirectorOpen((v) => !v); if (!directorOpen && window.innerWidth <= 1100) setSidebarOpen(false); }}><PanelRight /></Button>
      </header>
      <div className="workspace-matrix grid min-h-0 flex-1" data-sidebar={sidebarOpen} data-director={directorOpen}>
        <div id="workspace-sidebar" className="workspace-sidebar-slot min-h-0 overflow-hidden" inert={!sidebarOpen}>
          <aside aria-label="Studio sidebar" className="flex h-full w-56 flex-col gap-4 border-r bg-card/80 p-4 backdrop-blur-md">
            <span className="text-xs font-mono uppercase text-primary">Studio directory</span>
            <nav className="min-h-0 flex-1 space-y-1 overflow-y-auto">{studios.map((s) => <Link key={s.id} to="/studio/$id" params={{ id: s.id }} className={`flex items-center gap-3 rounded-md border px-2 py-1.5 text-xs ${studio?.id === s.id ? "border-primary/50 bg-primary/10 text-primary" : "border-transparent text-muted-foreground hover:border-border hover:text-foreground"}`}><s.icon className="size-4 shrink-0" /><span className="min-w-0"><span className="block truncate font-semibold">{s.name}</span><span className="block truncate text-[10px] text-muted-foreground">{s.subLabel}</span></span></Link>)}</nav>
          </aside>
        </div>
        <div className="workspace-canvas min-h-0 min-w-0 overflow-auto" aria-label="Active studio workspace">{children}</div>
        <div id="workspace-director" className="workspace-director-slot min-h-0 overflow-hidden" inert={!directorOpen}><AICompanion key={`${path}:${studio?.id ?? "workspace"}`} /></div>
      </div>
    </div>
  </LayoutContext.Provider>;
}