import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Check, Play, Pause, Send, Download, Scissors, Share2, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { AccountControl, useOmniWallet } from "@/components/AccountProvider";
import { OmniStatusGauge } from "@/components/OmniStatusGauge";
import { EnhanceButton } from "@/components/MediaComposer";
import { MessageResponse } from "@/components/ai-elements/message";
import { useWorkspaceState } from "@/components/WorkspaceStateProvider";
import { checkVideoJob } from "@/lib/ai.functions";
import { analyzeMusicTrack, createMusicReference, createMusicVideoClip, createMusicDirection, applyMusicCorrection, stopMusicProduction } from "@/lib/music-video.functions";
import { PRODUCTION_STAGES, clipLengths, type ProductionState, type ProductionOutput } from "@/lib/music-video";
import { useCreditApproval } from "@/components/CreditApprovalProvider";
import { getPipelineEscrow, reservePipeline, extendPipeline, settlePipeline } from "@/lib/pipeline-escrow.functions";
import { escrowRemaining } from "@/lib/omni-plans";
import { renderMusicFilm } from "@/lib/music-video-render";
export function OmniBeatProduction({ projectId }: { projectId: string }) {
  const navigate = useNavigate(); const { setPhase } = useWorkspaceState();
  const authorizeCredits = useCreditApproval();
  const { wallet, refreshWallet } = useOmniWallet();
  const reserve = useServerFn(reservePipeline), extend = useServerFn(extendPipeline), settle = useServerFn(settlePipeline), readEscrow = useServerFn(getPipelineEscrow), createReference = useServerFn(createMusicReference);
  const escrow = useQuery({ queryKey: ["pipeline-escrow", projectId], queryFn: () => readEscrow({ data: { projectId } }), refetchInterval: 5000 });
  const [approvalOpen, setApprovalOpen] = useState(false);
  async function refreshCredits() { await Promise.all([escrow.refetch(), refreshWallet()]); }
  const stopProduction = useServerFn(stopMusicProduction);
  const direction = useServerFn(createMusicDirection), correction = useServerFn(applyMusicCorrection), analyze = useServerFn(analyzeMusicTrack), createClip = useServerFn(createMusicVideoClip), poll = useServerFn(checkVideoJob);
  const [state, setState] = useState<ProductionState | null>(null), [title, setTitle] = useState("Music film"), [busy, setBusy] = useState(false), [input, setInput] = useState(""), [error, setError] = useState(""), [selected, setSelected] = useState(0);
  const live = useRef<ProductionState | null>(null), pause = useRef(false), running = useRef(false);
  const writes = useRef<Promise<void>>(Promise.resolve());
  const loaded = useQuery({ queryKey: ["music-production", projectId], queryFn: async () => { const r = await supabase.from("studio_projects").select("title,state").eq("id", projectId).eq("kind", "music-production").single(); if (r.error) throw new Error("Production not found."); return r.data; } });
  useEffect(() => { if (!loaded.data) return; const s = loaded.data.state as unknown as ProductionState; live.current = s; setState(s); setTitle(loaded.data.title); pause.current = s.paused; }, [loaded.data]);
  useEffect(() => () => { pause.current = true; setPhase("idle"); }, [setPhase]);
  async function save(s: ProductionState) { const next = pause.current ? { ...s, paused: true } : s; live.current = next; setState(next); const write = writes.current.catch(() => {}).then(async () => { const r = await supabase.from("studio_projects").update({ state: JSON.parse(JSON.stringify(next)) }).eq("id", projectId); if (r.error) throw new Error("Production could not be saved."); }); writes.current = write; await write; }
  async function log(content: string, role: "user" | "assistant" = "assistant") { const s = live.current; if (s) await save({ ...s, logs: [...s.logs, { role, content }] }); }
  async function signed(path: string) { const r = await supabase.storage.from("studio-assets").createSignedUrl(path, 3600); if (r.error) throw r.error; return r.data.signedUrl; }
  async function output(projectId: string): Promise<ProductionOutput> { const r = await supabase.from("studio_projects").select("asset_path").eq("id", projectId).single(); if (r.error || !r.data.asset_path) throw new Error("Generated asset was not saved."); return { projectId, path: r.data.asset_path, url: await signed(r.data.asset_path) }; }
  async function run() {
    if (!live.current || running.current) return; running.current = true; setBusy(true); setError(""); pause.current = false; setPhase("classified");
    try {
      await save({ ...live.current, paused: false });
      while (live.current && live.current.stage < 6 && !pause.current) {
        const s: ProductionState = live.current; const stage = s.stage; await log(`Processing ${PRODUCTION_STAGES[stage]?.name} from reserved credits…`); setPhase("classified");
        if (stage === 0) { const r = await analyze({ data: { projectId } }); const current = live.current; if (current) await save({ ...current, results: { ...current.results, "0": r.text }, stage: 1 }); }
        else if (stage === 3) {
          while (live.current && live.current.images.length < s.config.variants && !pause.current) {
            const r = await createReference({ data: { projectId } });
            const asset = await output(r.projectId); const current = live.current;
            if (current) await save({ ...current, images: [...current.images, asset] });
            await refreshCredits(); setPhase("streaming");
          }
          if (!pause.current && live.current) await save({ ...live.current, stage: 4 });
        } else if (stage === 5) {
          const lengths = clipLengths(s.config.seconds);
          if (live.current && live.current.clips.length < lengths.length && !pause.current) {
            const n = live.current.clips.length, seconds = lengths[n]; if (!seconds) break;
            let pending = live.current.clips[n];
            const clipPrompt = `${s.prompt}\nVisual style: ${s.results["1"]}\nScene plan: ${s.results["4"]}\nGenerate scene ${n + 1} of ${lengths.length}, ${seconds} seconds. Original audio will be merged later.`.slice(0, 6000);
            const job = await createClip({ data: { projectId, prompt: clipPrompt, seconds } });
            pending = { ...job, seconds, prompt: clipPrompt };
            await save({ ...live.current, clips: [...live.current.clips, pending] });
            await finishPending(n);
          }
          if (!pause.current && live.current && live.current.clips.length === lengths.length && live.current.clips.every((c) => c.path)) await save({ ...live.current, stage: 6 });
        } else {
          const r = await direction({ data: { projectId } });
          if (!r.text.trim()) throw new Error("No creative output returned."); const current = live.current; if (current) await save({ ...current, results: { ...current.results, [stage]: r.text }, stage: stage + 1 });
        }
        await refreshCredits(); setPhase("streaming");
      }
      await log(pause.current ? "Paused at the next safe boundary. Completed work is retained." : "Stages are ready. Choose a merge version and render your film."); setPhase(pause.current ? "idle" : "succeeded");
    } catch (e) { const message = e instanceof Error ? e.message : "Production failed."; setError(message === "CONTINUATION_REQUIRED" ? "" : message); await refreshCredits(); if (message !== "CONTINUATION_REQUIRED") { await settle({ data: { projectId } }).catch(() => {}); await refreshCredits(); } if (live.current) await save({ ...live.current, paused: true }).catch(() => {}); pause.current = true; setPhase("failed"); }
    finally { running.current = false; setBusy(false); }
  }
  async function finishPending(index: number) {
    const pending = live.current?.clips[index]; if (!pending?.jobId || pending.path) return;
    for (let attempt = 0; attempt < 150; attempt++) { const r = await poll({ data: { id: pending.jobId } }); if (r.error || r.status === "failed") throw new Error(r.error ?? "Clip generation failed."); if (r.url && pending.projectId) { const asset = await output(pending.projectId); const current = live.current; if (current) await save({ ...current, clips: current.clips.map((c, i) => i === index ? { ...c, ...asset } : c), renderSeconds: current.renderSeconds + (pending.seconds ?? 0) }); return; } await new Promise((resolve) => setTimeout(resolve, 8000)); }
    throw new Error("Clip is still processing. Resume later to check the same job without generating again.");
  }
  async function resume() { if (running.current) return; const index = live.current?.clips.findIndex((c) => !c.path) ?? -1; if (index >= 0) { setBusy(true); running.current = true; try { await finishPending(index); } catch (e) { setError(e instanceof Error ? e.message : "Clip recovery failed."); return; } finally { setBusy(false); running.current = false; } } await run(); }
  async function stop() { pause.current = true; try { await stopProduction({ data: { projectId } }); if (live.current) await save({ ...live.current, paused: true }); await refreshCredits(); } catch (e) { setError(e instanceof Error ? e.message : "Stop could not be saved."); } }
  async function correct() { if (!input.trim() || busy || !live.current) return; const text = input.trim().slice(0, 4000); setBusy(true); try { const approvalId = await authorizeCredits({ operation: "correction", target: "music-video", projectId, prompt: text }); const next = await correction({ data: { projectId, text, approvalId } }); setInput(""); await save(next); } catch (e) { setError(e instanceof Error ? e.message : "Correction could not be saved."); } finally { setBusy(false); } }

  async function render() { const s = live.current; if (!s || busy) return; setBusy(true); setPhase("streaming"); setError(""); try { const clips = await Promise.all(s.clips.map(async (c): Promise<ProductionOutput> => { if (!c.path) throw new Error("All clips must finish first."); return { ...c, url: await signed(c.path) }; })); const blob = await renderMusicFilm(clips, await signed(s.track.path), selected === 1); const { data } = await supabase.auth.getUser(); if (!data.user) throw new Error("Sign in first."); const path = `${data.user.id}/music-video/${crypto.randomUUID()}.webm`; const up = await supabase.storage.from("studio-assets").upload(path, blob, { contentType: "video/webm" }); if (up.error) throw up.error; const r = await supabase.from("studio_projects").insert({ user_id: data.user.id, studio: "music-video", title: `${title} · ${selected === 1 ? "Reverse" : "Timeline"} merge`, kind: "video", asset_path: path }).select("id").single(); if (r.error) throw r.error; const asset = await output(r.data.id); await save({ ...s, final: [...s.final, asset] }); if (escrow.data && escrow.data.status !== "settled") await settle({ data: { projectId, completed: true } }); await refreshCredits(); setPhase("succeeded"); } catch (e) { setError(e instanceof Error ? e.message : "Render failed."); setPhase("failed"); } finally { setBusy(false); } }
  async function edit(asset: ProductionOutput) { if (!asset.path) return; await navigate({ to: "/studio/$id", params: { id: "video" }, search: { source: asset.projectId } }); }
  const s = state;
  return <div className="flex h-full min-h-0 flex-col gap-2 overflow-hidden p-2"><header className="holo flex shrink-0 items-center justify-between gap-3 px-4 py-3"><Link to="/studio/$id" params={{ id: "music-video" }} className="font-display text-lg text-primary">OmniAI / OmniBeat</Link><span className="hidden truncate text-sm sm:block">{title}</span><AccountControl /></header><div className="flex min-h-0 flex-1 gap-2">
    <aside className="holo flex w-32 shrink-0 flex-col gap-3 overflow-hidden p-2 sm:w-56 sm:p-3 md:w-64 xl:w-72"><span className="hud-label text-primary">Omni · Director</span><OmniStatusGauge /><div className="min-h-0 flex-1 space-y-3 overflow-y-auto text-xs">{s?.logs.map((l, i) => <div key={i} className={l.role === "user" ? "text-primary" : "text-muted-foreground"}><MessageResponse>{l.content}</MessageResponse></div>)}</div><Button size="sm" variant="outline" disabled={!escrow.data || escrow.data.status === "settled"} onClick={() => void stop()}><Pause />Stop</Button><p className="text-[10px] text-muted-foreground">Stop pauses after the current request; in-flight compute may finish.</p><form className="recessed shrink-0 space-y-2 p-2" onSubmit={(e) => { e.preventDefault(); void correct(); }}><textarea aria-label="Production correction" value={input} onChange={(e) => setInput(e.target.value)} rows={2} placeholder="What needs fixing?" className="w-full resize-none bg-transparent text-xs outline-none" /><div className="flex flex-wrap gap-1"><EnhanceButton value={input} onChange={setInput} studio="music-video" disabled={busy} /><Button aria-label="Apply correction" size="icon-sm" disabled={busy || !input.trim()}><Send /></Button></div></form></aside>
    <main className="holo hud-corners min-h-0 min-w-0 flex-1 overflow-y-auto p-3 sm:p-6"><div className="mb-5 flex flex-wrap items-center justify-between gap-3"><div><span className="hud-label text-primary">Production pipeline</span><h1 className="mt-1 text-2xl">Your music film</h1></div><Button disabled={busy || !s || s.stage >= 6} onClick={() => { if (!escrow.data || escrow.data.status === "settled") setApprovalOpen(true); else if (escrow.data.status === "reserved") void resume(); }}>{busy ? <Loader2 className="animate-spin" /> : <Play />}{busy ? "Creating…" : !escrow.data || escrow.data.status === "settled" ? "Authorize 400 CR pipeline" : s?.paused ? "Resume production" : "Start production"}</Button></div>{(error || loaded.error) && <p role="alert" className="mb-4 text-sm text-destructive">{error || loaded.error?.message}</p>}
    {approvalOpen && <section role="dialog" aria-label="Authorize video pipeline" className="credit-glass mb-5 space-y-4 rounded-md border p-5">
      <h2 className="text-xl text-primary">Authorize 400 CR for this music video pipeline</h2>
      <p className="text-sm">Analysis 5 CR · reference images 3 CR each · animation 8 CR/sec</p>
      <div className="flex flex-wrap gap-5 font-mono text-primary"><span>Current {wallet?.balance ?? 0} CR</span><span>Available after reservation {Math.max(0, (wallet?.balance ?? 0) - 400)} CR</span></div>
      {(wallet?.balance ?? 0) < 400 && <p role="alert" className="text-destructive">Insufficient Omni Credits. Top off using an Omni Booster Pack. Production is locked.</p>}
      <div className="flex flex-wrap gap-2"><Button disabled={busy || !wallet || wallet.balance < 400} onClick={async () => { setBusy(true); try { await reserve({ data: { projectId } }); setApprovalOpen(false); await refreshCredits(); await resume(); } catch (e) { setError(e instanceof Error ? e.message : "Reservation failed."); } finally { setBusy(false); } }}>Confirm & Authorize Video Pipeline</Button><Button variant="ghost" onClick={() => setApprovalOpen(false)}>Cancel</Button></div>
    </section>}
    {escrow.data && <section aria-label="Reserved pipeline credits" className="recessed mb-5 space-y-3 p-4"><div className="flex flex-wrap justify-between gap-3 font-mono text-primary"><span>{escrow.data.status === "settled" ? "Settled" : "Reserved"} · {escrow.data.reserved} CR</span><span>{escrowRemaining(escrow.data)} CR remaining</span></div><progress aria-label="Reservation remaining" className="w-full accent-primary" max={escrow.data.reserved} value={escrowRemaining(escrow.data)} /><div className="flex flex-wrap gap-4 text-xs text-muted-foreground"><span>Completed {escrow.data.spent} CR</span><span>In flight {escrow.data.pending} CR</span><span>Released {escrow.data.released} CR</span></div></section>}
    {escrow.data?.status === "awaiting-approval" && <section role="alertdialog" aria-label="Authorize continuation" className="credit-glass mb-5 space-y-3 rounded-md border p-5"><h2 className="text-lg">Additional compute steps required. Authorize continuation?</h2><p className="font-mono text-primary">Animation 8 CR/sec · next step {escrow.data.next_required} CR · additional reservation {Math.max(0, escrow.data.next_required - escrowRemaining(escrow.data))} CR</p><p className="text-xs">Current balance {wallet?.balance ?? 0} CR</p><Button disabled={busy || !wallet || wallet.balance < Math.max(0, escrow.data.next_required - escrowRemaining(escrow.data))} onClick={async () => { const r = escrow.data; if (!r) return; try { await extend({ data: { id: r.id } }); await refreshCredits(); await resume(); } catch (e) { setError(e instanceof Error ? e.message : "Continuation failed."); } }}>Confirm & Authorize Continuation</Button><Button variant="ghost" onClick={() => void stop()}>Stop & release unused credits</Button>{wallet && wallet.balance < escrow.data.next_required - escrowRemaining(escrow.data) && <p className="text-destructive text-sm">Top off using an Omni Booster Pack to continue.</p>}</section>}
    {s && <div className="mb-5 flex flex-wrap gap-2 text-xs"><span className="hud-chip">Completed clips {s.renderSeconds * 8} CR</span><span className="hud-chip">{s.renderSeconds}/{s.config.seconds}s rendered</span></div>}
    <div className="space-y-5">{PRODUCTION_STAGES.map((stage, i) => <section key={stage.name} className={`border-b pb-5 ${s?.stage === i ? "border-primary/50" : "border-border"}`}><div className="flex items-start gap-3"><span className={`recessed grid size-8 shrink-0 place-items-center text-sm ${s && s.stage > i ? "text-success" : "text-primary"}`}>{s && s.stage > i ? <Check className="size-4" /> : String(i + 1).padStart(2, "0")}</span><div className="min-w-0 flex-1"><h2 className="text-lg">{stage.name}</h2><p className="text-xs text-muted-foreground">{stage.subtitle}</p></div><span className="hud-label">{s && s.stage > i ? "Complete" : busy && s?.stage === i ? "Working" : "Queued"}</span></div>
      {s?.results[String(i)] && <div className="mt-4 text-sm"><MessageResponse>{s.results[String(i)] ?? ""}</MessageResponse></div>}
      {i === 3 && !!s?.images.length && <div className="mt-4 grid grid-cols-2 gap-2 lg:grid-cols-4">{s.images.map((a, n) => <SavedAsset key={a.path ?? n} asset={a} image />)}</div>}
      {i === 5 && !!s?.clips.length && <div className="mt-4 grid gap-3 lg:grid-cols-2">{s.clips.map((a, n) => <div key={a.jobId ?? n}><p className="mb-2 text-xs text-primary">Scene {n + 1} · {a.seconds}s</p>{a.path ? <SavedAsset asset={a} /> : <p className="text-xs text-muted-foreground">Generating clip…</p>}</div>)}{s.clips.length > 0 && s.clips.every((c) => c.path) && <Button className="mt-3" variant="outline" onClick={() => void navigate({ to: "/studio/$id", params: { id: "video" }, search: { production: projectId } })}><Scissors />Open scenes in editor · trim, titles, export</Button>}</div>}
      {i === 6 && s?.stage === 6 && <div className="mt-4 space-y-4"><div role="radiogroup" aria-label="Merge version" className="flex flex-wrap gap-2">{["Timeline order", "Reverse cut"].map((v, n) => <Button key={v} role="radio" aria-checked={selected === n} variant={selected === n ? "default" : "outline"} size="sm" onClick={() => setSelected(n)}>{v}</Button>)}<Button disabled={busy} onClick={() => void render()}><Play />{busy ? "Rendering…" : "Render merge"}</Button></div><p className="text-xs text-muted-foreground">WebM · original song · keep this page open during rendering</p>{s.final.map((a, n) => <div key={a.path ?? n} className="space-y-3"><SavedAsset asset={a} /><div className="flex flex-wrap gap-2"><Button size="sm" onClick={async () => { if (!a.path) return; const url = await signed(a.path); const blob = await (await fetch(url)).blob(); const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = `${title}.webm`; link.click(); }}><Download />Download</Button><Button size="sm" variant="outline" onClick={async () => { if (!a.path) return; try { const file = new File([await (await fetch(await signed(a.path))).blob()], `${title}.webm`, { type: "video/webm" }); if (navigator.canShare?.({ files: [file] })) await navigator.share({ files: [file], title }); else toast.info("Download your film to share it."); } catch { toast.error("Sharing was cancelled or unavailable."); } }}><Share2 />Share</Button><Button size="sm" variant="outline" onClick={() => void edit(a)}><Scissors />Edit video</Button></div></div>)}</div>}
    </section>)}</div></main></div></div>;
}
function SavedAsset({ asset, image = false }: { asset: ProductionOutput; image?: boolean }) { const [url, setUrl] = useState(""); useEffect(() => { if (!asset.path) return; let active = true; void supabase.storage.from("studio-assets").createSignedUrl(asset.path, 3600).then((r) => { if (active && r.data) setUrl(r.data.signedUrl); }); return () => { active = false; }; }, [asset.path]); return image ? <img src={url || undefined} alt="Generated film reference" className="aspect-video w-full rounded-md object-cover" /> : <video src={url || undefined} controls className="aspect-video w-full rounded-md bg-background" />; }