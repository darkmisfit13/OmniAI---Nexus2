import { Suspense, useEffect, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { OBJExporter } from "three/examples/jsm/exporters/OBJExporter.js";
import { GLTFExporter } from "three/examples/jsm/exporters/GLTFExporter.js";
import { USDZExporter } from "three/examples/jsm/exporters/USDZExporter.js";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Wand2, Download, RotateCw } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { askModel } from "@/lib/ai.functions";
import { EnhanceButton } from "@/components/MediaComposer";
import { useAccount } from "@/components/AccountProvider";

type MeshStyle = "quad" | "tri" | "points";
type Material = { color: string; metalness: number; roughness: number; opacity: number; emissive: number; emissiveColor: string };

const PRESETS: Record<string, Material> = {
  "Brushed aluminum": { color: "#b8bcc4", metalness: 0.9, roughness: 0.35, opacity: 1, emissive: 0, emissiveColor: "#000000" },
  "Neon trim": { color: "#101014", metalness: 0.5, roughness: 0.35, opacity: 1, emissive: 0.4, emissiveColor: "#00f2fe" },
  "Matte obsidian": { color: "#0B0B0C", metalness: 0.1, roughness: 0.95, opacity: 1, emissive: 0, emissiveColor: "#000000" },
  "Carbon fiber": { color: "#1a1d22", metalness: 0.6, roughness: 0.55, opacity: 1, emissive: 0, emissiveColor: "#000000" },
  "Holographic decal": { color: "#7f00ff", metalness: 0.2, roughness: 0.15, opacity: 0.65, emissive: 1.1, emissiveColor: "#7f00ff" },
};

function geometryFor(style: MeshStyle) {
  if (style === "quad") return new THREE.BoxGeometry(1.6, 1.6, 1.6, 4, 4, 4);
  if (style === "points") return new THREE.TorusKnotGeometry(1, 0.32, 120, 20);
  return new THREE.TorusKnotGeometry(1, 0.32, 160, 24);
}

function Model({ meshStyle, mat, spin, objectRef }: { meshStyle: MeshStyle; mat: Material; spin: boolean; objectRef: React.MutableRefObject<THREE.Object3D | null> }) {
  const group = useRef<THREE.Group>(null);
  const [geo, setGeo] = useState(() => geometryFor(meshStyle));
  useEffect(() => {
    const g = geometryFor(meshStyle);
    setGeo((old) => { old.dispose(); return g; });
  }, [meshStyle]);
  useFrame((_, delta) => { if (spin && group.current) { group.current.rotation.y += delta * 0.5; group.current.rotation.x += delta * 0.15; } });
  const material = <meshStandardMaterial color={mat.color} metalness={mat.metalness} roughness={mat.roughness} transparent={mat.opacity < 1} opacity={mat.opacity} emissive={mat.emissiveColor} emissiveIntensity={mat.emissive} flatShading={meshStyle === "quad"} />;
  return (
    <group ref={(g) => { group.current = g; objectRef.current = g; }} scale={0.7}>
      {meshStyle === "points" ? (
        <points geometry={geo}>
          <pointsMaterial color={mat.emissive > 0 ? mat.emissiveColor : mat.color} size={0.03} sizeAttenuation transparent opacity={mat.opacity} />
        </points>
      ) : (
        <mesh geometry={geo} castShadow>{material}</mesh>
      )}
      <mesh rotation-x={-Math.PI / 2} position-y={-1.8} receiveShadow>
        <planeGeometry args={[12, 12]} />
        <meshStandardMaterial color="#0B0B0C" metalness={0.3} roughness={0.8} />
      </mesh>
    </group>
  );
}

function Slider({ label, value, onChange, min = 0, max = 1, step = 0.01 }: { label: string; value: number; onChange: (v: number) => void; min?: number; max?: number; step?: number }) {
  return (
    <label className="block text-xs text-muted-foreground">{label}
      <div className="mt-1 flex items-center gap-2">
        <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full accent-primary" aria-label={label} />
        <span className="w-10 text-right font-mono text-xs text-primary">{value.toFixed(2)}</span>
      </div>
    </label>
  );
}

export function OmniSpatial() {
  const { user } = useAccount();
  const ask = useServerFn(askModel);
  const [mounted, setMounted] = useState(false);
  const [meshStyle, setMeshStyle] = useState<MeshStyle>("tri");
  const [mat, setMat] = useState<Material>(PRESETS["Neon trim"]!);
  const [spin, setSpin] = useState(true);
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);
  const objectRef = useRef<THREE.Object3D | null>(null);
  useEffect(() => setMounted(true), []);

  const applyAiMaterial = async () => {
    if (!prompt.trim() || busy) return;
    if (!user) { toast.error("Sign in to use AI material commands."); return; }
    setBusy(true);
    try {
      const r = await ask({ data: { model: "openai/gpt-6-astra", messages: [{ role: "user", content: prompt }], system: `You translate a material description into JSON for a 3D meshStandardMaterial. Reply with ONLY JSON: {"color":"#hex","metalness":0-1,"roughness":0-1,"opacity":0-1,"emissive":0-2,"emissiveColor":"#hex"}. Current: ${JSON.stringify(mat)}` } });
      const m = r.text.match(/\{[\s\S]*\}/);
      if (!m) throw new Error("The AI didn't return material settings.");
      const parsed = JSON.parse(m[0]) as Partial<Material>;
      setMat((old) => ({
        color: /^#[0-9a-f]{6}$/i.test(parsed.color ?? "") ? parsed.color! : old.color,
        metalness: Math.min(1, Math.max(0, Number(parsed.metalness ?? old.metalness))),
        roughness: Math.min(1, Math.max(0, Number(parsed.roughness ?? old.roughness))),
        opacity: Math.min(1, Math.max(0.05, Number(parsed.opacity ?? old.opacity))),
        emissive: Math.min(2, Math.max(0, Number(parsed.emissive ?? old.emissive))),
        emissiveColor: /^#[0-9a-f]{6}$/i.test(parsed.emissiveColor ?? "") ? parsed.emissiveColor! : old.emissiveColor,
      }));
      toast.success("Material applied to the surface.");
    } catch (e) { toast.error(e instanceof Error ? e.message : "Material command failed."); }
    finally { setBusy(false); }
  };

  const download = (name: string, blob: Blob) => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  const exportModel = async (kind: "obj" | "gltf" | "usdz") => {
    const obj = objectRef.current;
    if (!obj) { toast.error("Nothing to export yet."); return; }
    try {
      if (kind === "obj") download("omnispatial.obj", new Blob([new OBJExporter().parse(obj)], { type: "text/plain" }));
      else if (kind === "gltf") {
        const gltf = await new GLTFExporter().parseAsync(obj, { binary: false });
        download("omnispatial.gltf", new Blob([JSON.stringify(gltf)], { type: "model/gltf+json" }));
      } else {
        const buf = await new USDZExporter().parseAsync(obj);
        download("omnispatial.usdz", new Blob([buf], { type: "model/vnd.usdz+zip" }));
      }
    } catch (e) { toast.error(e instanceof Error ? e.message : "Export failed."); }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-hidden p-4">
      <div className="grid min-h-0 flex-1 gap-3 lg:grid-cols-3">
        <section className="holo hud-corners relative min-h-64 overflow-hidden lg:col-span-2">
          <span className="hud-label absolute left-3 top-3 z-10">Live viewport</span>
          <Button variant="outline" size="icon-sm" className="absolute right-3 top-3 z-10 bevel" title={spin ? "Pause rotation" : "Resume rotation"} aria-label="Toggle rotation" onClick={() => setSpin((v) => !v)}><RotateCw /></Button>
          {mounted && (
            <Canvas shadows camera={{ position: [0, 2, 9.5], fov: 45 }}>
              <color attach="background" args={["#000000"]} />
              <ambientLight intensity={0.35} />
              <directionalLight position={[4, 6, 4]} intensity={1.4} castShadow />
              <pointLight position={[-4, 2, -3]} intensity={6} color="#7f00ff" />
              <pointLight position={[4, -1, 3]} intensity={4} color="#00f2fe" />
              <Suspense fallback={null}>
                <Model meshStyle={meshStyle} mat={mat} spin={spin} objectRef={objectRef} />
              </Suspense>
            </Canvas>
          )}
        </section>
        <div className="flex min-h-0 flex-col gap-3 overflow-y-auto">
          <section className="holo hud-corners space-y-3 p-4">
            <span className="hud-label">3D model constructor</span>
            <div className="flex flex-wrap gap-2">
              {([["quad", "Quad mesh"], ["tri", "Triangular mesh"], ["points", "Point cloud"]] as const).map(([id, label]) => (
                <Button key={id} variant={meshStyle === id ? "default" : "outline"} size="sm" className="bevel" onClick={() => setMeshStyle(id)}>{label}</Button>
              ))}
            </div>
            <span className="hud-label">Export matrix</span>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm" className="bevel" onClick={() => void exportModel("obj")}><Download />.obj</Button>
              <Button variant="outline" size="sm" className="bevel" onClick={() => void exportModel("gltf")}><Download />.gltf</Button>
              <Button variant="outline" size="sm" className="bevel" onClick={() => void exportModel("usdz")}><Download />.usdz</Button>
            </div>
          </section>
          <section className="holo hud-corners space-y-3 p-4">
            <span className="hud-label">Texture & inpainting deck</span>
            <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={2} aria-label="AI material prompt"
              placeholder="Make it more metallic with a cyan emission glow…"
              className="w-full resize-none rounded-md border bg-background/60 p-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
            <div className="flex items-center gap-2">
              <EnhanceButton value={prompt} onChange={setPrompt} studio="3d" disabled={busy} />
              <Button size="sm" className="ml-auto bevel" disabled={busy || !prompt.trim()} onClick={() => void applyAiMaterial()}>{busy ? <Loader2 className="animate-spin" /> : <Wand2 />}Apply to surface</Button>
            </div>
            <Slider label="Metallic" value={mat.metalness} onChange={(v) => setMat((m) => ({ ...m, metalness: v }))} />
            <Slider label="Rough ↔ smooth" value={mat.roughness} onChange={(v) => setMat((m) => ({ ...m, roughness: v }))} />
            <Slider label="Opacity" value={mat.opacity} onChange={(v) => setMat((m) => ({ ...m, opacity: v }))} />
            <Slider label="Emission glow" value={mat.emissive} onChange={(v) => setMat((m) => ({ ...m, emissive: v }))} max={2} />
            <div className="flex items-center gap-3">
              <label className="text-xs text-muted-foreground">Base <input type="color" value={mat.color} aria-label="Base color" onChange={(e) => setMat((m) => ({ ...m, color: e.target.value }))} className="ml-1 size-7 cursor-pointer rounded border border-border bg-transparent align-middle" /></label>
              <label className="text-xs text-muted-foreground">Glow <input type="color" value={mat.emissiveColor} aria-label="Emission color" onChange={(e) => setMat((m) => ({ ...m, emissiveColor: e.target.value }))} className="ml-1 size-7 cursor-pointer rounded border border-border bg-transparent align-middle" /></label>
            </div>
            <span className="hud-label">Material presets</span>
            <div className="flex flex-wrap gap-2">
              {Object.keys(PRESETS).map((p) => <Button key={p} variant="outline" size="sm" className="bevel" onClick={() => setMat(PRESETS[p]!)}>{p}</Button>)}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
