import { useRef, useState } from "react";
import { Database, Copy, Plus, Trash2, ArrowRight, Play, Webhook, ShieldCheck, Rows3, GitBranch, Check } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";

type Col = { name: string; type: string };
type Table = { id: string; name: string; cols: Col[]; x: number; y: number };
type Rel = { from: string; to: string };

const DEFAULT_TABLES: Table[] = [
  { id: "users", name: "users", x: 20, y: 20, cols: [{ name: "id", type: "uuid pk" }, { name: "email", type: "text" }, { name: "display_name", type: "text" }, { name: "created_at", type: "timestamptz" }] },
  { id: "products", name: "products", x: 300, y: 20, cols: [{ name: "id", type: "uuid pk" }, { name: "title", type: "text" }, { name: "price", type: "numeric" }, { name: "owner_id", type: "uuid fk" }] },
  { id: "orders", name: "orders", x: 20, y: 240, cols: [{ name: "id", type: "uuid pk" }, { name: "user_id", type: "uuid fk" }, { name: "product_id", type: "uuid fk" }, { name: "total", type: "numeric" }] },
  { id: "messages", name: "messages", x: 300, y: 240, cols: [{ name: "id", type: "uuid pk" }, { name: "sender_id", type: "uuid fk" }, { name: "body", type: "text" }, { name: "created_at", type: "timestamptz" }] },
];

const sqlType = (t: string) => t.replace(" pk", " primary key default gen_random_uuid()").replace(" fk", "");

function buildSql(tables: Table[], rels: Rel[]) {
  const fkLines = rels.map((r) => {
    const [ft, fc] = r.from.split(".");
    const [tt, tc] = r.to.split(".");
    return `alter table public.${ft} add constraint fk_${ft}_${fc} foreign key (${fc}) references public.${tt} (${tc});`;
  });
  return [
    ...tables.map((t) => `create table public.${t.name} (\n${t.cols.map((c) => `  ${c.name} ${sqlType(c.type)}`).join(",\n")}\n);\n\ngrant select, insert, update, delete on public.${t.name} to authenticated;\nalter table public.${t.name} enable row level security;`),
    ...fkLines,
  ].join("\n\n");
}

type Migration = { id: string; name: string; stage: "dev" | "staged" | "live" };
const DEFAULT_MIGRATIONS: Migration[] = [
  { id: "m1", name: "20261016_messages_body_index", stage: "dev" },
  { id: "m2", name: "20261016_users_row_inu", stage: "dev" },
  { id: "m3", name: "20261016_orders_total_numeric", stage: "staged" },
  { id: "m4", name: "20261015_init_schema", stage: "live" },
];

const FIRST = ["aria", "kai", "milo", "zoe", "lena", "odin", "ivy", "rex"], LAST = ["chen", "garcia", "kim", "patel", "smith", "novak"];
function mockRows(table: Table, n: number) {
  return Array.from({ length: n }, (_, i) => Object.fromEntries(table.cols.map((c) => {
    if (c.type.startsWith("uuid")) return [c.name, crypto.randomUUID().slice(0, 8)];
    if (c.name.includes("email")) return [c.name, `${FIRST[i % 8]}.${LAST[(i * 3) % 6]}${i}@example.com`];
    if (c.type.includes("numeric")) return [c.name, (Math.random() * 500).toFixed(2)];
    if (c.type.includes("timestamptz")) return [c.name, new Date(Date.now() - i * 86400000).toISOString().slice(0, 10)];
    return [c.name, `${c.name}_${i + 1}`];
  })));
}

export function OmniBackend() {
  const [tables, setTables] = useState<Table[]>(DEFAULT_TABLES);
  const [rels, setRels] = useState<Rel[]>([]);
  const [pending, setPending] = useState<string | null>(null);
  const [drag, setDrag] = useState<{ id: string; dx: number; dy: number } | null>(null);
  const [testResult, setTestResult] = useState<Record<string, string>>({});
  const [pipeline, setPipeline] = useState({ jwt: true, cookie: true, email: false, refresh: true, rateLimit: true });
  const [hooks, setHooks] = useState<{ event: string; url: string }[]>([]);
  const [hookEvent, setHookEvent] = useState("insert on users");
  const [hookUrl, setHookUrl] = useState("");
  const [rate, setRate] = useState({ max: 120, burst: 30 });
  const [cors, setCors] = useState("Same origin only");
  const [tier, setTier] = useState("Owner only (RLS)");
  const [mockTable, setMockTable] = useState("orders");
  const [mockCount, setMockCount] = useState(100);
  const [mockPreview, setMockPreview] = useState<Record<string, string>[]>([]);
  const [migrations, setMigrations] = useState<Migration[]>(DEFAULT_MIGRATIONS);
  const canvasRef = useRef<HTMLDivElement>(null);

  const sql = buildSql(tables, rels);

  const onHeaderDown = (e: React.PointerEvent, t: Table) => {
    const box = canvasRef.current?.getBoundingClientRect();
    if (!box) return;
    setDrag({ id: t.id, dx: e.clientX - box.left - t.x, dy: e.clientY - box.top - t.y });
  };
  const onCanvasMove = (e: React.PointerEvent) => {
    if (!drag) return;
    const box = canvasRef.current?.getBoundingClientRect();
    if (!box) return;
    setTables((all) => all.map((t) => (t.id === drag.id ? { ...t, x: Math.max(0, e.clientX - box.left - drag.dx), y: Math.max(0, e.clientY - box.top - drag.dy) } : t)));
  };

  const clickCol = (key: string) => {
    if (!pending) { setPending(key); return; }
    if (pending === key) { setPending(null); return; }
    const [ft] = pending.split("."), [tt] = key.split(".");
    if (ft === tt) { setPending(key); return; }
    setRels((all) => [...all, { from: pending, to: key }]);
    setPending(null);
  };

  const colPos = (key: string) => {
    const [tid, cn] = key.split(".");
    const t = tables.find((x) => x.id === tid);
    if (!t) return { x: 0, y: 0 };
    const idx = t.cols.findIndex((c) => c.name === cn);
    return { x: t.x + 110, y: t.y + 44 + idx * 24 + 12 };
  };

  const testRequest = (path: string) => {
    const table = tables.find((t) => path.includes(t.name));
    const rows = table ? mockRows(table, 2) : [{ ok: "true" }];
    setTestResult((all) => ({ ...all, [path]: JSON.stringify(path.startsWith("post") ? { inserted: rows[0] } : rows, null, 2) }));
  };

  const copySql = async () => { await navigator.clipboard.writeText(sql); toast.success("Migration SQL copied."); };

  const pipeNodes: [keyof typeof pipeline, string][] = [["jwt", "JWT security layer"], ["cookie", "HTTP-only cookie storage"], ["email", "Email validation workflow"], ["refresh", "Refresh token rotation"], ["rateLimit", "Rate limit guard"]];
  const activeNodes = pipeNodes.filter(([k]) => pipeline[k]);

  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-y-auto p-4">
      <div className="grid gap-3 xl:grid-cols-3">
        <section className="holo hud-corners flex flex-col gap-2 p-4 xl:col-span-2">
          <div className="flex items-center justify-between">
            <span className="hud-label"><Database className="mr-1 inline size-3" />Database schema playground</span>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="bevel" onClick={() => setTables((all) => [...all, { id: `table_${all.length + 1}`, name: `table_${all.length + 1}`, x: 60 + all.length * 30, y: 60 + all.length * 30, cols: [{ name: "id", type: "uuid pk" }] }])}><Plus />Table</Button>
              <Button variant="outline" size="sm" className="bevel" onClick={() => { setRels([]); setPending(null); }}><Trash2 />Clear relationships</Button>
            </div>
          </div>
          <p className="text-[11px] text-muted-foreground">All table blocks move freely — drag a header to reposition. Click a column, then another column, to draw a relationship.</p>
          <div ref={canvasRef} onPointerMove={onCanvasMove} onPointerUp={() => setDrag(null)} onPointerLeave={() => setDrag(null)}
            className="recessed relative h-96 touch-none overflow-hidden">
            <svg className="pointer-events-none absolute inset-0 size-full">
              {rels.map((r, i) => { const a = colPos(r.from), b = colPos(r.to); return <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#00f2fe" strokeWidth="1.5" strokeDasharray="4 3" opacity="0.8" />; })}
            </svg>
            {tables.map((t) => (
              <div key={t.id} className="absolute w-56 rounded-md border border-border bg-card/90 shadow-glow" style={{ left: t.x, top: t.y }}>
                <div onPointerDown={(e) => onHeaderDown(e, t)} className="flex cursor-grab items-center justify-between rounded-t-md border-b bg-secondary/60 px-2 py-1.5 text-xs font-semibold active:cursor-grabbing">
                  <span className="font-mono text-primary">{t.name}</span>
                  <button type="button" aria-label={`Delete ${t.name}`} onClick={() => { setTables((all) => all.filter((x) => x.id !== t.id)); setRels((all) => all.filter((r) => !r.from.startsWith(t.id + ".") && !r.to.startsWith(t.id + "."))); }} className="text-muted-foreground hover:text-destructive"><Trash2 className="size-3" /></button>
                </div>
                {t.cols.map((c) => {
                  const key = `${t.id}.${c.name}`;
                  return (
                    <button key={c.name} type="button" onClick={() => clickCol(key)}
                      className={`flex w-full items-center justify-between px-2 py-1 text-left font-mono text-[11px] ${pending === key ? "bg-primary/20 text-primary" : "text-muted-foreground hover:bg-secondary/40"}`}>
                      <span>{c.name}</span><span className="text-[10px] opacity-70">{c.type}</span>
                    </button>
                  );
                })}
                <button type="button" onClick={() => setTables((all) => all.map((x) => (x.id === t.id ? { ...x, cols: [...x.cols, { name: `col_${x.cols.length + 1}`, type: "text" }] } : x)))} className="w-full border-t px-2 py-1 text-left text-[10px] text-muted-foreground hover:text-primary">+ column</button>
              </div>
            ))}
          </div>
        </section>

        <section className="holo hud-corners flex flex-col gap-2 p-4">
          <span className="hud-label">Live API documentation inspector</span>
          <p className="text-[11px] text-muted-foreground">Auto-generated REST and GraphQL endpoint reference blocks as the schema is built.</p>
          <div className="min-h-0 flex-1 space-y-2 overflow-y-auto">
            {tables.flatMap((t) => [
              { m: "get", path: `/api/${t.name}`, d: `List all ${t.name} records` },
              { m: "post", path: `/api/${t.name}`, d: `Create a new ${t.name} record` },
            ]).concat([{ m: "post", path: "/api/auth/signin", d: `Auth via Google OAuth ${pipeline.jwt ? "enabled" : "disabled"}` }]).map((e) => {
              const key = `${e.m}${e.path}`;
              return (
                <div key={key} className="rounded-md border border-border bg-background/50 p-2">
                  <p className="flex items-center gap-2 font-mono text-[11px]">
                    <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold uppercase ${e.m === "get" ? "bg-primary/20 text-primary" : "bg-accent/20 text-accent"}`}>{e.m}</span>
                    <span className="truncate">{e.path}</span>
                  </p>
                  <p className="mt-0.5 text-[11px] text-muted-foreground">{e.d}</p>
                  <Button variant="outline" size="sm" className="mt-1 h-6 bevel text-[10px]" onClick={() => testRequest(key)}><Play className="size-3" />Test request</Button>
                  {testResult[key] && <pre className="mt-1 max-h-28 overflow-auto rounded bg-black/60 p-2 font-mono text-[10px] text-success">{testResult[key]}</pre>}
                </div>
              );
            })}
          </div>
        </section>
      </div>

      <div className="grid gap-3 xl:grid-cols-3">
        <section className="holo hud-corners flex flex-col gap-2 p-4">
          <div className="flex items-center justify-between"><span className="hud-label">SQL schema raw terminal</span><Button variant="outline" size="sm" className="bevel" onClick={() => void copySql()}><Copy />Copy</Button></div>
          <p className="text-[11px] text-muted-foreground">Raw backend infrastructure controls with PostgreSQL — migration SQL.</p>
          <pre className="recessed max-h-72 flex-1 overflow-auto p-3 font-mono text-[10px] leading-relaxed text-primary/90">{sql}</pre>
        </section>

        <section className="holo hud-corners flex flex-col gap-3 p-4">
          <span className="hud-label"><ShieldCheck className="mr-1 inline size-3" />One-click auth pipeline constructor</span>
          <p className="text-[11px] text-muted-foreground">Toggle nodes to instantly stitch JWT security layers, cookie storage and email validation workflows into the request pipeline.</p>
          {pipeNodes.map(([k, label]) => (
            <label key={k} className="flex items-center justify-between text-xs text-muted-foreground">{label}
              <input type="checkbox" checked={pipeline[k]} onChange={(e) => setPipeline((p) => ({ ...p, [k]: e.target.checked }))} className="accent-primary" /></label>
          ))}
          <div className="recessed flex flex-wrap items-center gap-1 p-2 font-mono text-[10px]">
            <span className="rounded bg-secondary px-1.5 py-0.5">request</span>
            {activeNodes.map(([k, label]) => (
              <span key={k} className="flex items-center gap-1"><ArrowRight className="size-3 text-primary" /><span className="rounded bg-primary/15 px-1.5 py-0.5 text-primary">{label}</span></span>
            ))}
            <span className="flex items-center gap-1"><ArrowRight className="size-3 text-primary" /><span className="rounded bg-success/15 px-1.5 py-0.5 text-success">route</span></span>
          </div>
          <span className="hud-label"><Webhook className="mr-1 inline size-3" />Webhook payload broadcaster</span>
          <p className="text-[11px] text-muted-foreground">Configure custom outgoing API posts to trigger on database updates.</p>
          <div className="flex gap-2">
            <select value={hookEvent} onChange={(e) => setHookEvent(e.target.value)} className="rounded-md border bg-background/60 p-1.5 text-xs">
              {["insert on users", "insert on orders", "update on orders", "delete on messages", "insert on products"].map((e) => <option key={e}>{e}</option>)}
            </select>
            <input value={hookUrl} onChange={(e) => setHookUrl(e.target.value)} placeholder="https://api.yourapp.com/hooks" className="min-w-0 flex-1 rounded-md border bg-background/60 p-1.5 font-mono text-xs" />
            <Button variant="outline" size="sm" className="bevel" onClick={() => { if (!/^https:\/\//.test(hookUrl)) { toast.error("HTTPS URL required."); return; } setHooks((all) => [...all, { event: hookEvent, url: hookUrl }]); setHookUrl(""); }}>Add broadcast target</Button>
          </div>
          {hooks.map((h, i) => <p key={i} className="flex items-center justify-between rounded border border-border bg-background/50 px-2 py-1 font-mono text-[10px] text-muted-foreground"><span>{h.event} → {h.url}</span><button type="button" aria-label="Remove target" onClick={() => setHooks((all) => all.filter((_, j) => j !== i))} className="hover:text-destructive"><Trash2 className="size-3" /></button></p>)}
        </section>

        <section className="flex flex-col gap-3">
          <div className="holo hud-corners space-y-3 p-4">
            <span className="hud-label">Rate limiting & security firewall matrix</span>
            <label className="block text-xs text-muted-foreground">Max requests per minute
              <div className="mt-1 flex items-center gap-2"><input type="range" min={10} max={1000} value={rate.max} onChange={(e) => setRate((r) => ({ ...r, max: Number(e.target.value) }))} className="w-full accent-primary" aria-label="Max requests per minute" /><span className="w-10 text-right font-mono text-xs text-primary">{rate.max}</span></div></label>
            <label className="block text-xs text-muted-foreground">Burst allowance
              <div className="mt-1 flex items-center gap-2"><input type="range" min={0} max={200} value={rate.burst} onChange={(e) => setRate((r) => ({ ...r, burst: Number(e.target.value) }))} className="w-full accent-primary" aria-label="Burst allowance" /><span className="w-10 text-right font-mono text-xs text-primary">{rate.burst}</span></div></label>
            <label className="block text-xs text-muted-foreground">CORS access policy
              <select value={cors} onChange={(e) => setCors(e.target.value)} className="mt-1 w-full rounded-md border bg-background/60 p-1.5 text-xs">{["Same origin only", "Allow list — trusted domains", "Public — any origin"].map((o) => <option key={o}>{o}</option>)}</select></label>
            <label className="block text-xs text-muted-foreground">Data table access tier
              <select value={tier} onChange={(e) => setTier(e.target.value)} className="mt-1 w-full rounded-md border bg-background/60 p-1.5 text-xs">{["Authenticated users", "Public read", "Row scoped (RBAC)", "Owner only (RLS)"].map((o) => <option key={o}>{o}</option>)}</select></label>
          </div>
          <div className="holo hud-corners space-y-2 p-4">
            <span className="hud-label"><Rows3 className="mr-1 inline size-3" />Mock data ingestion suite</span>
            <p className="text-[11px] text-muted-foreground">Populate newly constructed columns with realistic generated rows for load testing. Ingestion needs a scaffolded backend; this previews the row set.</p>
            <div className="flex items-center gap-2">
              <select value={mockTable} onChange={(e) => setMockTable(e.target.value)} className="rounded-md border bg-background/60 p-1.5 text-xs">{tables.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select>
              <input type="number" min={1} max={5000} value={mockCount} onChange={(e) => setMockCount(Math.min(5000, Math.max(1, Number(e.target.value))))} aria-label="Row count" className="w-20 rounded-md border bg-background/60 p-1.5 font-mono text-xs" />
              <Button variant="outline" size="sm" className="bevel" onClick={() => setMockPreview(mockRows(tables.find((t) => t.id === mockTable) ?? tables[0]!, Math.min(mockCount, 8)))}>Generate up to 5,000 rows</Button>
            </div>
            {mockPreview.length > 0 && <pre className="recessed max-h-28 overflow-auto p-2 font-mono text-[10px] text-muted-foreground">{JSON.stringify(mockPreview, null, 1)}</pre>}
          </div>
        </section>
      </div>

      <section className="holo hud-corners space-y-2 p-4">
        <span className="hud-label"><GitBranch className="mr-1 inline size-3" />Database migration console</span>
        <p className="text-[11px] text-muted-foreground">Visual staging pass tracking updates between development schemas and the active live production database.</p>
        <div className="grid gap-3 md:grid-cols-3">
          {(["dev", "staged", "live"] as const).map((stage) => (
            <div key={stage} className="recessed space-y-2 p-3">
              <p className="font-mono text-xs font-semibold uppercase text-primary">{stage === "dev" ? "Development 2" : stage === "staged" ? "Stage 1" : "Live production"}</p>
              {migrations.filter((m) => m.stage === stage).map((m) => (
                <div key={m.id} className="flex items-center justify-between gap-2 rounded border border-border bg-background/50 px-2 py-1.5 font-mono text-[10px]">
                  <span className="truncate">{m.name}</span>
                  {stage === "live" ? <span className="flex items-center gap-1 text-success"><Check className="size-3" />Applied to production</span> : (
                    <Button variant="outline" size="sm" className="h-6 bevel text-[10px]" onClick={() => setMigrations((all) => all.map((x) => (x.id === m.id ? { ...x, stage: stage === "dev" ? "staged" : "live" } : x)))}>
                      Promote <ArrowRight className="size-3" />{stage === "dev" ? "staged" : "live"}
                    </Button>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
