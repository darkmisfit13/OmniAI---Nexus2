import { useEffect, useMemo, useRef, useState } from "react";
import { useStudioActions } from "@/lib/studio-actions";
import { useParams, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Code2, Download, Eye, FileCode2, FilePlus2, FolderOpen, Loader2, Monitor, Send, Smartphone, Sparkles, Wrench } from "lucide-react";
import { FILE_NAMES, joinSite, splitSite } from "@/lib/site-files";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { buildSite } from "@/lib/ai.functions";
import { notifyWorkstationEvent } from "@/lib/notifications.functions";
import { useAccount } from "@/components/AccountProvider";
import { useWorkspaceState } from "@/components/WorkspaceStateProvider";
import { Button } from "@/components/ui/button";
import { EnhanceButton } from "@/components/MediaComposer";

type Log = { at: string; level: "info" | "ok" | "error" | "warn"; text: string };
type Turn = { role: "user" | "ai"; text: string };

// Injected into the preview so its console and runtime errors stream into the terminal.
const BRIDGE = `<script>(function(){function s(l,a){try{parent.postMessage({omni:1,level:l,text:Array.from(a).map(function(x){try{return typeof x==="string"?x:JSON.stringify(x)}catch(e){return String(x)}}).join(" ")},"*")}catch(e){}}
["log","warn","error"].forEach(function(k){var o=console[k];console[k]=function(){s(k==="log"?"info":k,arguments);o.apply(console,arguments)}});
addEventListener("error",function(e){s("error",[e.message+" (line "+e.lineno+")"])});addEventListener("unhandledrejection",function(e){s("error",["Unhandled promise: "+(e.reason&&e.reason.message||e.reason)])});s("ok",["Preview runtime started"]);})();</script>`;
const withBridge = (html: string) => /<head[^>]*>/i.test(html) ? html.replace(/<head[^>]*>/i, (m) => m + BRIDGE) : BRIDGE + html;
const now = () => new Date().toLocaleTimeString([], { hour12: false });

export function OmniForge() {
  const { id: kind = "website" } = useParams({ strict: false }) as { id?: string };
  const { user } = useAccount(); const qc = useQueryClient(); const { setPhase } = useWorkspaceState();
  const build = useServerFn(buildSite);
  const notify = useServerFn(notifyWorkstationEvent);
  const [projectId, setProjectId] = useState<string | null>(null);
  const [title, setTitle] = useState("Untitled project");
  const [html, setHtml] = useState(""); const [turns, setTurns] = useState<Turn[]>([]);
  const [prompt, setPrompt] = useState(""); const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<"preview" | "code">("preview"); const [device, setDevice] = useState<"desktop" | "mobile">("desktop");
  const [logs, setLogs] = useState<Log[]>([]);
  const frame = useRef<HTMLIFrameElement>(null); const termEnd = useRef<HTMLDivElement>(null);
  const log = (level: Log["level"], text: string) => setLogs((l) => [...l.slice(-300), { at: now(), level, text }]);

  const projects = useQuery({ queryKey: ["builds", kind, user?.id], enabled: !!user, queryFn: async () => {
    const r = await supabase.from("studio_projects").select("id,title,content,state,created_at").eq("studio", kind).eq("kind", "build").order("created_at", { ascending: false });
    if (r.error) throw r.error; return r.data;
  } });

  useEffect(() => {
    let reported = false;
    const onMsg = (e: MessageEvent) => { if (e.source !== frame.current?.contentWindow || !e.data?.omni) return; log(e.data.level, String(e.data.text).slice(0, 500)); if (e.data.level === "error" && !reported) { reported = true; void notify({ data: { event: "compilation", key: crypto.randomUUID() } }).catch(() => {}); } };
    addEventListener("message", onMsg); return () => removeEventListener("message", onMsg);
  }, [notify, html]);
  useEffect(() => { termEnd.current?.scrollIntoView({ block: "end" }); }, [logs]);
  const srcDoc = useMemo(() => html ? withBridge(html) : "", [html]);
  const [file, setFile] = useState<(typeof FILE_NAMES)[number]>("index.html");
  const files = useMemo(() => splitSite(html), [html]);

  async function save(nextHtml: string, nextTurns: Turn[], nextTitle: string) {
    if (!user) throw new Error("Sign in to save.");
    const row = { studio: kind, kind: "build", title: nextTitle, content: nextHtml, state: { turns: nextTurns } };
    const r = projectId ? await supabase.from("studio_projects").update(row).eq("id", projectId).select("id").single() : await supabase.from("studio_projects").insert({ ...row, user_id: user.id }).select("id").single();
    if (r.error) throw r.error; setProjectId(r.data.id); void qc.invalidateQueries({ queryKey: ["builds", kind] });
    log("ok", `Saved to your account (${(nextHtml.length / 1024).toFixed(1)} KB)`);
  }

  async function run(instruction: string) {
    if (!instruction.trim() || busy || !user) return;
    setBusy(true); setPhase("classified");
    const nextTurns: Turn[] = [...turns, { role: "user", text: instruction }]; setTurns(nextTurns); setPrompt("");
    log("info", `$ omni ${html ? "edit" : "create"} — "${instruction.slice(0, 80)}"`);
    const t = performance.now();
    try {
      setPhase("routed"); log("info", "Sending request to the builder model…");
      const r = await build({ data: { kind, prompt: instruction, html } });
      setPhase("streaming");
      log("ok", `Received ${r.html.length.toLocaleString()} characters in ${((performance.now() - t) / 1000).toFixed(1)}s`);
      const nextTitle = projectId ? title : instruction.slice(0, 60); setTitle(nextTitle);
      const done: Turn[] = [...nextTurns, { role: "ai", text: html ? "Applied your changes." : "Built the first version." }];
      setTurns(done); setHtml(r.html); setTab("preview"); log("info", "Mounting live preview…");
      await save(r.html, done, nextTitle); setPhase("succeeded");
    } catch (e) {
      setPhase("failed"); const m = e instanceof Error ? e.message : "Build failed."; log("error", m); toast.error(m);
      void notify({ data: { event: "compilation", key: crypto.randomUUID() } }).catch(() => {});
    } finally { setBusy(false); }
  }

  function open(p: { id: string; title: string; content: string | null; state: unknown }) {
    setProjectId(p.id); setTitle(p.title); setHtml(p.content ?? ""); setLogs([{ at: now(), level: "info", text: `Opened "${p.title}"` }]);
    const s = p.state as { turns?: Turn[] } | null; setTurns(s?.turns ?? []);
  }
  function fresh() { setProjectId(null); setTitle("Untitled project"); setHtml(""); setTurns([]); setLogs([]); }
  const errors = logs.filter((l) => l.level === "error");
  useStudioActions([
    { name: "builder_describe", description: "Read the current project: title, whether a page exists, its HTML length, recent terminal errors and saved project titles.", run: () => JSON.stringify({ title, hasPage: !!html, htmlChars: html.length, errors: errors.slice(-5).map((e) => e.text), projects: projects.data?.map((p) => p.title) ?? [] }) },
    { name: "builder_build", description: "Build a new site/app or apply a change to the current one. Runs the real builder, updates the live preview and auto-saves. Write a detailed instruction.", args: `{ "instruction": string }`, run: async (a) => { const i = String(a.instruction ?? "").trim(); if (!i) throw new Error("Missing instruction."); await run(i); return "Build finished — preview updated and saved."; } },
    { name: "builder_autofix", description: "Fix the runtime errors currently shown in the terminal.", run: async () => { if (!errors.length) return "No errors to fix."; await run(`Fix these runtime errors without changing the design:\n${errors.slice(-5).map((e) => e.text).join("\n")}`); return "Fix applied."; } },
    { name: "builder_view", description: "Switch the main panel to preview or code, and/or device to desktop or mobile.", args: `{ "tab"?: "preview"|"code", "device"?: "desktop"|"mobile" }`, run: (a) => { if (a.tab === "preview" || a.tab === "code") setTab(a.tab); if (a.device === "desktop" || a.device === "mobile") setDevice(a.device); return "View updated."; } },
    { name: "builder_open_project", description: "Open a saved project by title.", args: `{ "title": string }`, run: (a) => { const p = projects.data?.find((x) => x.title.toLowerCase().includes(String(a.title).toLowerCase())); if (!p) throw new Error("Project not found."); open(p); return `Opened ${p.title}.`; } },
    { name: "builder_new_project", description: "Start a blank new project.", run: () => { fresh(); return "New project started."; } },
    { name: "builder_save", description: "Save the current project.", run: async () => { if (!html) throw new Error("Nothing to save yet."); await save(html, turns, title); return "Saved."; } },
  ]);

  if (!user) return <div className="grid h-full place-items-center"><Button asChild><Link to="/auth">Sign in to build and save projects</Link></Button></div>;
  return <div className="forge-layout flex h-full min-w-0 max-w-full flex-col gap-2 overflow-hidden p-2">
    {/* Chat + projects */}
    <section className="forge-chat holo hud-corners flex min-h-0 min-w-0 w-full shrink-0 flex-col overflow-hidden">
      <div className="flex items-center gap-2 border-b p-3"><Sparkles className="size-4 text-primary" /><input aria-label="Project name" value={title} onChange={(e) => setTitle(e.target.value)} onBlur={() => { if (projectId) void save(html, turns, title).catch((e) => toast.error(String(e))); }} className="min-w-0 flex-1 bg-transparent font-display text-sm outline-none" /><Button size="icon-sm" variant="outline" title="New project" onClick={fresh}><FilePlus2 /></Button></div>
      <div className="min-h-0 flex-1 space-y-2 overflow-y-auto p-3 text-sm">
        {turns.length === 0 && <div className="space-y-3"><p className="text-muted-foreground">Describe the {kind === "app-builder" ? "app" : kind === "code" ? "program" : "website"} you want. Then keep chatting to change it.</p>
          {!!projects.data?.length && <div><p className="mb-1 text-xs uppercase tracking-wider text-muted-foreground">Your projects</p>{projects.data.map((p) => <button key={p.id} onClick={() => open(p)} className="extrude mb-1 block w-full truncate rounded px-2 py-1.5 text-left">{p.title}</button>)}</div>}</div>}
        {turns.map((t, i) => <div key={i} className={`rounded-lg px-3 py-2 ${t.role === "user" ? "ml-6 bg-primary/15" : "mr-6 bg-secondary"}`}>{t.text}</div>)}
        {busy && <div className="mr-6 flex items-center gap-2 rounded-lg bg-secondary px-3 py-2 text-muted-foreground"><Loader2 className="size-4 animate-spin" />Building…</div>}
      </div>
      <form className="space-y-2 border-t p-3" onSubmit={(e) => { e.preventDefault(); void run(prompt); }}>
        <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={3} placeholder={html ? "Ask for a change…" : "A landing page for a coffee shop with menu and booking form"} aria-label="Builder prompt" onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void run(prompt); } }} className="w-full resize-none rounded-md border bg-background/60 p-2 text-sm outline-none focus:border-primary/60" />
        <div className="flex gap-2"><EnhanceButton value={prompt} onChange={setPrompt} studio={kind} disabled={busy} /><Button className="ml-auto" size="sm" disabled={busy || !prompt.trim()}>{busy ? <Loader2 className="animate-spin" /> : <Send />}{html ? "Update" : "Build"}</Button></div>
      </form>
    </section>
    {/* Preview / code + terminal */}
    <section className="flex min-h-0 min-w-0 flex-1 flex-col gap-2 overflow-hidden">
      <div className={`holo hud-corners flex min-h-0 flex-1 flex-col overflow-hidden ${busy ? "glow-active hud-trace" : ""}`}>
        <div className="flex flex-wrap items-center gap-1 border-b p-2">
          <Button size="sm" variant={tab === "preview" ? "default" : "ghost"} onClick={() => setTab("preview")}><Eye />Preview</Button>
          <Button size="sm" variant={tab === "code" ? "default" : "ghost"} onClick={() => setTab("code")}><Code2 />Code</Button>
          <div className="ml-auto flex gap-1">
            <Button size="icon-sm" variant={device === "desktop" ? "secondary" : "ghost"} title="Desktop" onClick={() => setDevice("desktop")}><Monitor /></Button>
            <Button size="icon-sm" variant={device === "mobile" ? "secondary" : "ghost"} title="Phone" onClick={() => setDevice("mobile")}><Smartphone /></Button>
            <Button size="icon-sm" variant="ghost" title="Download HTML" disabled={!html} onClick={() => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([html], { type: "text/html" })); a.download = `${title.replace(/[^\w-]+/g, "-") || "omni"}.html`; a.click(); }}><Download /></Button>
          </div>
        </div>
        <div className="min-h-0 flex-1 overflow-hidden bg-background">
          {!html ? <div className="grid h-full place-items-center text-sm text-muted-foreground">{busy ? "Generating your first version…" : "Your live preview appears here."}</div>
            : tab === "preview" ? <div className="flex h-full justify-center overflow-auto p-2"><iframe ref={frame} title="Live preview" sandbox="allow-scripts allow-forms allow-modals allow-popups" srcDoc={srcDoc} className={`h-full rounded-md border bg-card ${device === "mobile" ? "w-[390px] max-w-full" : "w-full"}`} /></div>
            : <div className="flex h-full min-h-0">
                <nav aria-label="Project files" className="w-44 shrink-0 overflow-y-auto border-r bg-card/40 p-2 text-xs">
                  <span className="hud-label mb-1 flex items-center gap-1 text-primary"><FolderOpen className="size-3 shrink-0" /><span className="truncate">{title || "project"}</span></span>
                  {FILE_NAMES.map((n) => <button key={n} onClick={() => setFile(n)} className={`extrude mb-1 flex w-full items-center gap-2 rounded px-2 py-1.5 text-left font-mono ${file === n ? "bg-primary/15 text-foreground" : "text-muted-foreground"}`}><FileCode2 className="size-3.5 text-primary" /><span className="truncate">{n}</span><span className="ml-auto opacity-50">{(files[n].length / 1024).toFixed(1)}k</span></button>)}
                </nav>
                <textarea aria-label={`Edit ${file}`} value={files[file]} onChange={(e) => setHtml(joinSite({ ...files, [file]: e.target.value }))} onBlur={() => projectId && void save(html, turns, title).catch((e) => toast.error(String(e)))} spellCheck={false} className="h-full min-w-0 flex-1 resize-none bg-transparent p-4 font-mono text-xs leading-5 outline-none" />
              </div>}
        </div>
      </div>
      <div className="holo scanline flex h-48 shrink-0 flex-col overflow-hidden">
        <div className="flex items-center gap-2 border-b px-3 py-1.5 text-xs"><span className="font-display uppercase tracking-widest text-primary">Terminal</span><span className="text-muted-foreground">{errors.length ? `${errors.length} error${errors.length > 1 ? "s" : ""}` : "no errors"}</span>
          {errors.length > 0 && <Button size="xs" variant="outline" className="ml-auto" disabled={busy} onClick={() => void run(`Fix these runtime errors without changing the design:\n${errors.slice(-5).map((e) => e.text).join("\n")}`)}><Wrench />AI Auto-fix</Button>}
          <Button size="xs" variant="ghost" className={errors.length ? "" : "ml-auto"} onClick={() => setLogs([])}>Clear</Button></div>
        <div className="min-h-0 flex-1 overflow-y-auto p-2 font-mono text-xs leading-5">
          {logs.length === 0 && <p className="text-muted-foreground">Waiting for activity…</p>}
          {logs.map((l, i) => <div key={i} className={l.level === "error" ? "text-destructive" : l.level === "warn" ? "text-accent-foreground" : l.level === "ok" ? "text-success" : "text-muted-foreground"}><span className="opacity-50">{l.at} </span>{l.text}</div>)}
          <div ref={termEnd} />
        </div>
      </div>
    </section>
  </div>;
}
