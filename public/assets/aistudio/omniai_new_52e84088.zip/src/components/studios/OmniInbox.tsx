import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { Loader2, Inbox, MailWarning, Clock, CheckCircle2, Plug } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { askModel } from "@/lib/ai.functions";
import { useAccount } from "@/components/AccountProvider";

type Ranked = { subject: string; priority: "urgent" | "soon" | "later"; reason: string; followUp: string };

function parseRanked(text: string): Ranked[] {
  const m = text.match(/\[[\s\S]*\]/);
  if (!m) return [];
  try {
    const arr = JSON.parse(m[0]) as Partial<Ranked>[];
    return arr.filter((r) => r.subject).map((r) => ({
      subject: String(r.subject).slice(0, 200),
      priority: r.priority === "urgent" || r.priority === "soon" ? r.priority : "later",
      reason: String(r.reason ?? "").slice(0, 300),
      followUp: String(r.followUp ?? "").slice(0, 1000),
    }));
  } catch { return []; }
}

const ICONS = { urgent: MailWarning, soon: Clock, later: CheckCircle2 } as const;

export function OmniInbox() {
  const { user } = useAccount();
  const ask = useServerFn(askModel);
  const [emails, setEmails] = useState("");
  const [busy, setBusy] = useState(false);
  const [ranked, setRanked] = useState<Ranked[]>([]);

  if (!user) return <div className="grid h-full place-items-center p-6"><Button asChild><Link to="/auth">Sign in to prioritize your inbox</Link></Button></div>;

  const run = async () => {
    if (!emails.trim() || busy) return;
    setBusy(true); setRanked([]);
    try {
      const r = await ask({ data: { model: "openai/gpt-6-astra", messages: [{ role: "user", content: emails.slice(0, 12000) }], system: `You triage email. Reply with ONLY a JSON array, one object per email: [{"subject":"...","priority":"urgent|soon|later","reason":"one line","followUp":"a ready-to-send follow-up draft"}]. Order most urgent first.` } });
      const parsed = parseRanked(r.text);
      if (!parsed.length) throw new Error("Couldn't parse the triage result — try again.");
      setRanked(parsed);
    } catch (e) { toast.error(e instanceof Error ? e.message : "Triage failed."); }
    finally { setBusy(false); }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-hidden p-4">
      <div className="grid min-h-0 flex-1 gap-3 lg:grid-cols-2">
        <section className="holo hud-corners flex flex-col gap-3 p-4">
          <span className="hud-label"><Inbox className="mr-1 inline size-3" />Inbox intake</span>
          <p className="text-xs text-muted-foreground">Paste recent emails (subject + a line or two each) and Omni ranks them and drafts the follow-ups. Live Gmail / Outlook sync arrives through Omni Connect.</p>
          <textarea value={emails} onChange={(e) => setEmails(e.target.value)} rows={10} aria-label="Emails to triage"
            placeholder={"Subject: Invoice #1042 overdue\nClient asking when the payment link arrives…\n\nSubject: Re: Demo next week\nCan we move it to Thursday?…"}
            className="w-full flex-1 resize-none rounded-md border bg-background/60 p-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="bevel" asChild><Link to="/studio/$id" params={{ id: "connectors" }}><Plug />Connect Gmail / Outlook</Link></Button>
            <Button size="sm" className="ml-auto bevel" disabled={busy || !emails.trim()} onClick={() => void run()}>{busy ? <Loader2 className="animate-spin" /> : <Inbox />}Prioritize & draft follow-ups</Button>
          </div>
        </section>
        <section className="holo hud-corners flex min-h-0 flex-col gap-2 p-4">
          <span className="hud-label">Prioritized queue</span>
          <div className="min-h-0 flex-1 space-y-2 overflow-y-auto">
            {busy && <span className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" /> Triaging…</span>}
            {!busy && ranked.length === 0 && <p className="text-sm text-muted-foreground">Ranked emails with follow-up drafts appear here.</p>}
            {ranked.map((r, i) => {
              const Icon = ICONS[r.priority];
              return (
                <div key={i} className={`rounded-md border p-3 ${r.priority === "urgent" ? "border-destructive/50 bg-destructive/10" : r.priority === "soon" ? "border-primary/40 bg-primary/5" : "border-border bg-background/50"}`}>
                  <p className="flex items-center gap-2 text-sm font-semibold"><Icon className={`size-4 ${r.priority === "urgent" ? "text-destructive" : r.priority === "soon" ? "text-primary" : "text-success"}`} />{r.subject}<span className="ml-auto font-mono text-[10px] uppercase text-muted-foreground">{r.priority}</span></p>
                  <p className="mt-1 text-xs text-muted-foreground">{r.reason}</p>
                  {r.followUp && <div className="recessed mt-2 whitespace-pre-wrap p-2 text-xs">{r.followUp}</div>}
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </div>
  );
}
