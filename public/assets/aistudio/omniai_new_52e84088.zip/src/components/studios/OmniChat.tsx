import { useEffect, useRef, useState } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, lastAssistantMessageIsCompleteWithApprovalResponses, type UIMessage, isToolUIPart } from "ai";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link, useNavigate } from "@tanstack/react-router";
import { Plus, Pencil, Trash2, Brain, GitFork, Clapperboard, ImagePlus, X, Film, Menu, Cpu } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { listThreads, newThread, renameThread, deleteThread } from "@/lib/private.functions";
import { Button } from "@/components/ui/button";
import { AccountControl } from "@/components/AccountProvider";
import { Conversation, ConversationContent, ConversationScrollButton } from "@/components/ai-elements/conversation";
import { Message, MessageContent, MessageResponse } from "@/components/ai-elements/message";
import { PromptInput, PromptInputTextarea, PromptInputFooter, PromptInputSubmit, PromptInputHeader, PromptInputButton, usePromptInputAttachments } from "@/components/ai-elements/prompt-input";
import { EnhanceButton, MEDIA_ACCEPT, MAX_FILES, MAX_VIDEO_BYTES } from "@/components/MediaComposer";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { Tool, ToolHeader, ToolContent, ToolInput, ToolOutput } from "@/components/ai-elements/tool";
import { toast } from "sonner";
import { HoloOrb } from "@/components/HoloOrb";
import { useWorkspaceState } from "@/components/WorkspaceStateProvider";
import { OmniStatusGauge } from "@/components/OmniStatusGauge";

export function OmniChat({ threadId, initialMessages }: { threadId: string; initialMessages: UIMessage[] }) {
  const { phase, setPhase } = useWorkspaceState();
  const [director, setDirector] = useState(false), [council, setCouncil] = useState(false), [input, setInput] = useState("");
  const textarea = useRef<HTMLTextAreaElement>(null); const modes = useRef({ director, council }); modes.current = { director, council };
  const navigate = useNavigate(), qc = useQueryClient(); const list = useServerFn(listThreads), create = useServerFn(newThread), rename = useServerFn(renameThread), remove = useServerFn(deleteThread);
  const threads = useQuery({ queryKey: ["threads"], queryFn: () => list() });
  const [transport] = useState(() => new DefaultChatTransport({ api: "/api/chat", fetch: async (url, options) => { setPhase("routed"); return fetch(url, options); }, body: () => ({ threadId, ...modes.current }), headers: async () => { const { data } = await supabase.auth.getSession(); return data.session ? { Authorization: `Bearer ${data.session.access_token}` } : {}; } }));
  const { messages, sendMessage, status, stop, error, addToolApprovalResponse } = useChat({ id: threadId, messages: initialMessages, transport, sendAutomaticallyWhen: lastAssistantMessageIsCompleteWithApprovalResponses, onError: (e) => { setPhase("failed"); toast.error(e.message); }, onFinish: ({ isAbort, isError }) => { setPhase(isError ? "failed" : isAbort ? "idle" : "succeeded"); void qc.invalidateQueries({ queryKey: ["threads"] }); void qc.invalidateQueries({ queryKey: ["memories"] }); } });
  useEffect(() => { if (status === "streaming") setPhase("streaming"); if (status === "error") setPhase("failed"); }, [status, setPhase]);
  useEffect(() => () => setPhase("idle"), [setPhase, threadId]);
  const busy = status === "submitted" || status === "streaming";
  useEffect(() => { if (!busy) textarea.current?.focus(); }, [busy, threadId]);
  async function openNew() { try { const t = await create(); await qc.invalidateQueries({ queryKey: ["threads"] }); await navigate({ to: "/chat/$threadId", params: { threadId: t.id } }); } catch (e) { toast.error(String(e)); } }
  const mode = director ? "director" : council ? "council" : "standard";
  const setMode = (m: string) => { setDirector(m === "director"); setCouncil(m === "council"); };
  const [drawer, setDrawer] = useState(false);
  const threadList = <nav className="min-h-0 flex-1 overflow-y-auto space-y-1 pr-1">{threads.data?.map((t) => <div key={t.id} className={`group flex items-center gap-1 rounded-md border border-transparent ${t.id === threadId ? "border-primary/40 bg-primary/10" : "hover:border-border"}`}><Button variant="ghost" disabled={busy} className="min-w-0 flex-1 justify-start truncate shadow-none" onClick={() => { setDrawer(false); void navigate({ to: "/chat/$threadId", params: { threadId: t.id } }); }}><span className="truncate">{t.title}</span></Button><Button title="Rename conversation" aria-label="Rename conversation" variant="ghost" size="icon-xs" disabled={busy} onClick={async () => { const title = window.prompt("Conversation name", t.title); if (!title?.trim()) return; try { await rename({ data: { id: t.id, title } }); await qc.invalidateQueries({ queryKey: ["threads"] }); } catch (e) { toast.error(String(e)); } }}><Pencil /></Button><Button title="Delete conversation" aria-label="Delete conversation" variant="ghost" size="icon-xs" disabled={busy} onClick={async () => { if (!window.confirm("Delete this conversation and its memories?")) return; try { await remove({ data: { id: t.id } }); await qc.invalidateQueries({ queryKey: ["threads"] }); if (t.id === threadId) await openNew(); } catch (e) { toast.error(String(e)); } }}><Trash2 /></Button></div>)}</nav>;
  const working = phase !== "idle" && phase !== "succeeded" && phase !== "failed";
  return <div className="flex h-full flex-col gap-2 overflow-hidden p-2">
    <header className="holo grid shrink-0 grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-3 py-2 md:grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)]">
      <div className="flex min-w-0 items-center gap-3"><Button variant="outline" size="icon" aria-label="Conversations" onClick={() => setDrawer((d) => !d)}><Menu /></Button><Link to="/" className="font-display text-lg font-bold text-brand">OmniAI</Link><span className="hud-label hidden truncate sm:inline">/ Neural chat</span></div>
      <div className="hud-chip hidden items-center gap-2 md:flex"><span className={`size-2 rounded-full ${phase === "failed" ? "bg-destructive" : working ? "bg-primary animate-pulse" : "bg-success"}`} />{PHASE_LABEL[phase] ?? phase}</div>
      <div className="flex items-center justify-end gap-2"><span className="hud-chip hidden xl:inline">Core online</span><AccountControl /></div>
    </header>
    <div className="relative flex min-h-0 flex-1 gap-2">
      <aside aria-label="Permanent OmniAI sidebar" className="holo flex w-28 shrink-0 flex-col gap-3 overflow-y-auto p-2 sm:w-56 sm:p-3 md:w-64 xl:w-72">
        <div className="flex items-center justify-between"><span className="hud-label text-primary">Omni · Neural core</span><span className="hud-label">v1</span></div>
        <OmniStatusGauge />
        <div className="mt-auto flex shrink-0 flex-wrap gap-2"><Button size="sm" className="flex-1" onClick={() => void openNew()} disabled={busy}><Plus />New</Button><Button asChild variant="outline" size="icon" title="Private memory"><Link to="/account" aria-label="Private memory"><Brain /></Link></Button></div>
      </aside>
      {drawer && <aside aria-label="Conversations drawer" className="holo absolute inset-y-0 left-0 z-30 flex w-[min(320px,100%)] flex-col gap-3 p-3"><div className="flex items-center justify-between"><span className="hud-label">Conversations</span><Button variant="ghost" size="icon" aria-label="Close conversations" onClick={() => setDrawer(false)}><X /></Button></div>{threadList}</aside>}
      <main className={`holo hud-corners min-w-0 flex-1 flex flex-col overflow-hidden ${busy ? "hud-trace" : ""}`}>
        <div className="flex shrink-0 items-center justify-between border-b px-4 py-2"><div className="flex items-center gap-2 text-sm"><div className="recessed size-9 shrink-0 p-0.5 lg:hidden"><HoloOrb /></div><span className={`size-2 rounded-full ${busy ? "bg-primary animate-pulse" : "bg-success"}`} />{busy ? "Processing" : "Ready"}</div><span className="hud-label">{messages.length} msg</span></div>
        <Conversation className="min-h-0 flex-1"><ConversationContent className="mx-auto w-full max-w-3xl p-5">{messages.length === 0 && <div className="flex flex-col items-center py-16 text-center"><div className="recessed grid size-16 place-items-center"><Cpu className="size-7 text-primary" /></div><h2 className="mt-5 font-display text-3xl">What are we building today?</h2><p className="mt-3 max-w-md text-muted-foreground">Ask anything, drop in images or video, or switch on AI Director to have OmniAI run the studios for you.</p><div className="mt-6 flex flex-wrap justify-center gap-2">{["Plan a music video", "Explain something technical", "Brainstorm creative ideas"].map((s) => <Button key={s} variant="outline" onClick={() => { setInput(s); textarea.current?.focus(); }}>{s}</Button>)}</div></div>}{messages.map((message) => <Message key={message.id} from={message.role}><MessageContent className={message.role === "user" ? "group-[.is-user]:bg-primary group-[.is-user]:text-primary-foreground" : ""}>{message.parts.map((part, i) => {
          if (part.type === "text") return <MessageResponse key={i}>{part.text}</MessageResponse>;
          if (part.type === "file") return part.mediaType.startsWith("video/") ? <video key={i} src={part.url} controls className="max-h-64 max-w-full rounded-md" /> : part.mediaType.startsWith("image/") ? <img key={i} src={part.url} alt={part.filename ?? "Attached image"} className="max-h-64 max-w-full rounded-md" /> : null;
          if (part.type === "reasoning") return <details key={i} className="text-xs text-muted-foreground"><summary>Thinking</summary><MessageResponse>{part.text}</MessageResponse></details>;
          if (isToolUIPart(part)) return <div key={i}><Tool defaultOpen={false}><ToolHeader type="dynamic-tool" toolName="createStudioWork" state={part.state} title="Create studio work" /><ToolContent><ToolInput input={part.input} /><ToolOutput output={part.state === "output-available" ? part.output : undefined} errorText={part.state === "output-error" ? part.errorText : undefined}/></ToolContent></Tool>{part.state === "approval-requested" && <div className="flex gap-2 py-2"><Button size="sm" onClick={() => void addToolApprovalResponse({ id: part.approval.id, approved: true })}>Approve generation</Button><Button size="sm" variant="outline" onClick={() => void addToolApprovalResponse({ id: part.approval.id, approved: false })}>Cancel</Button></div>}{part.state === "output-available" && typeof part.output === "object" && part.output !== null && "studio" in part.output ? <Button asChild variant="link" size="sm"><Link to="/studio/$id" params={{ id: String(part.output.studio) }}>Open studio</Link></Button> : null}</div>;
          return null;
        })}</MessageContent></Message>)}{status === "submitted" && <Shimmer>Thinking…</Shimmer>}{error && <p role="alert" className="text-sm text-destructive">{error.message}</p>}</ConversationContent><ConversationScrollButton /></Conversation>
      </main>
    </div>
    <section className="holo shrink-0 p-3">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2"><span className="hud-label">Intelligence mode</span><div role="radiogroup" aria-label="Intelligence mode" className="flex gap-2">{([["standard", "OmniAI", Cpu], ["council", "Council", GitFork]] as const).map(([id, label, Icon]) => <Button key={id} role="radio" aria-checked={mode === id} size="sm" disabled={busy} variant={mode === id ? "default" : "outline"} onClick={() => { setCouncil(id === "council"); if (id === "council") setDirector(false); }}><Icon />{label}</Button>)}<Button title="AI Director" aria-label="AI Director" aria-pressed={director} size="icon-sm" disabled={busy || council} variant={director ? "default" : "outline"} onClick={() => setDirector((d) => !d)}><Clapperboard /></Button></div></div>
      <PromptInput accept={MEDIA_ACCEPT} multiple maxFiles={MAX_FILES} maxFileSize={MAX_VIDEO_BYTES} globalDrop onError={(e) => toast.error(e.message)} onSubmit={({ text, files }) => { if (!text.trim() || busy) return; setPhase("classified"); void sendMessage({ text, files }); setInput(""); textarea.current?.focus(); }}><PromptInputHeader><AttachmentChips /></PromptInputHeader><PromptInputTextarea ref={textarea} value={input} onChange={(e) => setInput(e.target.value)} placeholder="Message OmniAI…" aria-label="Message OmniAI" autoFocus /><PromptInputFooter className="justify-between"><div className="flex items-center gap-2"><AttachButton /><EnhanceButton value={input} onChange={setInput} studio="chat" disabled={busy} /></div><span className="hud-label hidden sm:inline">{director ? "Director · approval required" : council ? "Council · multi-model" : "Standard"}</span><PromptInputSubmit status={status} onStop={() => { stop(); setPhase("idle"); }} disabled={!busy && !input.trim()} /></PromptInputFooter></PromptInput>
    </section>
  </div>;
}

const PHASE_LABEL: Record<string, string> = { idle: "Standing by", classified: "Understanding your request", routed: "Contacting models", streaming: "Thinking & responding", succeeded: "Response complete", failed: "Something went wrong" };

function AttachButton() {
  const a = usePromptInputAttachments();
  return <PromptInputButton variant="outline" title="Add images or videos" onClick={() => a.openFileDialog()}><ImagePlus />Media</PromptInputButton>;
}

function AttachmentChips() {
  const a = usePromptInputAttachments();
  if (!a.files.length) return null;
  return <div className="flex flex-wrap gap-2 p-2">{a.files.map((f) => <div key={f.id} className="relative size-14 overflow-hidden rounded-md border border-primary/30">
    {f.mediaType?.startsWith("video/") ? <><video src={f.url} muted className="size-full object-cover" /><Film className="absolute bottom-1 left-1 size-3 text-primary" /></> : <img src={f.url} alt={f.filename ?? "attachment"} className="size-full object-cover" />}
    <button type="button" aria-label="Remove attachment" onClick={() => a.remove(f.id)} className="absolute right-0.5 top-0.5 rounded-full bg-background/80 p-0.5"><X className="size-3" /></button>
  </div>)}</div>;
}
