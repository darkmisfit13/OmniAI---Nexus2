import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Upload, Play, Pause, Scissors, Trash2, Type, Film, Music2, Save, Download, Loader2, FilePlus2, Image as ImageIcon, Copy } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAccount } from "@/components/AccountProvider";
import { Button } from "@/components/ui/button";
import { CURVES, curveRate, FILTERS, clipDuration, type Clip, type Curve } from "@/lib/editor";
import { useStudioActions } from "@/lib/studio-actions";

type Media = { id: string; name: string; type: "video" | "image" | "audio"; path: string; duration: number; url?: string | undefined };
type TextLayer = { id: string; text: string; start: number; end: number; x: number; y: number; size: number; color: string; anim: "none" | "fade" | "pop" };
type Ratio = "16:9" | "9:16" | "1:1";
const RATIOS: Record<Ratio, [number, number]> = { "16:9": [1280, 720], "9:16": [720, 1280], "1:1": [1080, 1080] };
const TABS = ["Basic", "Speed", "Adjust", "Filters", "Cutout", "Audio", "Animation", "Text"] as const;
const uid = () => crypto.randomUUID();

function Slider({ label, value, set, min = 0, max = 100, step = 1, unit = "" }: { label: string; value: number; set: (n: number) => void; min?: number; max?: number; step?: number; unit?: string }) {
  return <label className="block text-xs"><div className="mb-1 flex justify-between text-muted-foreground"><span>{label}</span><span className="text-primary">{value}{unit}</span></div>
    <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => set(+e.target.value)} className="w-full accent-[var(--primary)]" /></label>;
}
const newClip = (m: Media): Clip => ({ id: uid(), mediaId: m.id, in: 0, out: m.type === "image" ? 3 : m.duration, speed: 1, curve: "none", volume: 100, fadeIn: 0, fadeOut: 0, scale: 100, x: 0, y: 0, rotate: 0, opacity: 100, bright: 100, contrast: 100, sat: 100, hue: 0, blur: 0, filter: "None", chroma: false, chromaColor: "#00ff00", chromaSim: 40, anim: "none" });
const hex = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16)) as [number, number, number];

export function OmniMotion({ sourceProjectId, sourceProductionId }: { sourceProjectId?: string | undefined; sourceProductionId?: string | undefined } = {}) {
  const { user } = useAccount(); const qc = useQueryClient();
  const [projectId, setProjectId] = useState<string | null>(null); const [title, setTitle] = useState("Untitled edit");
  const [media, setMedia] = useState<Media[]>([]); const [clips, setClips] = useState<Clip[]>([]); const [texts, setTexts] = useState<TextLayer[]>([]);
  const [music, setMusic] = useState<{ mediaId: string; volume: number } | null>(null);
  const [ratio, setRatio] = useState<Ratio>("16:9"); const [sel, setSel] = useState<string | null>(null); const [selText, setSelText] = useState<string | null>(null);
  const [tab, setTab] = useState<(typeof TABS)[number]>("Basic"); const [t, setT] = useState(0); const [playing, setPlaying] = useState(false);
  const [uploading, setUploading] = useState(0); const [saving, setSaving] = useState(false); const [exporting, setExporting] = useState(false);
  const canvas = useRef<HTMLCanvasElement>(null), video = useRef<HTMLVideoElement>(null), audio = useRef<HTMLAudioElement>(null), fileInput = useRef<HTMLInputElement>(null);
  const tRef = useRef(0), playRef = useRef(false), images = useRef(new Map<string, HTMLImageElement>()), keyCanvas = useRef<HTMLCanvasElement | null>(null);
  const audioCtx = useRef<{ ctx: AudioContext; dest: MediaStreamAudioDestinationNode } | null>(null), recorder = useRef<MediaRecorder | null>(null);
  const state = useRef({ media, clips, texts, music, ratio }); state.current = { media, clips, texts, music, ratio };

  const layout = (cs: Clip[]) => { let s = 0; return cs.map((c) => { const d = clipDuration(c); const r = { c, start: s, dur: d }; s += d; return r; }); };
  const placed = layout(clips); const total = placed.reduce((a, p) => a + p.dur, 0);
  const clip = clips.find((c) => c.id === sel) ?? null; const text = texts.find((x) => x.id === selText) ?? null;
  const update = (patch: Partial<Clip>) => sel && setClips((cs) => cs.map((c) => c.id === sel ? { ...c, ...patch } : c));
  const updateText = (patch: Partial<TextLayer>) => selText && setTexts((ts) => ts.map((x) => x.id === selText ? { ...x, ...patch } : x));

  const projects = useQuery({ queryKey: ["edits", user?.id], enabled: !!user, queryFn: async () => {
    const r = await supabase.from("studio_projects").select("id,title,state,created_at").eq("studio", "video").eq("kind", "edit").order("created_at", { ascending: false });
    if (r.error) throw r.error; return r.data;
  } });

  useEffect(() => {
    if (!sourceProjectId || !user) return;
    let active = true;
    void (async () => {
      const r = await supabase.from("studio_projects").select("title,asset_path").eq("id", sourceProjectId).eq("kind", "video").single();
      if (r.error || !r.data.asset_path) throw new Error("Saved video could not be opened.");
      const signed = await supabase.storage.from("studio-assets").createSignedUrl(r.data.asset_path, 3600);
      if (signed.error) throw signed.error;
      const duration = await new Promise<number>((resolve, reject) => { const v = document.createElement("video"); v.onloadedmetadata = () => resolve(v.duration); v.onerror = () => reject(new Error("Video could not be decoded.")); v.src = signed.data.signedUrl; });
      if (!active) return;
      const m: Media = { id: uid(), name: r.data.title, type: "video", path: r.data.asset_path, duration, url: signed.data.signedUrl };
      setTitle(r.data.title); setMedia([m]); setClips([newClip(m)]); setSel(null); setTexts([]); setMusic(null); setProjectId(null);
    })().catch((e: Error) => { if (active) toast.error(e.message); });
    return () => { active = false; };
  }, [sourceProjectId, user]);

  useEffect(() => {
    if (!sourceProductionId || !user) return;
    let active = true;
    void (async () => {
      const r = await supabase.from("studio_projects").select("title,state").eq("id", sourceProductionId).eq("kind", "music-production").single();
      if (r.error) throw new Error("Music video could not be opened.");
      const st = r.data.state as { track?: { path: string; name: string }; clips?: { path?: string; seconds?: number }[] };
      const scenes = (st.clips ?? []).filter((c): c is { path: string; seconds?: number } => !!c.path);
      if (!scenes.length) throw new Error("This music video has no finished scenes yet.");
      const sign = async (path: string) => { const s = await supabase.storage.from("studio-assets").createSignedUrl(path, 3600); if (s.error) throw s.error; return s.data.signedUrl; };
      const probe = (url: string, kind: "video" | "audio", fallback: number) => new Promise<number>((resolve) => { const el = document.createElement(kind); el.preload = "metadata"; el.onloadedmetadata = () => resolve(Number.isFinite(el.duration) && el.duration > 0 ? el.duration : fallback); el.onerror = () => resolve(fallback); el.src = url; });
      const ms: Media[] = await Promise.all(scenes.map(async (c, i) => { const url = await sign(c.path); return { id: uid(), name: `Scene ${i + 1}`, type: "video" as const, path: c.path, duration: await probe(url, "video", c.seconds ?? 8), url }; }));
      let song: Media | null = null;
      if (st.track?.path) { const url = await sign(st.track.path); song = { id: uid(), name: st.track.name || "Track", type: "audio", path: st.track.path, duration: await probe(url, "audio", 30), url }; }
      if (!active) return;
      const title = r.data.title || "Music video";
      setTitle(`${title} · edit`); setMedia(song ? [...ms, song] : ms); setClips(ms.map(newClip)); setSel(null);
      setTexts([{ id: uid(), text: title.slice(0, 40), start: 0, end: 3, x: 50, y: 80, size: 56, color: "#00f2fe", anim: "fade" }]);
      setMusic(song ? { mediaId: song.id, volume: 90 } : null); setProjectId(null);
      toast.success(`Loaded ${ms.length} scenes${song ? " and your song" : ""} into the editor`);
    })().catch((e: Error) => { if (active) toast.error(e.message); });
    return () => { active = false; };
  }, [sourceProductionId, user]);

  async function importFiles(files: FileList | null) {
    if (!files || !user) return;
    for (const f of Array.from(files)) {
      const type = f.type.startsWith("video/") ? "video" : f.type.startsWith("image/") ? "image" : f.type.startsWith("audio/") ? "audio" : null;
      if (!type) { toast.error(`${f.name} isn't a video, image or audio file.`); continue; }
      setUploading((n) => n + 1);
      try {
        const local = URL.createObjectURL(f);
        const duration = type === "image" ? 3 : await new Promise<number>((res) => { const el = document.createElement(type === "video" ? "video" : "audio"); el.preload = "metadata"; el.onloadedmetadata = () => res(el.duration || 3); el.onerror = () => res(3); el.src = local; });
        const path = `${user.id}/editor/${uid()}-${f.name.replace(/[^\w.-]+/g, "_")}`;
        const up = await supabase.storage.from("studio-assets").upload(path, f, { contentType: f.type });
        if (up.error) throw up.error;
        const m: Media = { id: uid(), name: f.name, type, path, duration, url: local };
        setMedia((all) => [...all, m]);
        if (type === "audio") setMusic((cur) => cur ?? { mediaId: m.id, volume: 80 }); else setClips((cs) => [...cs, newClip(m)]);
      } catch (e) { toast.error(`${f.name}: ${e instanceof Error ? e.message : "upload failed"}`); } finally { setUploading((n) => n - 1); }
    }
  }

  async function save() {
    if (!user) return; setSaving(true);
    try {
      const s = state.current; const row = { studio: "video", kind: "edit", title, state: JSON.parse(JSON.stringify({ media: s.media.map(({ url: _u, ...m }) => m), clips: s.clips, texts: s.texts, music: s.music, ratio: s.ratio })) };
      const r = projectId ? await supabase.from("studio_projects").update(row).eq("id", projectId).select("id").single() : await supabase.from("studio_projects").insert({ ...row, user_id: user.id }).select("id").single();
      if (r.error) throw r.error; setProjectId(r.data.id); void qc.invalidateQueries({ queryKey: ["edits"] }); toast.success("Edit saved to your account");
    } catch (e) { toast.error(e instanceof Error ? e.message : "Save failed"); } finally { setSaving(false); }
  }
  async function open(p: { id: string; title: string; state: unknown }) {
    const s = p.state as { media: Media[]; clips: Clip[]; texts: TextLayer[]; music: typeof music; ratio: Ratio };
    const signed = await Promise.all((s.media ?? []).map(async (m) => { const r = await supabase.storage.from("studio-assets").createSignedUrl(m.path, 3600 * 6); return { ...m, url: r.data?.signedUrl }; }));
    images.current.clear(); setPlaying(false); seek(0);
    setProjectId(p.id); setTitle(p.title); setMedia(signed); setClips(s.clips ?? []); setTexts(s.texts ?? []); setMusic(s.music ?? null); setRatio(s.ratio ?? "16:9"); setSel(null); setSelText(null);
  }
  function fresh() { setPlaying(false); setProjectId(null); setTitle("Untitled edit"); setMedia([]); setClips([]); setTexts([]); setMusic(null); setSel(null); setSelText(null); seek(0); }

  const seek = (v: number) => { tRef.current = v; setT(v); };
  useEffect(() => { playRef.current = playing; if (!playing) { video.current?.pause(); audio.current?.pause(); } }, [playing]);

  function ensureAudioGraph() {
    if (audioCtx.current || !video.current || !audio.current) return;
    const ctx = new AudioContext(); const dest = ctx.createMediaStreamDestination();
    for (const el of [video.current, audio.current]) { const src = ctx.createMediaElementSource(el); src.connect(ctx.destination); src.connect(dest); }
    audioCtx.current = { ctx, dest };
  }

  // Render + playback engine.
  const draw = useCallback(() => {
    const cv = canvas.current; const ctx = cv?.getContext("2d", { willReadFrequently: true }); if (!cv || !ctx) return;
    const { media: ms, clips: cs, texts: ts } = state.current; const [W, H] = RATIOS[state.current.ratio];
    if (cv.width !== W) { cv.width = W; cv.height = H; }
    ctx.globalAlpha = 1; ctx.filter = "none"; ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = "#000"; ctx.fillRect(0, 0, W, H);
    const now = tRef.current; const cur = layout(cs).find((p) => now >= p.start && now < p.start + p.dur);
    if (cur) {
      const c = cur.c, m = ms.find((x) => x.id === c.mediaId); const local = now - cur.start;
      let src: CanvasImageSource | null = null, sw = 0, sh = 0;
      if (m?.type === "video" && video.current && video.current.readyState >= 2) { src = video.current; sw = video.current.videoWidth; sh = video.current.videoHeight; }
      if (m?.type === "image" && m.url) { let img = images.current.get(m.url); if (!img) { img = new Image(); img.crossOrigin = "anonymous"; img.src = m.url; images.current.set(m.url, img); } if (img.complete && img.naturalWidth) { src = img; sw = img.naturalWidth; sh = img.naturalHeight; } }
      if (src && sw) {
        let alpha = c.opacity / 100, zoom = 1;
        if (c.anim === "fade") alpha *= Math.min(1, local / 0.6, (cur.dur - local) / 0.6);
        if (c.anim === "zoom") zoom = 1 + 0.12 * (local / cur.dur);
        if (c.anim === "slide") ctx.translate(Math.max(0, 1 - local / 0.5) * W, 0);
        const fit = Math.min(W / sw, H / sh) * (c.scale / 100) * zoom; const dw = sw * fit, dh = sh * fit;
        const f = FILTERS[c.filter] ?? ""; ctx.filter = `brightness(${c.bright}%) contrast(${c.contrast}%) saturate(${c.sat}%) hue-rotate(${c.hue}deg) blur(${c.blur}px) ${f}`;
        ctx.globalAlpha = Math.max(0, alpha);
        ctx.translate(W / 2 + (c.x / 100) * W, H / 2 + (c.y / 100) * H); ctx.rotate((c.rotate * Math.PI) / 180);
        if (c.chroma) {
          const kc = (keyCanvas.current ??= document.createElement("canvas")); const kw = Math.max(1, Math.round(dw / 2)), kh = Math.max(1, Math.round(dh / 2)); kc.width = kw; kc.height = kh;
          const k = kc.getContext("2d", { willReadFrequently: true })!; k.filter = ctx.filter; k.drawImage(src, 0, 0, kw, kh);
          try { const d = k.getImageData(0, 0, kw, kh); const [kr, kg, kb] = hex(c.chromaColor); const lim = (c.chromaSim / 100) * 442;
            for (let i = 0; i < d.data.length; i += 4) { const dist = Math.hypot(d.data[i]! - kr, d.data[i + 1]! - kg, d.data[i + 2]! - kb); if (dist < lim) d.data[i + 3] = Math.max(0, Math.min(255, ((dist - lim * 0.7) / (lim * 0.3)) * 255)); }
            k.putImageData(d, 0, 0); } catch { /* cross-origin frame: show unkeyed */ }
          ctx.filter = "none"; ctx.drawImage(kc, -dw / 2, -dh / 2, dw, dh);
        } else ctx.drawImage(src, -dw / 2, -dh / 2, dw, dh);
        ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.filter = "none";
      }
    }
    for (const x of ts) {
      if (now < x.start || now >= x.end) continue; const l = now - x.start;
      let a = 1, s = 1; if (x.anim === "fade") a = Math.min(1, l / 0.5, (x.end - now) / 0.5); if (x.anim === "pop") s = Math.min(1, 0.6 + l * 1.6);
      ctx.globalAlpha = Math.max(0, a); ctx.font = `700 ${x.size * s}px "Space Grotesk", sans-serif`; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.lineWidth = Math.max(2, x.size / 12); ctx.strokeStyle = "rgba(0,0,0,.75)"; ctx.fillStyle = x.color;
      const px = (x.x / 100) * W, py = (x.y / 100) * H; ctx.strokeText(x.text, px, py); ctx.fillText(x.text, px, py); ctx.globalAlpha = 1;
    }
  }, []);

  useEffect(() => {
    let raf = 0, last = performance.now(), loadingSrc = "";
    const tick = (ts: number) => {
      const dt = Math.min(0.1, (ts - last) / 1000); last = ts;
      const { media: ms, clips: cs, music: mu } = state.current; const pl = layout(cs); const end = pl.reduce((a, p) => a + p.dur, 0);
      const v = video.current, au = audio.current; let now = tRef.current;
      const cur = pl.find((p) => now >= p.start && now < p.start + p.dur); const m = cur && ms.find((x) => x.id === cur.c.mediaId);
      if (cur && m?.type === "video" && v && m.url) {
        const c = cur.c; const want = c.in + ((now - cur.start) / cur.dur) * (c.out - c.in);
        if (v.dataset["src"] !== m.url) { v.dataset["src"] = m.url; loadingSrc = m.url; v.src = m.url; v.currentTime = want; v.onloadeddata = () => { loadingSrc = ""; }; }
        const p = (now - cur.start) / cur.dur; const fade = Math.min(1, c.fadeIn ? (now - cur.start) / c.fadeIn : 1, c.fadeOut ? (cur.start + cur.dur - now) / c.fadeOut : 1);
        v.volume = Math.max(0, Math.min(1, (c.volume / 100) * fade)); v.playbackRate = Math.max(0.0625, Math.min(16, c.speed * curveRate(c.curve, p)));
        const rec = recorder.current;
        if (playRef.current && loadingSrc) { if (rec?.state === "recording") rec.pause(); au?.pause(); }
        if (playRef.current && !loadingSrc && rec?.state === "paused") rec.resume();
        if (playRef.current && !loadingSrc) {
          if (v.paused) void v.play().catch(() => {});
          now = cur.start + ((v.currentTime - c.in) / (c.out - c.in)) * cur.dur; if (v.currentTime >= c.out - 0.04) now = cur.start + cur.dur + 0.001;
        } else if (!playRef.current && Math.abs(v.currentTime - want) > 0.08 && !loadingSrc) { v.pause(); v.currentTime = want; }
      } else { v?.pause(); if (playRef.current) now += dt * (cur?.c.speed ?? 1) * (cur ? curveRate(cur.c.curve, (now - cur.start) / cur.dur) : 1); }
      const mm = mu && ms.find((x) => x.id === mu.mediaId);
      if (au && mm?.url) { if (au.dataset["src"] !== mm.url) { au.dataset["src"] = mm.url; au.src = mm.url; } au.volume = (mu?.volume ?? 80) / 100;
        if (playRef.current && !loadingSrc) { if (au.paused) { au.currentTime = now % (mm.duration || 1); void au.play().catch(() => {}); } } else au.pause(); }
      if (playRef.current && now >= end) { now = end > 0 ? 0 : 0; setPlaying(false); recorder.current?.state === "recording" && recorder.current.stop(); }
      if (now !== tRef.current) { tRef.current = now; setT(now); }
      draw(); raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick); return () => cancelAnimationFrame(raf);
  }, [draw]);

  async function exportVideo() {
    if (!canvas.current || !clips.length || !user) return;
    ensureAudioGraph(); await audioCtx.current?.ctx.resume();
    const stream = canvas.current.captureStream(30); audioCtx.current?.dest.stream.getAudioTracks().forEach((tr) => stream.addTrack(tr));
    const type = ["video/webm;codecs=vp9,opus", "video/webm"].find((x) => MediaRecorder.isTypeSupported(x)) ?? "";
    const rec = new MediaRecorder(stream, type ? { mimeType: type } : undefined); const chunks: Blob[] = []; recorder.current = rec;
    rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
    rec.onstop = async () => {
      setExporting(false); const raw = new Blob(chunks, { type: "video/webm" });
      let blob = raw; try { const { default: fixWebmDuration } = await import("fix-webm-duration"); blob = await fixWebmDuration(raw, Math.round(layout(state.current.clips).reduce((a, p) => a + p.dur, 0) * 1000), { logger: false }); } catch { blob = raw; }
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `${title.replace(/[^\w-]+/g, "-")}.webm`; a.click();
      const path = `${user.id}/video/${uid()}.webm`; const up = await supabase.storage.from("studio-assets").upload(path, blob, { contentType: "video/webm" });
      if (up.error) { toast.error(`Export downloaded, but saving failed: ${up.error.message}`); return; }
      const ins = await supabase.from("studio_projects").insert({ user_id: user.id, studio: "video", kind: "video", title: `${title} (export)`, asset_path: path });
      if (ins.error) toast.error(ins.error.message); else toast.success("Export saved to your account");
    };
    setExporting(true); seek(0); rec.start(250); setPlaying(true);
  }

  function split() {
    if (!clip) return; const p = placed.find((x) => x.c.id === clip.id); if (!p || t <= p.start || t >= p.start + p.dur) { toast.error("Move the playhead inside the selected clip."); return; }
    const cut = clip.in + ((t - p.start) / p.dur) * (clip.out - clip.in);
    setClips((cs) => cs.flatMap((c) => c.id === clip.id ? [{ ...c, out: cut }, { ...c, id: uid(), in: cut }] : [c]));
  }
  const fmt = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${(s % 60).toFixed(1).padStart(4, "0")}`;

  // Controls the AI companion can press directly.
  const pick = (a: { clip?: unknown }) => { const i = Number(a.clip); return Number.isInteger(i) && i >= 1 && i <= clips.length ? [clips[i - 1]!.id] : sel ? [sel] : clips.map((c) => c.id); };
  const patchClips = (ids: string[], p: Partial<Clip>) => setClips((cs) => cs.map((c) => ids.includes(c.id) ? { ...c, ...p } : c));
  const num = (v: unknown, lo: number, hi: number) => { const n = Number(v); if (!Number.isFinite(n)) throw new Error("Expected a number."); return Math.min(hi, Math.max(lo, n)); };
  const CLIP_ARG = `"clip"?: number (1-based; omit = selected clip, or all clips if none selected)`;
  useStudioActions([
    { name: "editor_describe", description: "Read the current timeline: media library, clips with their settings, text layers, music, aspect ratio, playhead.", run: () => JSON.stringify({ media: media.map((m) => ({ name: m.name, type: m.type, duration: +m.duration.toFixed(1) })), clips: placed.map((p, i) => ({ clip: i + 1, media: media.find((m) => m.id === p.c.mediaId)?.name, start: +p.start.toFixed(1), duration: +p.dur.toFixed(1), speed: p.c.speed, curve: p.c.curve, filter: p.c.filter, bright: p.c.bright, contrast: p.c.contrast, sat: p.c.sat, anim: p.c.anim })), texts: texts.map((x) => ({ text: x.text, start: x.start, end: x.end })), music: !!music, ratio, playhead: +t.toFixed(1), total: +total.toFixed(1) }) },
    { name: "editor_add_all_media", description: "Place every imported video and photo on the timeline in order (audio becomes the music track).", run: () => { const vis = media.filter((m) => m.type !== "audio"); setClips((cs) => [...cs, ...vis.map(newClip)]); const au = media.find((m) => m.type === "audio"); if (au) setMusic({ mediaId: au.id, volume: 80 }); return `Added ${vis.length} clips${au ? " and music" : ""}.`; } },
    { name: "editor_select_clip", description: "Select a clip.", args: `{ "clip": number }`, run: (a) => { const [id] = pick(a); setSel(id ?? null); setTab("Basic"); return "Selected."; } },
    { name: "editor_filter", description: `Apply a filter. Options: ${Object.keys(FILTERS).join(", ")}.`, args: `{ "filter": string, ${CLIP_ARG} }`, run: (a) => { const f = Object.keys(FILTERS).find((k) => k.toLowerCase() === String(a.filter ?? "None").toLowerCase()); if (!f) throw new Error(`Unknown filter ${String(a.filter)}`); patchClips(pick(a), { filter: f }); setTab("Filters"); return `Filter ${f} applied.`; } },
    { name: "editor_adjust", description: "Colour adjust. bright/contrast/sat are percent (100 = normal, 0–200), hue degrees (-180–180), blur px (0–20).", args: `{ "bright"?, "contrast"?, "sat"?, "hue"?, "blur"?, ${CLIP_ARG} }`, run: (a) => { const p: Partial<Clip> = {}; if (a.bright != null) p.bright = num(a.bright, 0, 200); if (a.contrast != null) p.contrast = num(a.contrast, 0, 200); if (a.sat != null) p.sat = num(a.sat, 0, 200); if (a.hue != null) p.hue = num(a.hue, -180, 180); if (a.blur != null) p.blur = num(a.blur, 0, 20); patchClips(pick(a), p); setTab("Adjust"); return "Adjusted."; } },
    { name: "editor_speed", description: "Set clip speed (0.1–10) and/or speed curve: none, montage, hero, bullet.", args: `{ "speed"?: number, "curve"?: string, ${CLIP_ARG} }`, run: (a) => { const p: Partial<Clip> = {}; if (a.speed != null) p.speed = num(a.speed, 0.1, 10); if (a.curve != null) { if (!(String(a.curve) in CURVES)) throw new Error("Unknown curve"); p.curve = a.curve as Curve; } patchClips(pick(a), p); setTab("Speed"); return "Speed set."; } },
    { name: "editor_animate", description: "Set clip intro animation: none, fade, zoom, slide; plus fadeIn/fadeOut seconds (0–3).", args: `{ "anim"?: string, "fadeIn"?: number, "fadeOut"?: number, ${CLIP_ARG} }`, run: (a) => { const p: Partial<Clip> = {}; if (a.anim != null) { if (!["none", "fade", "zoom", "slide"].includes(String(a.anim))) throw new Error("Unknown animation"); p.anim = a.anim as Clip["anim"]; } if (a.fadeIn != null) p.fadeIn = num(a.fadeIn, 0, 3); if (a.fadeOut != null) p.fadeOut = num(a.fadeOut, 0, 3); patchClips(pick(a), p); setTab("Animation"); return "Animation set."; } },
    { name: "editor_trim", description: "Trim a clip's source in/out points in seconds.", args: `{ "in"?: number, "out"?: number, "clip": number }`, run: (a) => { const [id] = pick(a); const c = clips.find((x) => x.id === id); const m = media.find((x) => x.id === c?.mediaId); if (!c || !m) throw new Error("No such clip."); const i = a.in != null ? num(a.in, 0, m.duration) : c.in; const o = a.out != null ? num(a.out, i + 0.1, m.duration) : c.out; patchClips([c.id], { in: i, out: o }); return "Trimmed."; } },
    { name: "editor_delete_clip", description: "Remove a clip from the timeline.", args: `{ "clip": number }`, run: (a) => { const [id] = pick(a); setClips((cs) => cs.filter((c) => c.id !== id)); return "Deleted."; } },
    { name: "editor_duplicate_clip", description: "Duplicate a clip.", args: `{ "clip": number }`, run: (a) => { const [id] = pick(a); setClips((cs) => cs.flatMap((c) => c.id === id ? [c, { ...c, id: uid() }] : [c])); return "Duplicated."; } },
    { name: "editor_add_text", description: "Add a text/title layer. x,y are percent of frame; size px; color hex; anim none|fade|pop.", args: `{ "text": string, "start"?: number, "end"?: number, "x"?: number, "y"?: number, "size"?: number, "color"?: string, "anim"?: string }`, run: (a) => { const start = a.start != null ? num(a.start, 0, 3600) : t; const x: TextLayer = { id: uid(), text: String(a.text ?? "Title"), start, end: a.end != null ? num(a.end, start + 0.2, 3600) : start + 3, x: a.x != null ? num(a.x, 0, 100) : 50, y: a.y != null ? num(a.y, 0, 100) : 80, size: a.size != null ? num(a.size, 12, 200) : 72, color: /^#[0-9a-f]{6}$/i.test(String(a.color)) ? String(a.color) : "#ffffff", anim: ["none", "fade", "pop"].includes(String(a.anim)) ? a.anim as TextLayer["anim"] : "fade" }; setTexts((ts) => [...ts, x]); setSelText(x.id); setTab("Text"); return "Text added."; } },
    { name: "editor_aspect", description: "Set aspect ratio: 16:9, 9:16 or 1:1.", args: `{ "ratio": string }`, run: (a) => { const r = String(a.ratio); if (!(r in RATIOS)) throw new Error("Unknown ratio"); setRatio(r as Ratio); return `Aspect ${r}.`; } },
    { name: "editor_play", description: "Play from a time (seconds) or pause.", args: `{ "play": boolean, "at"?: number }`, run: (a) => { if (a.at != null) seek(num(a.at, 0, total)); setPlaying(!!a.play); return a.play ? "Playing." : "Paused."; } },
    { name: "editor_save", description: "Save the edit project to the user's account.", run: async () => { await save(); return "Saved."; } },
    { name: "editor_export", description: "Export the final video (plays through once, then downloads and saves).", run: () => { if (!clips.length) throw new Error("Timeline is empty."); void exportVideo(); return "Export started."; } },
  ]);
  const pxPerSec = 40;

  if (!user) return <div className="grid h-full place-items-center"><Button asChild><Link to="/auth">Sign in to edit and save videos</Link></Button></div>;
  return <div className="flex h-full max-w-full flex-col gap-2 overflow-hidden p-2">
    <video ref={video} crossOrigin="anonymous" playsInline className="hidden" /><audio ref={audio} crossOrigin="anonymous" className="hidden" />
    <div className="motion-layout grid min-h-0 min-w-0 flex-1 gap-2">
      {/* Media */}
      <section className="motion-media holo hud-corners flex min-h-0 min-w-0 w-full shrink-0 flex-col overflow-hidden">
        <div className="flex items-center gap-1 border-b p-2"><input aria-label="Project name" value={title} onChange={(e) => setTitle(e.target.value)} className="min-w-0 flex-1 bg-transparent px-1 font-display text-sm outline-none" /><Button size="icon-sm" variant="outline" title="New edit" onClick={fresh}><FilePlus2 /></Button></div>
        <div className="space-y-2 p-2"><input ref={fileInput} type="file" accept="video/*,image/*,audio/*" multiple hidden onChange={(e) => { void importFiles(e.target.files); e.target.value = ""; }} />
          <Button className="w-full" onClick={() => fileInput.current?.click()} disabled={uploading > 0}>{uploading ? <Loader2 className="animate-spin" /> : <Upload />}{uploading ? `Uploading ${uploading}…` : "Import media"}</Button></div>
        <div className="min-h-0 flex-1 space-y-1 overflow-y-auto px-2 pb-2 text-xs" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); void importFiles(e.dataTransfer.files); }}>
          {media.length === 0 && <p className="p-2 text-muted-foreground">Drop videos, photos or music here.</p>}
          {media.map((m) => <div key={m.id} className="flex items-center gap-2 rounded px-2 py-1.5 hover:bg-secondary">{m.type === "video" ? <Film className="size-3.5 text-primary" /> : m.type === "image" ? <ImageIcon className="size-3.5 text-teal" /> : <Music2 className="size-3.5 text-accent-foreground" />}<span className="min-w-0 flex-1 truncate">{m.name}</span>
            <button className="text-primary" title="Add to timeline" onClick={() => m.type === "audio" ? setMusic({ mediaId: m.id, volume: 80 }) : setClips((cs) => [...cs, newClip(m)])}>+</button></div>)}
          {!!projects.data?.length && <div className="pt-3"><p className="mb-1 uppercase tracking-wider text-muted-foreground">Saved edits</p>{projects.data.map((p) => <button key={p.id} onClick={() => void open(p)} className="block w-full truncate rounded px-2 py-1 text-left hover:bg-secondary">{p.title}</button>)}</div>}
        </div>
      </section>
      {/* Player */}
      <section className={`holo flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden ${exporting ? "glow-active" : ""}`}>
        <div className="flex flex-wrap items-center gap-2 border-b p-2 text-xs">
          {(Object.keys(RATIOS) as Ratio[]).map((r) => <Button key={r} size="xs" variant={ratio === r ? "default" : "ghost"} onClick={() => setRatio(r)}>{r}</Button>)}
          <div className="ml-auto flex gap-1"><Button size="sm" variant="outline" onClick={() => void save()} disabled={saving}>{saving ? <Loader2 className="animate-spin" /> : <Save />}Save</Button><Button size="sm" onClick={() => void exportVideo()} disabled={exporting || !clips.length}>{exporting ? <Loader2 className="animate-spin" /> : <Download />}{exporting ? "Exporting…" : "Export"}</Button></div>
        </div>
        <div className="grid min-h-0 flex-1 place-items-center overflow-hidden recessed scanline p-2"><canvas ref={canvas} className="max-h-full max-w-full rounded border" /></div>
        <div className="flex items-center gap-2 border-t p-2 font-mono text-xs">
          <Button size="icon-sm" onClick={() => { ensureAudioGraph(); void audioCtx.current?.ctx.resume(); if (tRef.current >= total) seek(0); setPlaying((p) => !p); }} disabled={!clips.length || exporting}>{playing ? <Pause /> : <Play />}</Button>
          <span className="text-primary">{fmt(t)}</span><span className="text-muted-foreground">/ {fmt(total)}</span>
          <input type="range" aria-label="Playhead" min={0} max={total || 1} step={0.01} value={t} onChange={(e) => { setPlaying(false); seek(+e.target.value); }} className="flex-1 accent-[var(--primary)]" />
        </div>
      </section>
      {/* Inspector */}
      <section className="motion-inspector holo hud-corners flex min-h-0 min-w-0 w-full shrink-0 flex-col overflow-hidden">
        <div className="flex flex-wrap gap-1 border-b p-2">{TABS.map((x) => <button key={x} onClick={() => setTab(x)} className={`rounded px-2 py-1 text-xs ${tab === x ? "bg-primary/20 text-primary" : "text-muted-foreground hover:text-foreground"}`}>{x}</button>)}</div>
        <div className="min-h-0 flex-1 space-y-3 overflow-y-auto p-3">
          {tab === "Text" ? <>
            <Button size="sm" className="w-full" onClick={() => { const x: TextLayer = { id: uid(), text: "Your title", start: t, end: Math.min(t + 3, Math.max(total, t + 3)), x: 50, y: 80, size: 72, color: "#ffffff", anim: "fade" }; setTexts((ts) => [...ts, x]); setSelText(x.id); }}><Type />Add text at playhead</Button>
            {text ? <><input aria-label="Text" value={text.text} onChange={(e) => updateText({ text: e.target.value })} className="w-full rounded border bg-background/60 p-2 text-sm" />
              <Slider label="Size" value={text.size} set={(size) => updateText({ size })} min={16} max={200} /><Slider label="X" value={text.x} set={(x) => updateText({ x })} unit="%" /><Slider label="Y" value={text.y} set={(y) => updateText({ y })} unit="%" />
              <Slider label="Start" value={+text.start.toFixed(1)} set={(start) => updateText({ start })} max={Math.max(total, 1)} step={0.1} unit="s" /><Slider label="End" value={+text.end.toFixed(1)} set={(end) => updateText({ end })} max={Math.max(total, 1)} step={0.1} unit="s" />
              <label className="flex items-center justify-between text-xs">Color<input type="color" value={text.color} onChange={(e) => updateText({ color: e.target.value })} /></label>
              <div className="flex gap-1">{(["none", "fade", "pop"] as const).map((a) => <Button key={a} size="xs" variant={text.anim === a ? "default" : "outline"} onClick={() => updateText({ anim: a })}>{a}</Button>)}</div>
              <Button size="sm" variant="destructive" onClick={() => { setTexts((ts) => ts.filter((x) => x.id !== text.id)); setSelText(null); }}><Trash2 />Delete text</Button></> : <p className="text-xs text-muted-foreground">Select a text layer on the timeline.</p>}
          </> : tab === "Audio" && !clip ? <>
            <p className="text-xs text-muted-foreground">Background music</p>
            {music ? <><p className="truncate text-sm">{media.find((m) => m.id === music.mediaId)?.name}</p><Slider label="Music volume" value={music.volume} set={(volume) => setMusic({ ...music, volume })} /><Button size="sm" variant="outline" onClick={() => setMusic(null)}>Remove music</Button></> : <p className="text-xs">Import an audio file to add music.</p>}
          </> : !clip ? <p className="text-xs text-muted-foreground">Select a clip on the timeline to edit it.</p> : <>
            {tab === "Basic" && <><Slider label="Trim start" value={+clip.in.toFixed(2)} set={(v) => update({ in: Math.min(v, clip.out - 0.1) })} max={media.find((m) => m.id === clip.mediaId)?.type === "image" ? 30 : media.find((m) => m.id === clip.mediaId)?.duration ?? 10} step={0.05} unit="s" />
              <Slider label={media.find((m) => m.id === clip.mediaId)?.type === "image" ? "Duration" : "Trim end"} value={+clip.out.toFixed(2)} set={(v) => update({ out: Math.max(v, clip.in + 0.1) })} max={media.find((m) => m.id === clip.mediaId)?.type === "image" ? 30 : media.find((m) => m.id === clip.mediaId)?.duration ?? 10} step={0.05} unit="s" />
              <Slider label="Scale" value={clip.scale} set={(scale) => update({ scale })} min={10} max={300} unit="%" /><Slider label="Position X" value={clip.x} set={(x) => update({ x })} min={-100} max={100} /><Slider label="Position Y" value={clip.y} set={(y) => update({ y })} min={-100} max={100} />
              <Slider label="Rotate" value={clip.rotate} set={(rotate) => update({ rotate })} min={-180} max={180} unit="°" /><Slider label="Opacity" value={clip.opacity} set={(opacity) => update({ opacity })} unit="%" /></>}
            {tab === "Speed" && <><Slider label="Speed" value={clip.speed} set={(speed) => update({ speed })} min={0.1} max={8} step={0.1} unit="×" />
              <p className="text-xs text-muted-foreground">Speed curve</p><div className="grid grid-cols-2 gap-1">{(Object.keys(CURVES) as Curve[]).map((k) => <Button key={k} size="xs" variant={clip.curve === k ? "default" : "outline"} onClick={() => update({ curve: k })}>{CURVES[k]}</Button>)}</div>
              <svg viewBox="0 0 100 40" className="w-full rounded border bg-background/60"><polyline fill="none" stroke="var(--orb-cyan)" strokeWidth="1.5" points={Array.from({ length: 51 }, (_, i) => `${i * 2},${40 - Math.min(38, curveRate(clip.curve, i / 50) * 12)}`).join(" ")} /></svg></>}
            {tab === "Adjust" && <><Slider label="Brightness" value={clip.bright} set={(bright) => update({ bright })} max={200} unit="%" /><Slider label="Contrast" value={clip.contrast} set={(contrast) => update({ contrast })} max={200} unit="%" />
              <Slider label="Saturation" value={clip.sat} set={(sat) => update({ sat })} max={300} unit="%" /><Slider label="Hue" value={clip.hue} set={(hue) => update({ hue })} min={-180} max={180} unit="°" /><Slider label="Blur" value={clip.blur} set={(blur) => update({ blur })} max={20} unit="px" /></>}
            {tab === "Filters" && <div className="grid grid-cols-2 gap-1">{Object.keys(FILTERS).map((f) => <Button key={f} size="xs" variant={clip.filter === f ? "default" : "outline"} onClick={() => update({ filter: f })}>{f}</Button>)}</div>}
            {tab === "Cutout" && <><label className="flex items-center justify-between text-xs">Chroma key (green screen)<input type="checkbox" checked={clip.chroma} onChange={(e) => update({ chroma: e.target.checked })} /></label>
              <label className="flex items-center justify-between text-xs">Key color<input type="color" value={clip.chromaColor} onChange={(e) => update({ chromaColor: e.target.value })} /></label>
              <Slider label="Similarity" value={clip.chromaSim} set={(chromaSim) => update({ chromaSim })} min={5} max={90} unit="%" /></>}
            {tab === "Audio" && <><Slider label="Clip volume" value={clip.volume} set={(volume) => update({ volume })} max={200} unit="%" /><Slider label="Fade in" value={clip.fadeIn} set={(fadeIn) => update({ fadeIn })} max={5} step={0.1} unit="s" /><Slider label="Fade out" value={clip.fadeOut} set={(fadeOut) => update({ fadeOut })} max={5} step={0.1} unit="s" />
              {music && <Slider label="Music volume" value={music.volume} set={(volume) => setMusic({ ...music, volume })} />}</>}
            {tab === "Animation" && <div className="grid grid-cols-2 gap-1">{(["none", "fade", "zoom", "slide"] as const).map((a) => <Button key={a} size="xs" variant={clip.anim === a ? "default" : "outline"} onClick={() => update({ anim: a })}>{a === "none" ? "None" : a === "fade" ? "Fade in/out" : a === "zoom" ? "Ken Burns" : "Slide in"}</Button>)}</div>}
          </>}
        </div>
      </section>
    </div>
    {/* Timeline */}
    <section className="holo hud-corners flex h-44 shrink-0 flex-col overflow-hidden">
      <div className="flex items-center gap-1 border-b p-1.5">
        <Button size="xs" variant="ghost" onClick={split} disabled={!clip}><Scissors />Split</Button>
        <Button size="xs" variant="ghost" disabled={!clip} onClick={() => clip && setClips((cs) => { const i = cs.findIndex((c) => c.id === clip.id); const copy = [...cs]; copy.splice(i + 1, 0, { ...clip, id: uid() }); return copy; })}><Copy />Duplicate</Button>
        <Button size="xs" variant="ghost" disabled={!clip} onClick={() => { setClips((cs) => cs.filter((c) => c.id !== sel)); setSel(null); }}><Trash2 />Delete</Button>
        <span className="ml-auto pr-2 text-xs text-muted-foreground">{clips.length} clips · {texts.length} text</span>
      </div>
      <div className="relative min-h-0 flex-1 overflow-auto" onClick={(e) => { if (e.target !== e.currentTarget) return; const r = e.currentTarget.getBoundingClientRect(); setPlaying(false); seek(Math.min(total, (e.clientX - r.left + e.currentTarget.scrollLeft - 64) / pxPerSec)); }}>
        <div className="relative space-y-1 p-1 pl-16" style={{ width: Math.max(600, total * pxPerSec + 120) }}>
          {[{ label: "Video", icon: Film }, { label: "Text", icon: Type }, { label: "Music", icon: Music2 }].map((row, ri) => <div key={row.label} className="relative h-9">
            <span className="absolute -left-14 top-2 flex items-center gap-1 text-[10px] text-muted-foreground"><row.icon className="size-3" />{row.label}</span>
            {ri === 0 && placed.map((p) => <button key={p.c.id} onClick={() => { setSel(p.c.id); setSelText(null); if (tab === "Text") setTab("Basic"); }} style={{ left: p.start * pxPerSec, width: Math.max(8, p.dur * pxPerSec - 2) }} className={`absolute top-0 h-9 truncate rounded border px-1 text-left text-[10px] ${sel === p.c.id ? "border-primary bg-primary/30 shadow-glow" : "border-primary/30 bg-primary/10"}`}>{media.find((m) => m.id === p.c.mediaId)?.name}{p.c.speed !== 1 ? ` · ${p.c.speed}×` : ""}</button>)}
            {ri === 1 && texts.map((x) => <button key={x.id} onClick={() => { setSelText(x.id); setSel(null); setTab("Text"); }} style={{ left: x.start * pxPerSec, width: Math.max(8, (x.end - x.start) * pxPerSec) }} className={`absolute top-0 h-9 truncate rounded border px-1 text-left text-[10px] ${selText === x.id ? "border-accent bg-accent/40" : "border-accent/40 bg-accent/15"}`}>{x.text}</button>)}
            {ri === 2 && music && <button onClick={() => { setSel(null); setTab("Audio"); }} style={{ left: 0, width: Math.max(100, total * pxPerSec) }} className="absolute top-0 h-9 truncate rounded border border-teal/50 bg-teal/15 px-1 text-left text-[10px]">{media.find((m) => m.id === music.mediaId)?.name}</button>}
          </div>)}
          <div className="pointer-events-none absolute bottom-0 top-0 w-px bg-primary shadow-glow" style={{ left: 64 + t * pxPerSec }} />
        </div>
      </div>
    </section>
  </div>;
}
