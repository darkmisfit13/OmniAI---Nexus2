import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { zipSync, strToU8 } from "fflate";
import {
  BarChart3, Bot, Code2, CreditCard, Database, Download, Eye, FileCode2, FilePlus2, Files, FolderOpen, GitBranch, Globe, KeyRound,
  Layers, Loader2, Mail, Monitor, Plug, RefreshCw, ScrollText, Send, Settings, Shield, Smartphone, Tablet, Trash2, Upload, Users, HardDrive,
  BrainCircuit, Activity, Wrench, BookOpen, Copy, ExternalLink,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { buildSite } from "@/lib/ai.functions";
import { FILE_NAMES, joinSite, splitSite } from "@/lib/site-files";
import { useAccount } from "@/components/AccountProvider";
import { useWorkspaceState } from "@/components/WorkspaceStateProvider";
import { useStudioActions } from "@/lib/studio-actions";
import { EnhanceButton } from "@/components/MediaComposer";
import { HoloOrb } from "@/components/HoloOrb";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";

type Turn = { role: "user" | "ai"; text: string; at?: string };
type Log = { at: string; level: "info" | "ok" | "error" | "warn"; text: string };
type SiteSettings = {
  subdomain: string; category: string; prototype: boolean; monitoring: boolean; livePreview: boolean; hideBadge: boolean;
  visitorAnalytics: boolean; aiContext: boolean; autoFixSecurity: boolean; trustCenter: boolean; published: boolean;
  publicRemix: boolean; crossProject: boolean; knowledge: string; agentIntegrations: boolean; payments: boolean; emails: boolean;
  palette: string[]; fontPair: string; customDomain: string;
};
const DEFAULTS: SiteSettings = {
  subdomain: "", category: "", prototype: false, monitoring: false, livePreview: true, hideBadge: false, visitorAnalytics: true,
  aiContext: true, autoFixSecurity: false, trustCenter: false, published: false, publicRemix: false, crossProject: false, knowledge: "",
  agentIntegrations: false, payments: false, emails: false, palette: ["#000000", "#0B0B0C", "#00f2fe", "#7f00ff", "#0575e6"], fontPair: "Space Grotesk / DM Sans", customDomain: "",
};
type View = "preview" | "files" | "code" | "more";
const SECTIONS = [
  ["analytics", "Analytics & SEO", BarChart3], ["database", "Database", Database], ["users", "Users", Users], ["storage", "Storage", HardDrive],
  ["ai", "AI", BrainCircuit], ["agents", "Agent integrations", Bot], ["payments", "Payments", CreditCard], ["emails", "Emails", Mail],
  ["connectors", "Connectors", Plug], ["security", "Security", Shield], ["usage", "Usage", Activity], ["general", "Settings", Settings],
  ["secrets", "Secrets", KeyRound], ["logs", "Logs", ScrollText], ["knowledge", "Knowledge", BookOpen], ["domains", "Domains", Globe], ["git", "Git", GitBranch],
] as const;
type Section = (typeof SECTIONS)[number][0];
const STARTERS = ["SaaS landing page", "Customer portal", "Online store", "Internal ops dashboard", "Restaurant site with booking", "Portfolio"];
const CATEGORIES = ["Internal tools", "Website", "Personal", "Consumer app", "B2B app", "Prototype"];

const BRIDGE = `<script>(function(){function s(l,a){try{parent.postMessage({omni:1,level:l,text:Array.from(a).map(function(x){try{return typeof x==="string"?x:JSON.stringify(x)}catch(e){return String(x)}}).join(" ")},"*")}catch(e){}}["log","warn","error"].forEach(function(k){var o=console[k];console[k]=function(){s(k==="log"?"info":k,arguments);o.apply(console,arguments)}});addEventListener("error",function(e){s("error",[e.message+" (line "+e.lineno+")"])});s("ok",["Preview runtime started"]);})();</script>`;
const withBridge = (h: string) => (/<head[^>]*>/i.test(h) ? h.replace(/<head[^>]*>/i, (m) => m + BRIDGE) : BRIDGE + h);
const now = () => new Date().toLocaleTimeString([], { hour12: false });
const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "omni-site";

export function OmniSite() {
  const { user } = useAccount(); const qc = useQueryClient(); const { setPhase } = useWorkspaceState();
  const build = useServerFn(buildSite);
  const [projectId, setProjectId] = useState<string | null>(null);
  const [started, setStarted] = useState(false);
  const [title, setTitle] = useState("Untitled site");
  const [html, setHtml] = useState(""); const [turns, setTurns] = useState<Turn[]>([]);
  const [settings, setSettings] = useState<SiteSettings>(DEFAULTS);
  const [createdAt, setCreatedAt] = useState<string | null>(null);
  const [prompt, setPrompt] = useState(""); const [busy, setBusy] = useState(false);
  const [view, setView] = useState<View>("preview"); const [device, setDevice] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [section, setSection] = useState<Section>("general");
  const [logs, setLogs] = useState<Log[]>([]); const [file, setFile] = useState<(typeof FILE_NAMES)[number]>("index.html");
  const [reloadKey, setReloadKey] = useState(0);
  const frame = useRef<HTMLIFrameElement>(null); const chatEnd = useRef<HTMLDivElement>(null);
  const log = (level: Log["level"], text: string) => setLogs((l) => [...l.slice(-300), { at: now(), level, text }]);

  const projects = useQuery({ queryKey: ["omni-site", user?.id], enabled: !!user, queryFn: async () => {
    const r = await supabase.from("studio_projects").select("id,title,content,state,created_at").eq("studio", "website").eq("kind", "build").order("created_at", { ascending: false });
    if (r.error) throw r.error; return r.data;
  } });
  const folder = user && projectId ? `${user.id}/omni-site/${projectId}` : null;
  const assets = useQuery({ queryKey: ["omni-site-files", folder], enabled: !!folder, queryFn: async () => {
    const r = await supabase.storage.from("studio-assets").list(folder!, { limit: 200, sortBy: { column: "created_at", order: "desc" } });
    if (r.error) throw r.error; return r.data.filter((f) => f.name !== ".emptyFolderPlaceholder");
  } });

  useEffect(() => {
    const onMsg = (e: MessageEvent) => { if (e.source !== frame.current?.contentWindow || !e.data?.omni) return; log(e.data.level, String(e.data.text).slice(0, 500)); };
    addEventListener("message", onMsg); return () => removeEventListener("message", onMsg);
  }, []);
  useEffect(() => { chatEnd.current?.scrollIntoView({ block: "end" }); }, [turns, busy]);
  const srcDoc = useMemo(() => (html ? withBridge(html) : ""), [html]);
  const files = useMemo(() => splitSite(html), [html]);
  const errors = logs.filter((l) => l.level === "error");

  async function save(next: { html?: string; turns?: Turn[]; title?: string; settings?: SiteSettings } = {}) {
    if (!user) throw new Error("Sign in to save.");
    const row = { studio: "website", kind: "build", title: next.title ?? title, content: next.html ?? html, state: { turns: next.turns ?? turns, settings: next.settings ?? settings } };
    const r = projectId ? await supabase.from("studio_projects").update(row).eq("id", projectId).select("id,created_at").single()
      : await supabase.from("studio_projects").insert({ ...row, user_id: user.id }).select("id,created_at").single();
    if (r.error) throw r.error; setProjectId(r.data.id); setCreatedAt(r.data.created_at); void qc.invalidateQueries({ queryKey: ["omni-site"] });
    return r.data.id as string;
  }
  function update<K extends keyof SiteSettings>(k: K, v: SiteSettings[K]) {
    const next = { ...settings, [k]: v }; setSettings(next);
    if (projectId) void save({ settings: next }).catch((e) => toast.error(String(e?.message ?? e)));
  }

  async function run(instruction: string) {
    if (!instruction.trim() || busy || !user) return;
    setStarted(true); setBusy(true); setPhase("classified");
    const stamp = new Date().toISOString();
    const nextTurns: Turn[] = [...turns, { role: "user", text: instruction, at: stamp }]; setTurns(nextTurns); setPrompt("");
    log("info", `$ omni ${html ? "edit" : "create"} — "${instruction.slice(0, 80)}"`);
    const t = performance.now();
    try {
      setPhase("routed");
      const withKnowledge = settings.knowledge.trim() ? `${instruction}\n\nProject knowledge:\n${settings.knowledge}` : instruction;
      const r = await build({ data: { kind: "website", prompt: withKnowledge, html } });
      setPhase("streaming");
      const secs = ((performance.now() - t) / 1000).toFixed(1);
      log("ok", `Received ${r.html.length.toLocaleString()} characters in ${secs}s`);
      const nextTitle = projectId ? title : instruction.slice(0, 60); setTitle(nextTitle);
      const parts = splitSite(r.html);
      const summary = `${html ? "Applied your changes" : "Built the first version"} in ${secs}s.\n• index.html ${(parts["index.html"].length / 1024).toFixed(1)}k · styles.css ${(parts["styles.css"].length / 1024).toFixed(1)}k · script.js ${(parts["script.js"].length / 1024).toFixed(1)}k\nNext you could: add a contact form, tune the colors in Design system, or check it on mobile.`;
      const done: Turn[] = [...nextTurns, { role: "ai", text: summary, at: new Date().toISOString() }];
      setTurns(done); setHtml(r.html); setView("preview");
      const nextSettings = settings.subdomain ? settings : { ...settings, subdomain: slug(nextTitle) }; setSettings(nextSettings);
      await save({ html: r.html, turns: done, title: nextTitle, settings: nextSettings }); setPhase("succeeded");
    } catch (e) {
      setPhase("failed"); const m = e instanceof Error ? e.message : "Build failed."; log("error", m); toast.error(m);
      setTurns([...nextTurns, { role: "ai", text: `That didn't work: ${m}` }]);
    } finally { setBusy(false); }
  }

  function open(p: { id: string; title: string; content: string | null; state: unknown; created_at: string }) {
    const s = (p.state ?? {}) as { turns?: Turn[]; settings?: Partial<SiteSettings> };
    setProjectId(p.id); setTitle(p.title); setHtml(p.content ?? ""); setTurns(s.turns ?? []); setSettings({ ...DEFAULTS, ...s.settings });
    setCreatedAt(p.created_at); setLogs([{ at: now(), level: "info", text: `Opened "${p.title}"` }]); setStarted(true); setView("preview");
  }
  function fresh() { setProjectId(null); setTitle("Untitled site"); setHtml(""); setTurns([]); setSettings(DEFAULTS); setLogs([]); setStarted(false); }

  function downloadZip(name: string) {
    const z = zipSync({
      [`${name}/index.html`]: strToU8(html), [`${name}/src/index.html`]: strToU8(files["index.html"]), [`${name}/src/styles.css`]: strToU8(files["styles.css"]),
      [`${name}/src/script.js`]: strToU8(files["script.js"]), [`${name}/README.md`]: strToU8(`# ${title}\n\nBuilt with Omni Site.\n\nOpen index.html in a browser, or deploy the folder to any static host.\n`),
      [`${name}/omni-site.json`]: strToU8(JSON.stringify({ title, category: settings.category, subdomain: settings.subdomain, designSystem: { palette: settings.palette, fonts: settings.fontPair } }, null, 2)),
    });
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([z as BlobPart], { type: "application/zip" })); a.download = `${name}.zip`; a.click();
  }
  async function uploadFiles(list: FileList | null) {
    if (!list?.length || !user) return;
    const id = projectId ?? (await save()); const dir = `${user.id}/omni-site/${id}`;
    for (const f of Array.from(list)) {
      const r = await supabase.storage.from("studio-assets").upload(`${dir}/${Date.now()}-${f.name.replace(/[^\w.-]+/g, "_")}`, f, { contentType: f.type });
      if (r.error) { toast.error(r.error.message); return; }
    }
    toast.success(`Uploaded ${list.length} file${list.length > 1 ? "s" : ""}`); void qc.invalidateQueries({ queryKey: ["omni-site-files"] });
  }
  async function openAsset(name: string) {
    const r = await supabase.storage.from("studio-assets").createSignedUrl(`${folder}/${name}`, 600);
    if (r.error) { toast.error(r.error.message); return; } window.open(r.data.signedUrl, "_blank", "noopener");
  }
  async function removeAsset(name: string) {
    const r = await supabase.storage.from("studio-assets").remove([`${folder}/${name}`]);
    if (r.error) { toast.error(r.error.message); return; } void qc.invalidateQueries({ queryKey: ["omni-site-files"] });
  }
  async function duplicate() {
    if (!user) return;
    const r = await supabase.from("studio_projects").insert({ studio: "website", kind: "build", user_id: user.id, title: `${title} (remix)`, content: html, state: { turns: [], settings: { ...settings, published: false, subdomain: `${settings.subdomain}-remix` } } }).select("id").single();
    if (r.error) { toast.error(r.error.message); return; } toast.success("Remixed into a new project"); void qc.invalidateQueries({ queryKey: ["omni-site"] });
  }
  async function destroy() {
    if (!projectId || !confirm(`Delete "${title}" permanently?`)) return;
    const r = await supabase.from("studio_projects").delete().eq("id", projectId);
    if (r.error) { toast.error(r.error.message); return; } toast.success("Project deleted"); void qc.invalidateQueries({ queryKey: ["omni-site"] }); fresh();
  }

  useStudioActions([
    { name: "site_describe", description: "Read the current Omni Site project: title, page size, errors, saved projects.", run: () => JSON.stringify({ title, hasPage: !!html, errors: errors.slice(-5).map((e) => e.text), projects: projects.data?.map((p) => p.title) ?? [] }) },
    { name: "site_build", description: "Build or change the current site. Write a detailed instruction.", args: `{ "instruction": string }`, run: async (a) => { await run(String(a.instruction ?? "")); return "Build finished."; } },
    { name: "site_view", description: "Switch the right panel.", args: `{ "view": "preview"|"files"|"code"|"more" }`, run: (a) => { setView(a.view as View); return "View changed."; } },
  ]);

  if (!user) return <div className="grid h-full place-items-center"><Button asChild><Link to="/auth">Sign in to build with Omni Site</Link></Button></div>;

  /* ───────── Landing: "What are we building?" ───────── */
  if (!started) return <div className="relative flex h-full flex-col items-center overflow-y-auto p-6">
    <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_50%_25%,color-mix(in_oklab,var(--primary)_14%,transparent),transparent_60%)]" />
    <div className="relative mt-[6vh] w-full max-w-2xl space-y-6 text-center">
      <div className="recessed mx-auto size-40 rounded-full p-2"><HoloOrb /></div>
      <div><p className="hud-label text-primary">Omni AI · Omni Site</p><h1 className="font-display text-4xl tracking-tight md:text-5xl">What are we building?</h1>
        <p className="mt-2 text-sm text-muted-foreground">Describe your website or app. Omni AI builds it live, explains every step and keeps improving it with you.</p></div>
      <form className="holo glow-frame space-y-2 p-3 text-left" onSubmit={(e) => { e.preventDefault(); void run(prompt); }}>
        <textarea autoFocus value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={4} aria-label="What are we building?" placeholder="A booking site for my barbershop with services, gallery and online appointments…"
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void run(prompt); } }} className="w-full resize-none bg-transparent p-2 text-sm outline-none" />
        <div className="flex items-center gap-2"><EnhanceButton value={prompt} onChange={setPrompt} studio="website" disabled={busy} />
          <Button className="bevel ml-auto" disabled={!prompt.trim() || busy}><Send />Start building</Button></div>
      </form>
      <div className="flex flex-wrap justify-center gap-2">{STARTERS.map((s) => <button key={s} onClick={() => setPrompt(`A ${s.toLowerCase()} — `)} className="extrude rounded-full px-3 py-1 text-xs">{s}</button>)}</div>
      {!!projects.data?.length && <div className="text-left"><p className="hud-label mb-2">Your Omni Site projects</p>
        <div className="grid gap-2 sm:grid-cols-2">{projects.data.slice(0, 8).map((p) => <button key={p.id} onClick={() => open(p)} className="extrude flex items-center gap-2 rounded-lg p-3 text-left text-sm"><Globe className="size-4 shrink-0 text-primary" /><span className="truncate">{p.title}</span><span className="ml-auto shrink-0 text-xs text-muted-foreground">{new Date(p.created_at).toLocaleDateString()}</span></button>)}</div></div>}
    </div>
  </div>;

  /* ───────── Workspace ───────── */
  const aiEdits = turns.filter((t) => t.role === "ai").length; const messages = turns.filter((t) => t.role === "user").length;
  const tab = (v: View, icon: ReactNode, label: string) => <Button size="sm" variant={view === v ? "default" : "ghost"} className={view === v ? "bevel" : ""} onClick={() => setView(v)}>{icon}<span className="hidden sm:inline">{label}</span></Button>;
  const widths = { desktop: "w-full", tablet: "w-[768px] max-w-full", mobile: "w-[390px] max-w-full" };

  return <div className="flex h-full min-w-0 flex-col gap-2 overflow-hidden p-2 lg:flex-row">
    {/* Omni AI sidebar */}
    <aside className="holo hud-corners flex min-h-0 w-full shrink-0 flex-col overflow-hidden max-lg:h-[45%] lg:w-[360px]">
      <div className="flex items-center gap-2 border-b p-2.5">
        <div className="recessed size-10 shrink-0 rounded-full p-0.5"><HoloOrb /></div>
        <div className="min-w-0 flex-1"><input aria-label="Project name" value={title} onChange={(e) => setTitle(e.target.value)} onBlur={() => projectId && void save().catch(() => {})} className="w-full bg-transparent font-display text-sm outline-none" />
          <p className="text-[11px] text-muted-foreground">Omni AI · {busy ? "building…" : `${aiEdits} AI edits`}</p></div>
        <Button size="icon-sm" variant="outline" title="New project" onClick={fresh}><FilePlus2 /></Button>
      </div>
      <div className="min-h-0 flex-1 space-y-2 overflow-y-auto p-3 text-sm">
        {turns.map((t, i) => <div key={i} className={`whitespace-pre-wrap rounded-lg px-3 py-2 ${t.role === "user" ? "ml-8 bg-primary/15" : "mr-4 border border-border/60 bg-secondary/60"}`}>
          {t.role === "ai" && <p className="hud-label mb-1 text-primary">Omni AI</p>}{t.text}</div>)}
        {busy && <div className="mr-4 space-y-1 rounded-lg border border-primary/40 bg-secondary/60 px-3 py-2 text-muted-foreground">
          <p className="flex items-center gap-2"><Loader2 className="size-4 animate-spin text-primary" />Omni AI is {html ? "applying your change" : "building your first version"}…</p></div>}
        {!busy && errors.length > 0 && <div className="mr-4 rounded-lg border border-destructive/50 bg-destructive/10 p-3">
          <p className="mb-2 font-medium">I found {errors.length} issue{errors.length > 1 ? "s" : ""} in the preview.</p>
          <p className="mb-2 font-mono text-xs text-muted-foreground">{errors.at(-1)?.text}</p>
          <div className="flex gap-2"><Button size="xs" className="bevel" onClick={() => { const list = errors.slice(-5).map((e) => e.text).join("\n"); setLogs([]); void run(`Fix these runtime errors without changing the design:\n${list}`); }}><Wrench />Try to fix</Button>
            <Button size="xs" variant="ghost" onClick={() => setLogs((l) => l.filter((x) => x.level !== "error"))}>Dismiss</Button></div></div>}
        <div ref={chatEnd} />
      </div>
      <form className="space-y-2 border-t p-2.5" onSubmit={(e) => { e.preventDefault(); void run(prompt); }}>
        <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={3} placeholder="Tell Omni AI what to change…" aria-label="Message Omni AI"
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void run(prompt); } }} className="w-full resize-none rounded-md border bg-background/60 p-2 text-sm outline-none focus:border-primary/60" />
        <div className="flex gap-2"><EnhanceButton value={prompt} onChange={setPrompt} studio="website" disabled={busy} />
          <Button size="sm" className="bevel ml-auto" disabled={busy || !prompt.trim()}>{busy ? <Loader2 className="animate-spin" /> : <Send />}Send</Button></div>
      </form>
    </aside>

    {/* Right canvas */}
    <section className={`holo hud-corners flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden ${busy ? "glow-active hud-trace" : ""}`}>
      <div className="flex flex-wrap items-center gap-1 border-b p-2">
        {tab("preview", <Eye />, "Preview")}{tab("files", <Files />, "Files")}{tab("code", <Code2 />, "Code")}{tab("more", <Layers />, "Project")}
        {view === "preview" && <div className="ml-auto flex gap-1">
          <Button size="icon-sm" variant={device === "desktop" ? "secondary" : "ghost"} title="Desktop" onClick={() => setDevice("desktop")}><Monitor /></Button>
          <Button size="icon-sm" variant={device === "tablet" ? "secondary" : "ghost"} title="Tablet" onClick={() => setDevice("tablet")}><Tablet /></Button>
          <Button size="icon-sm" variant={device === "mobile" ? "secondary" : "ghost"} title="Phone" onClick={() => setDevice("mobile")}><Smartphone /></Button>
          <Button size="icon-sm" variant="ghost" title="Reload preview" onClick={() => setReloadKey((k) => k + 1)}><RefreshCw /></Button>
          <Button size="icon-sm" variant="ghost" title="Open in new tab" disabled={!html} onClick={() => window.open(URL.createObjectURL(new Blob([html], { type: "text/html" })), "_blank", "noopener")}><ExternalLink /></Button>
        </div>}
        {view === "code" && <Button size="sm" variant="outline" className="bevel ml-auto" disabled={!html} onClick={() => downloadZip(slug(title))}><Download />Download codebase</Button>}
      </div>
      <div className="min-h-0 flex-1 overflow-hidden">
        {view === "preview" && (!html ? <div className="grid h-full place-items-center text-sm text-muted-foreground">{busy ? <span className="flex items-center gap-2"><Loader2 className="animate-spin text-primary" />Building your preview…</span> : "Your live preview appears here."}</div>
          : !settings.livePreview && busy ? <div className="grid h-full place-items-center text-sm text-muted-foreground">Live preview is off — showing the latest version when the build finishes.</div>
          : <div className="flex h-full justify-center overflow-auto bg-background p-2"><iframe key={reloadKey} ref={frame} title="Live preview" sandbox="allow-scripts allow-forms allow-modals allow-popups" srcDoc={srcDoc} className={`h-full rounded-md border bg-card ${widths[device]}`} /></div>)}

        {view === "files" && <div className="h-full overflow-y-auto p-4">
          <div className="mb-4 flex items-center gap-2"><h2 className="font-display text-lg">Files</h2>
            <label className="ml-auto"><input type="file" multiple className="sr-only" onChange={(e) => { void uploadFiles(e.target.files); e.target.value = ""; }} /><span className="bevel inline-flex cursor-pointer items-center gap-2 rounded-md px-3 py-1.5 text-sm"><Upload className="size-4" />Upload files</span></label></div>
          <label onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); void uploadFiles(e.dataTransfer.files); }} className="recessed mb-4 grid cursor-pointer place-items-center rounded-xl border border-dashed border-primary/40 p-8 text-center text-sm text-muted-foreground">
            <input type="file" multiple className="sr-only" onChange={(e) => { void uploadFiles(e.target.files); e.target.value = ""; }} />
            <Upload className="mb-2 size-6 text-primary" />Drop images, logos, documents or videos for Omni AI to use. Stored privately in your account.</label>
          {!assets.data?.length ? <p className="text-center text-sm text-muted-foreground">No files yet.</p>
            : <ul className="space-y-1">{assets.data.map((f) => <li key={f.name} className="extrude flex items-center gap-2 rounded px-3 py-2 text-sm"><FileCode2 className="size-4 text-primary" /><button className="truncate text-left hover:underline" onClick={() => void openAsset(f.name)}>{f.name.replace(/^\d+-/, "")}</button>
              <span className="ml-auto text-xs text-muted-foreground">{((f.metadata?.size ?? 0) / 1024).toFixed(1)} KB</span><Button size="icon-xs" variant="ghost" title="Delete" onClick={() => void removeAsset(f.name)}><Trash2 /></Button></li>)}</ul>}
        </div>}

        {view === "code" && (!html ? <div className="grid h-full place-items-center text-sm text-muted-foreground">No code yet.</div> : <div className="flex h-full min-h-0">
          <nav aria-label="Project files" className="w-44 shrink-0 overflow-y-auto border-r bg-card/40 p-2 text-xs">
            <span className="hud-label mb-1 flex items-center gap-1 text-primary"><FolderOpen className="size-3" /><span className="truncate">{slug(title)}</span></span>
            {FILE_NAMES.map((n) => <button key={n} onClick={() => setFile(n)} className={`extrude mb-1 flex w-full items-center gap-2 rounded px-2 py-1.5 font-mono ${file === n ? "bg-primary/15" : "text-muted-foreground"}`}><FileCode2 className="size-3.5 text-primary" /><span className="truncate">{n}</span></button>)}
          </nav>
          <div className="flex min-w-0 flex-1 flex-col"><div className="flex items-center border-b px-3 py-1 text-xs"><span className="font-mono">{file}</span><Button size="xs" variant="ghost" className="ml-auto" onClick={() => { void navigator.clipboard.writeText(files[file]); toast.success("Copied"); }}><Copy />Copy</Button></div>
            <textarea aria-label={`Edit ${file}`} value={files[file]} onChange={(e) => setHtml(joinSite({ ...files, [file]: e.target.value }))} onBlur={() => projectId && void save().catch(() => {})} spellCheck={false} className="min-h-0 flex-1 resize-none bg-transparent p-4 font-mono text-xs leading-5 outline-none" /></div>
        </div>)}

        {view === "more" && <div className="flex h-full min-h-0">
          <nav aria-label="Project settings" className="w-48 shrink-0 overflow-y-auto border-r p-2 text-sm max-sm:w-14">
            {SECTIONS.map(([id, label, Icon]) => <button key={id} onClick={() => setSection(id)} title={label} className={`mb-0.5 flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left ${section === id ? "bg-primary/15 text-foreground shadow-[inset_0_0_0_1px_color-mix(in_oklab,var(--primary)_50%,transparent)]" : "text-muted-foreground hover:bg-secondary"}`}><Icon className="size-4 shrink-0" /><span className="truncate max-sm:hidden">{label}</span></button>)}
          </nav>
          <div className="min-w-0 flex-1 overflow-y-auto p-5">
            <SettingsPanel section={section} s={settings} update={update} title={title} setTitle={setTitle} owner={user.email ?? "You"} createdAt={createdAt}
              messages={messages} aiEdits={aiEdits} turns={turns} logs={logs} html={html} assetsCount={assets.data?.length ?? 0} published={settings.published}
              onSave={() => void save().then(() => toast.success("Saved")).catch((e) => toast.error(String(e?.message ?? e)))} onZip={() => downloadZip(slug(title))} onRemix={duplicate} onDelete={destroy} />
          </div>
        </div>}
      </div>
      <div className="flex items-center gap-2 border-t px-3 py-1 font-mono text-[11px] text-muted-foreground">
        <span className={errors.length ? "text-destructive" : "text-success"}>●</span>{errors.length ? `${errors.length} preview error${errors.length > 1 ? "s" : ""}` : "Preview healthy"}
        <span className="ml-auto truncate">{settings.subdomain ? `${settings.subdomain}.omnisite.app` : "not published"}</span></div>
    </section>
  </div>;
}

/* ───────── Project settings panels ───────── */
type PanelProps = {
  section: Section; s: SiteSettings; update: <K extends keyof SiteSettings>(k: K, v: SiteSettings[K]) => void; title: string; setTitle: (t: string) => void;
  owner: string; createdAt: string | null; messages: number; aiEdits: number; turns: Turn[]; logs: Log[]; html: string; assetsCount: number; published: boolean;
  onSave: () => void; onZip: () => void; onRemix: () => void; onDelete: () => void;
};
function Head({ title, desc }: { title: string; desc: string }) { return <div className="mb-5"><h2 className="font-display text-xl">{title}</h2><p className="text-sm text-muted-foreground">{desc}</p></div>; }
function Card({ children, title }: { children: ReactNode; title?: string }) { return <div className="holo mb-4 divide-y divide-border/50 rounded-xl">{title && <p className="hud-label px-4 py-2 text-primary">{title}</p>}{children}</div>; }
function Row({ label, desc, children }: { label: string; desc?: string; children: ReactNode }) {
  return <div className="flex items-center gap-4 px-4 py-3"><div className="min-w-0 flex-1"><p className="text-sm font-medium">{label}</p>{desc && <p className="text-xs text-muted-foreground">{desc}</p>}</div><div className="shrink-0">{children}</div></div>;
}
function Stat({ label, value }: { label: string; value: string | number }) { return <div className="extrude rounded-lg p-3"><p className="text-xs text-muted-foreground">{label}</p><p className="font-display text-2xl text-primary">{value}</p></div>; }
function Feature({ icon: Icon, title, desc, cta, on, onToggle }: { icon: typeof Bot; title: string; desc: string; cta: string; on: boolean; onToggle: (v: boolean) => void }) {
  return <div className="holo glow-frame mx-auto max-w-lg overflow-hidden rounded-xl text-center">
    <div className="grid h-40 place-items-center bg-[radial-gradient(circle_at_50%_60%,color-mix(in_oklab,var(--accent)_35%,transparent),transparent_70%)]"><Icon className="size-14 text-primary drop-shadow-[0_0_18px_var(--primary)]" /></div>
    <div className="space-y-3 p-5"><h3 className="font-display text-lg">{title}</h3><p className="text-sm text-muted-foreground">{desc}</p>
      <Button className="bevel w-full" variant={on ? "outline" : "default"} onClick={() => onToggle(!on)}>{on ? `Disable ${cta.toLowerCase()}` : `Enable ${cta.toLowerCase()}`}</Button>
      {on && <p className="text-xs text-success">Enabled — Omni AI will include this in your next build.</p>}</div></div>;
}

function SettingsPanel(p: PanelProps) {
  const { s, update } = p;
  const pages = (p.html.match(/<section\b/gi) ?? []).length;
  switch (p.section) {
    case "analytics": return <><Head title="Analytics & SEO / AI search" desc="Visitor traffic and how discoverable your project is to search engines and AI assistants." />
      <div className="mb-4 grid grid-cols-2 gap-2 md:grid-cols-4"><Stat label="Visitors" value={p.published ? 0 : "—"} /><Stat label="Page views" value={p.published ? 0 : "—"} /><Stat label="Sections" value={pages} /><Stat label="Page size" value={`${(p.html.length / 1024).toFixed(0)}k`} /></div>
      {!p.published && <p className="mb-4 text-sm text-muted-foreground">Visitor numbers start once the project is published.</p>}
      <Card title="SEO & AI search check">{[["Page title", /<title>[^<]+<\/title>/i], ["Meta description", /name=["']description["']/i], ["Social preview (og:title)", /property=["']og:title["']/i], ["Single main heading", /<h1\b/i], ["Image alt text", /<img(?![^>]*alt=)/i], ["Mobile viewport", /name=["']viewport["']/i]].map(([l, re], i) => {
        const ok = l === "Image alt text" ? !(re as RegExp).test(p.html) : (re as RegExp).test(p.html);
        return <Row key={i} label={l as string}><span className={ok ? "text-success" : "text-destructive"}>{p.html ? (ok ? "Pass" : "Missing") : "—"}</span></Row>; })}</Card></>;
    case "database": return <><Head title="Database" desc="Tables that store your project's data." />
      <Card><Row label="Project database" desc="Ask Omni AI to add data storage — e.g. “save booking requests”. Tables will appear here.">
        <span className="text-xs text-muted-foreground">No tables yet</span></Row></Card></>;
    case "users": return <><Head title="Users" desc="People who sign up to your published project." />
      <Card><Row label="Sign-ups" desc="Ask Omni AI to add accounts (email or Google sign-in) to start collecting users."><span className="text-xs text-muted-foreground">0 users</span></Row></Card></>;
    case "storage": return <><Head title="Storage" desc="Files uploaded to this project." />
      <div className="grid grid-cols-2 gap-2"><Stat label="Files" value={p.assetsCount} /><Stat label="Code size" value={`${(p.html.length / 1024).toFixed(1)} KB`} /></div></>;
    case "ai": return <><Head title="AI" desc="How Omni AI works on this project." />
      <Card><Row label="AI edits" desc="Builds and changes made by Omni AI"><span className="font-display text-primary">{p.aiEdits}</span></Row>
        <Row label="AI app context" desc="Let Omni AI use context from your app's AI calls to debug and improve it."><Switch checked={s.aiContext} onCheckedChange={(v) => update("aiContext", v)} /></Row></Card></>;
    case "agents": return <><Head title="Agent integrations" desc="Your app isn't just for people anymore. It's for AI too." />
      <Feature icon={Bot} title="Let AI assistants use your app" desc="Publish once and let ChatGPT, Claude and other AI assistants use your project directly." cta="Agent integrations" on={s.agentIntegrations} onToggle={(v) => update("agentIntegrations", v)} /></>;
    case "payments": return <><Head title="Payments" desc="Accept payments if you want to sell from your project." />
      <Feature icon={CreditCard} title="Accept payments" desc="Sell products, subscriptions or bookings. Omni AI adds checkout to your project when enabled." cta="Payments" on={s.payments} onToggle={(v) => update("payments", v)} /></>;
    case "emails": return <><Head title="Emails" desc="Send emails from your project — confirmations, receipts and notifications." />
      <Feature icon={Mail} title="Send emails from your app" desc="Booking confirmations, welcome emails and receipts sent automatically." cta="Emails" on={s.emails} onToggle={(v) => update("emails", v)} /></>;
    case "connectors": return <><Head title="Connectors" desc="The following services are connected to your project." />
      <Card>{["Google Drive", "Slack", "Notion", "Shopify", "Stripe", "GitHub"].map((c) => <Row key={c} label={c}><Button size="xs" variant="outline" asChild><Link to="/studio/$id" params={{ id: "connectors" }}>Manage in Omni Connect</Link></Button></Row>)}</Card></>;
    case "security": {
      const issues = [[/<form(?![^>]*action=["']https)/i.test(p.html) && /<form/i.test(p.html), "Form submits without a secure destination"], [/http:\/\//i.test(p.html), "Insecure http:// links or resources"], [/eval\(|innerHTML\s*=/.test(p.html), "Unsafe dynamic code (eval / innerHTML)"], [/<a [^>]*target=["']_blank["'](?![^>]*rel=)/i.test(p.html), "External links missing rel=noopener"]] as const;
      const found = issues.filter(([b]) => b);
      return <><Head title="Security" desc="Scans the project being built so everything stays safe and secure." />
        <Card title={`Scan results · ${found.length} issue${found.length === 1 ? "" : "s"}`}>{!p.html ? <Row label="Nothing to scan yet"><span /></Row> : found.length === 0 ? <Row label="No issues found"><span className="text-success">Secure</span></Row> : found.map(([, t]) => <Row key={t} label={t}><span className="text-destructive">Review</span></Row>)}</Card>
        <Card><Row label="Auto-fix security issues" desc="Automatically fix low-risk scan issues. Uses a small amount of credits per fix."><Switch checked={s.autoFixSecurity} onCheckedChange={(v) => update("autoFixSecurity", v)} /></Row>
          <Row label="Trust center" desc="Make Omni Site security observations publicly discoverable for this published project."><Switch checked={s.trustCenter} onCheckedChange={(v) => update("trustCenter", v)} /></Row></Card></>;
    }
    case "usage": {
      const days = new Map<string, number>(); p.turns.filter((t) => t.role === "ai" && t.at).forEach((t) => { const d = t.at!.slice(0, 10); days.set(d, (days.get(d) ?? 0) + 1); });
      const month = new Date().toISOString().slice(0, 7); const thisMonth = [...days].filter(([d]) => d.startsWith(month)).reduce((a, [, n]) => a + n, 0);
      const today = days.get(new Date().toISOString().slice(0, 10)) ?? 0; const max = Math.max(1, ...days.values());
      return <><Head title="Usage" desc="AI activity on this project by day and month. Credits are charged from your Omni wallet." />
        <div className="mb-4 grid grid-cols-3 gap-2"><Stat label="Today" value={today} /><Stat label="This month" value={thisMonth} /><Stat label="All time" value={p.aiEdits} /></div>
        <Card title="AI edits per day"><div className="flex h-36 items-end gap-1 px-4 py-3">{[...days].slice(-30).map(([d, n]) => <div key={d} title={`${d}: ${n}`} className="flex-1 rounded-t bg-gradient-to-t from-accent to-primary" style={{ height: `${(n / max) * 100}%` }} />)}{days.size === 0 && <p className="m-auto text-xs text-muted-foreground">No activity yet</p>}</div></Card>
        <Button variant="outline" asChild><Link to="/studio/$id" params={{ id: "connectors" }}>View wallet balance</Link></Button></>;
    }
    case "general": return <><Head title="Settings" desc="Everything about your project." />
      <Card title="Project"><Row label="Project name"><input value={p.title} onChange={(e) => p.setTitle(e.target.value)} onBlur={p.onSave} className="w-56 rounded-md border bg-background/60 px-2 py-1 text-sm" /></Row>
        <Row label="URL subdomain"><span className="flex items-center text-sm"><input value={s.subdomain} onChange={(e) => update("subdomain", slug(e.target.value))} className="w-36 rounded-md border bg-background/60 px-2 py-1" /><span className="ml-1 text-muted-foreground">.omnisite.app</span></span></Row>
        <Row label="Owner"><span className="text-sm">{p.owner}</span></Row><Row label="Created"><span className="text-sm">{p.createdAt ? new Date(p.createdAt).toLocaleDateString() : "—"}</span></Row>
        <Row label="Messages"><span className="text-sm">{p.messages}</span></Row><Row label="AI edits"><span className="text-sm">{p.aiEdits}</span></Row>
        <Row label="Prototype" desc="Mark this project as a prototype in your Omni Site workspace."><Switch checked={s.prototype} onCheckedChange={(v) => update("prototype", v)} /></Row></Card>
      <Card title="Design system"><Row label="Palette" desc="Colors Omni AI builds this project with."><div className="flex gap-1">{s.palette.map((c, i) => <input key={i} type="color" aria-label={`Color ${i + 1}`} value={c} onChange={(e) => update("palette", s.palette.map((x, j) => (j === i ? e.target.value : x)))} className="size-7 cursor-pointer rounded border-0 bg-transparent" />)}</div></Row>
        <Row label="Fonts"><select value={s.fontPair} onChange={(e) => update("fontPair", e.target.value)} className="rounded-md border bg-background px-2 py-1 text-sm">{["Space Grotesk / DM Sans", "Syne / Plus Jakarta Sans", "Sora / Manrope", "Instrument Serif / Work Sans", "Bebas Neue / Barlow"].map((f) => <option key={f}>{f}</option>)}</select></Row></Card>
      <Card title="Project monitoring"><Row label="Regular health checks" desc="Checks the project for issues and improvements. Each check uses credits and is stored in history."><Switch checked={s.monitoring} onCheckedChange={(v) => update("monitoring", v)} /></Row></Card>
      <Card title="Preview"><Row label="Live preview" desc="Update the preview while Omni AI builds. Off shows the latest finished version."><Switch checked={s.livePreview} onCheckedChange={(v) => update("livePreview", v)} /></Row></Card>
      <Card title="Publishing"><Row label="Project category" desc="Help others find your project."><select value={s.category} onChange={(e) => update("category", e.target.value)} className="rounded-md border bg-background px-2 py-1 text-sm"><option value="">Select category</option>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></Row>
        <Row label="Hide Omni Site badge" desc="Premium — remove the “Built with Omni Site” badge."><Switch checked={s.hideBadge} disabled onCheckedChange={(v) => update("hideBadge", v)} /></Row>
        <Row label="Visitor analytics"><Switch checked={s.visitorAnalytics} onCheckedChange={(v) => update("visitorAnalytics", v)} /></Row>
        <Row label={s.published ? "Unpublish project" : "Publish project"} desc={s.published ? "The published URL will no longer be accessible." : "Make your project live at its subdomain."}><Button size="sm" variant={s.published ? "outline" : "default"} className="bevel" disabled={!p.html} onClick={() => update("published", !s.published)}>{s.published ? "Unpublish" : "Publish"}</Button></Row></Card>
      <Card title="Sharing"><Row label="Public remixing" desc="Anyone with the link can copy and remix the latest version."><Switch checked={s.publicRemix} onCheckedChange={(v) => update("publicRemix", v)} /></Row>
        <Row label="Cross-project sharing"><Switch checked={s.crossProject} onCheckedChange={(v) => update("crossProject", v)} /></Row>
        <Row label="Remix project" desc="Duplicate into a new project."><Button size="sm" variant="outline" onClick={p.onRemix}>Remix</Button></Row>
        <Row label="Transfer ownership / move workspace" desc="Available once team workspaces launch."><Button size="sm" variant="outline" disabled>Transfer</Button></Row>
        <Row label="Delete project" desc="Permanently remove this project."><Button size="sm" variant="destructive" onClick={p.onDelete}><Trash2 />Delete</Button></Row></Card></>;
    case "secrets": return <><Head title="Secrets" desc="Private keys your project uses. They are never shown in your site's code." />
      <Card><Row label="OMNISITE_APP_SECRET" desc="Managed by Omni Site — created automatically when your project needs a backend."><span className="text-xs text-muted-foreground">Not created yet</span></Row>
        <Row label="OMNISITE_API_KEY" desc="Lets your project call Omni AI models. Created automatically when you ask Omni AI to add an AI feature."><span className="text-xs text-muted-foreground">Not created yet</span></Row></Card></>;
    case "logs": return <><Head title="Logs" desc="Activity and errors from the preview." />
      <div className="holo scanline max-h-[60vh] overflow-y-auto rounded-xl p-3 font-mono text-xs leading-5">{p.logs.length === 0 ? <p className="text-muted-foreground">No logs yet.</p> : p.logs.map((l, i) => <div key={i} className={l.level === "error" ? "text-destructive" : l.level === "ok" ? "text-success" : "text-muted-foreground"}><span className="opacity-50">{l.at} </span>{l.text}</div>)}</div></>;
    case "knowledge": return <><Head title="Knowledge" desc="Help Omni AI understand your project — its purpose, audience, tone and rules. Sent with every request." />
      <textarea value={s.knowledge} onChange={(e) => update("knowledge", e.target.value)} rows={12} placeholder="e.g. This is a booking site for Fade Lab barbershop in Austin. Tone: confident and friendly. Always show prices in USD…" className="holo w-full resize-none rounded-xl p-4 text-sm outline-none" /></>;
    case "domains": return <><Head title="Domains" desc="Use your own web address for this project." />
      <Card><Row label="Omni Site address"><span className="font-mono text-sm">{s.subdomain || "—"}.omnisite.app</span></Row>
        <Row label="Connect your own domain" desc="Enter a domain you already own."><input value={s.customDomain} onChange={(e) => update("customDomain", e.target.value.trim().toLowerCase())} placeholder="mybusiness.com" className="w-48 rounded-md border bg-background/60 px-2 py-1 text-sm" /></Row>
        <Row label="Buy a new domain" desc="Domain purchases cost extra and are coming soon."><Button size="sm" variant="outline" disabled>Buy domain</Button></Row></Card></>;
    case "git": return <><Head title="Git" desc="Sync your code with a repository or download it." />
      <Card>{["GitHub", "GitLab", "Bitbucket"].map((g) => <Row key={g} label={`Connect ${g}`} desc="Repository sync is coming soon."><Button size="sm" variant="outline" disabled><GitBranch />Connect</Button></Row>)}
        <Row label="Download repository" desc="All project files as a ZIP."><Button size="sm" className="bevel" disabled={!p.html} onClick={p.onZip}><Download />Download</Button></Row></Card></>;
  }
}
