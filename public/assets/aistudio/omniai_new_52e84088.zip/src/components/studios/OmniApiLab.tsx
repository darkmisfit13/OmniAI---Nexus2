import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { Loader2, Webhook, Send, Copy, Play, Check } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { generate } from "@/lib/ai.functions";
import { useAccount } from "@/components/AccountProvider";

const METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE"];

export function OmniApiLab() {
  const { user } = useAccount();
  const gen = useServerFn(generate);
  const [method, setMethod] = useState("POST");
  const [path, setPath] = useState("/api/payments/webhook");
  const [body, setBody] = useState('{\n  "type": "payment.succeeded",\n  "amount": 4900\n}');
  const [busy, setBusy] = useState(false);
  const [response, setResponse] = useState("");
  const [copied, setCopied] = useState(false);

  if (!user) return <div className="grid h-full place-items-center p-6"><Button asChild><Link to="/auth">Sign in to simulate integrations</Link></Button></div>;

  const curl = `curl -X ${method} https://api.yourapp.com${path} \\\n  -H "Content-Type: application/json" \\\n  -H "Authorization: Bearer <token>"${method !== "GET" ? ` \\\n  -d '${body.replace(/\n/g, "")}'` : ""}`;

  const simulate = async () => {
    if (busy) return;
    setBusy(true); setResponse("");
    try {
      const result = await gen({ data: { studio: "api-lab", prompt: `Simulate this API interaction and return a realistic JSON response plus a one-line explanation of what the integration does:\n${method} ${path}\nBody: ${body || "(none)"}`, refs: [] } });
      setResponse(result?.text ?? "");
    } catch (e) { toast.error(e instanceof Error ? e.message : "Simulation failed."); }
    finally { setBusy(false); }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-y-auto p-4">
      <div className="grid min-h-0 flex-1 gap-3 lg:grid-cols-2">
        <section className="holo hud-corners flex flex-col gap-3 p-4">
          <span className="hud-label"><Webhook className="mr-1 inline size-3" />Request builder</span>
          <div className="flex gap-2">
            <select value={method} onChange={(e) => setMethod(e.target.value)} aria-label="HTTP method" className="rounded-md border bg-background/60 p-2 font-mono text-sm">{METHODS.map((m) => <option key={m}>{m}</option>)}</select>
            <input value={path} onChange={(e) => setPath(e.target.value)} aria-label="Request path" className="min-w-0 flex-1 rounded-md border bg-background/60 p-2 font-mono text-sm" />
          </div>
          {method !== "GET" && (
            <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={8} aria-label="Request body"
              className="w-full flex-1 resize-none rounded-md border bg-background/60 p-3 font-mono text-xs outline-none focus:ring-2 focus:ring-ring" />
          )}
          <Button className="bevel" disabled={busy} onClick={() => void simulate()}>{busy ? <Loader2 className="animate-spin" /> : <Play />}Simulate request</Button>
          <div className="recessed space-y-1 p-3">
            <div className="flex items-center justify-between"><span className="hud-label">cURL export</span><Button variant="outline" size="icon-sm" aria-label="Copy cURL" className="bevel" onClick={async () => { await navigator.clipboard.writeText(curl); setCopied(true); setTimeout(() => setCopied(false), 1500); }}>{copied ? <Check /> : <Copy />}</Button></div>
            <pre className="overflow-auto font-mono text-[10px] text-muted-foreground">{curl}</pre>
          </div>
        </section>
        <section className="holo hud-corners flex flex-col gap-2 p-4">
          <span className="hud-label"><Send className="mr-1 inline size-3" />Simulated response</span>
          <div className="recessed min-h-0 flex-1 overflow-auto p-3">
            {busy && <span className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" /> Running simulation…</span>}
            {!busy && !response && <p className="text-sm text-muted-foreground">The simulated JSON response and integration notes appear here.</p>}
            {response && <pre className="whitespace-pre-wrap font-mono text-xs text-success">{response}</pre>}
          </div>
        </section>
      </div>
    </div>
  );
}
