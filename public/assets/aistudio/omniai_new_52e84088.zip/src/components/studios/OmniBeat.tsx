import { useEffect, useState } from "react";
import { Upload, Check, RotateCcw } from "lucide-react";

const stages = ["Scene Planning", "Image Synthesis", "Creative Breeze Sync", "Master Render"];
const logLines = [
  "[router] allocating GPU cluster omni-h200-x8…", "[audio] beat grid detected: 120 BPM, 4/4", "[audio] 14 sections, 3 drops located",
  "[planner] storyboard: 18 scenes generated", "[planner] camera language: dolly / orbit / whip", "[synth] diffusion pass 1/3 — seed 48213",
  "[synth] diffusion pass 2/3 — style lock applied", "[synth] diffusion pass 3/3 — upscaling 4K", "[sync] aligning cuts to transients…",
  "[sync] lip-sync phonemes mapped", "[render] encoding H.265 10-bit", "[render] master export complete ✓",
];

export function OmniBeat() {
  const [stage, setStage] = useState<"setup" | "run">("setup");
  const [track, setTrack] = useState("Neon Nights");
  const [img, setImg] = useState<string | null>(null);
  const [prompt, setPrompt] = useState("Cyberpunk rooftop performance, rain, neon reflections, slow motion");
  const [ratio, setRatio] = useState("16:9");
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (stage !== "run" || step >= logLines.length) return;
    const id = setTimeout(() => setStep((s) => s + 1), 650);
    return () => clearTimeout(id);
  }, [stage, step]);

  const doneStages = Math.floor((step / logLines.length) * stages.length);

  if (stage === "setup") return (
    <div className="grid h-full grid-cols-2 gap-2 p-2">
      <section className="holo hud-corners min-h-0 space-y-4 overflow-y-auto p-5">
        <h3 className="text-sm font-semibold">1 · Target track</h3>
        <div className="grid grid-cols-2 gap-2">
          {["Neon Nights", "Gravity Bloom", "Concrete Halo", "Upload track…"].map((t) => (
            <button key={t} onClick={() => setTrack(t)} className={`extrude rounded-lg p-3 text-left text-sm ${track === t ? "glow-active bg-primary/10 text-primary" : ""}`}>{t}</button>
          ))}
        </div>
        <h3 className="pt-2 text-sm font-semibold">2 · Source image</h3>
        <label className="glow-frame flex aspect-video cursor-pointer flex-col items-center justify-center gap-2 overflow-hidden rounded-xl bg-secondary text-sm text-muted-foreground">
          {img ? <img src={img} alt="Source" className="h-full w-full object-cover" /> : <><Upload className="size-6 text-primary" />Upload character or reference image</>}
          <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) setImg(URL.createObjectURL(f)); }} />
        </label>
      </section>
      <section className="holo hud-corners flex min-h-0 flex-col gap-4 p-5">
        <h3 className="text-sm font-semibold">3 · Cinematic prompt</h3>
        <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} className="min-h-40 flex-1 rounded-lg bg-secondary p-3 text-sm outline-none" />
        <h3 className="text-sm font-semibold">4 · Aspect ratio lock</h3>
        <div className="flex gap-2">
          {["16:9", "9:16", "1:1", "4:5"].map((r) => (
            <button key={r} onClick={() => setRatio(r)} className={`extrude flex-1 rounded-md py-2 text-sm ${ratio === r ? "bg-primary text-primary-foreground" : ""}`}>{r}</button>
          ))}
        </div>
        <button onClick={() => { setStep(0); setStage("run"); }} className="bevel rounded-lg bg-brand py-3 font-semibold text-primary-foreground">Generate music video</button>
      </section>
    </div>
  );

  return (
    <div className="grid h-full grid-cols-2 gap-2 p-2">
      <section className="holo hud-corners flex min-h-0 flex-col p-4">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold">Execution log · {track} · {ratio}</h3>
          <button onClick={() => setStage("setup")} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-primary"><RotateCcw className="size-3" /> New</button>
        </div>
        <div className="min-h-0 flex-1 space-y-1 overflow-y-auto rounded-lg recessed p-3 font-mono text-xs">
          {logLines.slice(0, step).map((l, i) => <p key={i} className={i === step - 1 ? "text-primary" : "text-muted-foreground"}>{l}</p>)}
          {step < logLines.length && <p className="animate-pulse text-primary">▋</p>}
        </div>
      </section>
      <section className="holo hud-corners flex min-h-0 flex-col gap-3 overflow-y-auto p-4">
        {stages.map((s, i) => {
          const done = i < doneStages || step >= logLines.length, active = i === doneStages && !done;
          return (
            <div key={s} className={`extrude flex items-center gap-4 rounded-xl p-5 ${done ? "border-primary/60 bg-primary/10 shadow-glow" : active ? "glow-active bg-accent/10" : "opacity-60"}`}>
              <span className={`grid size-9 place-items-center rounded-full text-sm font-bold ${done ? "bg-primary text-primary-foreground" : "bg-muted"}`}>{done ? <Check className="size-4" /> : i + 1}</span>
              <div><p className="font-semibold">{s}</p><p className="text-xs text-muted-foreground">{done ? "Complete" : active ? "Running…" : "Queued"}</p></div>
            </div>
          );
        })}
        {step >= logLines.length && <div className="grid aspect-video place-items-center rounded-xl bg-brand font-semibold text-primary-foreground">▶ Master render ready</div>}
      </section>
    </div>
  );
}
