import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { Loader2, PenTool, Download, Plus, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { generate } from "@/lib/ai.functions";
import { EnhanceButton } from "@/components/MediaComposer";
import { useAccount } from "@/components/AccountProvider";
import { useCreditApproval } from "@/components/CreditApprovalProvider";

const DEFAULT_PALETTE = ["#00f2fe", "#7f00ff", "#0575e6", "#0B0B0C"];

export function OmniVector() {
  const { user } = useAccount();
  const gen = useServerFn(generate);
  const authorizeCredits = useCreditApproval();
  const [brand, setBrand] = useState("");
  const [prompt, setPrompt] = useState("");
  const [palette, setPalette] = useState<string[]>(DEFAULT_PALETTE);
  const [busy, setBusy] = useState(false);
  const [art, setArt] = useState<string | null>(null);

  if (!user) return <div className="grid h-full place-items-center p-6"><Button asChild><Link to="/auth">Sign in to build brand art</Link></Button></div>;

  const run = async () => {
    if (!prompt.trim() || busy) return;
    setBusy(true); setArt(null);
    const detailed = `${brand ? `Brand: ${brand}. ` : ""}${prompt}. Use this brand palette: ${palette.join(", ")}. Flat vector style, crisp edges, no gradients unless asked.`.slice(0, 4000);
    try {
      const approvalId = await authorizeCredits({ operation: "image", target: "vector", prompt: detailed, refUrls: [] });
      const result = await gen({ data: { studio: "vector", prompt: detailed, refs: [], approvalId } });
      if (result?.url) setArt(result.url);
      else toast.error("No artwork came back. Try again.");
    } catch (e) { toast.error(e instanceof Error ? e.message : "Vector generation failed."); }
    finally { setBusy(false); }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-y-auto p-4">
      <div className="grid min-h-0 flex-1 gap-3 lg:grid-cols-2">
        <section className="holo hud-corners flex flex-col gap-3 p-4">
          <span className="hud-label">Brand brief</span>
          <input value={brand} onChange={(e) => setBrand(e.target.value)} placeholder="Brand name (e.g. Northbeam)" aria-label="Brand name"
            className="rounded-md border bg-background/60 p-2 text-sm outline-none focus:ring-2 focus:ring-ring" />
          <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={4} aria-label="Artwork prompt"
            placeholder="Minimal geometric logo mark — a mountain peak inside a circle…"
            className="w-full resize-none rounded-md border bg-background/60 p-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          <EnhanceButton value={prompt} onChange={setPrompt} studio="vector" disabled={busy} />
          <div>
            <span className="hud-label">Brand palette</span>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              {palette.map((c, i) => (
                <span key={i} className="group relative">
                  <input type="color" value={c} aria-label={`Palette color ${i + 1}`} onChange={(e) => setPalette((all) => all.map((x, j) => (j === i ? e.target.value : x)))} className="size-9 cursor-pointer rounded-md border border-border bg-transparent" />
                  {palette.length > 1 && <button type="button" aria-label="Remove color" onClick={() => setPalette((all) => all.filter((_, j) => j !== i))} className="absolute -right-1 -top-1 hidden rounded-full bg-background p-0.5 group-hover:block"><X className="size-3" /></button>}
                </span>
              ))}
              {palette.length < 8 && <Button type="button" variant="outline" size="icon-sm" aria-label="Add color" onClick={() => setPalette((all) => [...all, "#ffffff"])}><Plus /></Button>}
            </div>
          </div>
          <Button className="mt-auto bevel" disabled={busy || !prompt.trim()} onClick={() => void run()}>
            {busy ? <Loader2 className="animate-spin" /> : <PenTool />}Generate brand artwork
          </Button>
        </section>
        <section className="holo hud-corners flex flex-col gap-3 p-4">
          <span className="hud-label">Artwork</span>
          <div className="recessed grid flex-1 place-items-center overflow-hidden p-2">
            {busy && <span className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" /> Drawing…</span>}
            {!busy && art && <img src={art} alt="Generated brand artwork" className="max-h-full w-full rounded-md object-contain" />}
            {!busy && !art && <span className="text-sm text-muted-foreground">Generated artwork appears here.</span>}
          </div>
          {art && <a href={art} download="omnivector.png" className="inline-flex items-center gap-1 text-xs text-primary"><Download className="size-3" /> Download artwork</a>}
        </section>
      </div>
    </div>
  );
}
