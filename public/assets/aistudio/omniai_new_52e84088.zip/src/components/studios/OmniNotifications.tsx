import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { BellRing, CheckCheck, FlaskConical, Loader2, Radio, Save, ShieldCheck, Terminal, Webhook, Wrench } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useAccount } from "@/components/AccountProvider";
import { getNotifications, saveNotifications, testNotificationWebhook } from "@/lib/notifications.functions";
import { notificationSettingsSchema, validateWebhook } from "@/lib/notifications";

const defaults = { webhook_url: "", generation_enabled: false, security_enabled: false, compilation_enabled: false };
const events = [
  { key: "generation_enabled", label: "On Generative Task Completion (Image/Video/Audio)", Icon: BellRing },
  { key: "security_enabled", label: "On Authentication Event or Security Audit Bridge Violation", Icon: ShieldCheck },
  { key: "compilation_enabled", label: "On OmniCode Compilation Failure / Self-Healing Trigger", Icon: Wrench },
] as const;
export function OmniNotifications() {
  const { user } = useAccount(); const qc = useQueryClient();
  const read = useServerFn(getNotifications), save = useServerFn(saveNotifications), test = useServerFn(testNotificationWebhook);
  const query = useQuery({ queryKey: ["notifications", user?.id], queryFn: () => read(), enabled: !!user, refetchInterval: 5000 });
  const [form, setForm] = useState(defaults); const [busy, setBusy] = useState<"save" | "test" | null>(null); const [error, setError] = useState(""); const [message, setMessage] = useState("");
  const loaded = useRef(false); const terminal = useRef<HTMLDivElement>(null);
  useEffect(() => { if (query.data && !loaded.current) { const s = query.data.settings; setForm(s ? notificationSettingsSchema.parse(s) : defaults); loaded.current = true; } }, [query.data]);
  useEffect(() => { if (terminal.current) terminal.current.scrollTop = terminal.current.scrollHeight; }, [query.data?.logs]);
  const linked = !!query.data?.settings?.verified_at && query.data.settings.webhook_url === form.webhook_url;
  const dirty = JSON.stringify(form) !== JSON.stringify(query.data?.settings ? notificationSettingsSchema.parse(query.data.settings) : defaults);
  async function act(mode: "save" | "test") {
    setBusy(mode); setError(""); setMessage("");
    try {
      const data = notificationSettingsSchema.parse(form); if (data.webhook_url) validateWebhook(data.webhook_url);
      await save({ data });
      if (mode === "test") await test({ data: { webhook_url: data.webhook_url } });
      setMessage(mode === "test" ? "Test payload delivered." : "Notification settings saved.");
    } catch (e) { setError(e instanceof Error ? e.message : "Notification request failed."); }
    finally { await qc.invalidateQueries({ queryKey: ["notifications", user?.id] }); setBusy(null); }
  }
  return <div className="notification-deck flex min-h-0 flex-1 flex-col overflow-y-auto p-4">
    <header className="mb-5 flex flex-wrap items-center gap-3 border-b pb-4">
      <Webhook className="size-6 text-primary" /><div><h2 className="font-display text-lg font-semibold">Notification gateway</h2><p className="hud-label">Workstation event routing</p></div>
      <div role="status" className={`notification-link ml-auto flex max-w-full items-center gap-2 rounded-md border px-3 py-2 font-mono text-[10px] ${linked ? "border-primary/50 text-primary" : "border-warning/40 text-warning"}`}>
        {linked ? <CheckCheck className="size-4 shrink-0" /> : <Radio className="size-4 shrink-0 motion-safe:animate-pulse" />}<span>{linked ? "OMNICONNECT EDGE GATEWAY LINKED" : "preview - not connected"}</span>
      </div>
    </header>
    <section aria-labelledby="webhook-heading" className="mb-5 space-y-3">
      <h3 id="webhook-heading" className="hud-label text-primary">A / Webhook endpoints</h3>
      <label className="block text-sm" htmlFor="notification-url">Global Workstation Notification Webhook</label>
      <div className="flex flex-wrap gap-2"><Input id="notification-url" type="url" autoComplete="off" value={form.webhook_url} onChange={(e) => { setForm({ ...form, webhook_url: e.target.value }); setMessage(""); }} placeholder="https://hook.eu1.make.com/…" className="min-w-0 flex-1 basis-60 bg-background/60 font-mono text-xs" />
        <Button variant="outline" disabled={!!busy || !form.webhook_url || query.isLoading} onClick={() => void act("test")} className="h-auto min-h-9 whitespace-normal text-primary">{busy === "test" ? <Loader2 className="animate-spin" /> : <FlaskConical />}Test Webhook Payload</Button></div>
    </section>
    <section aria-labelledby="events-heading" className="mb-4">
      <h3 id="events-heading" className="hud-label mb-2 text-accent">B / Event-driven notifications</h3>
      {events.map(({ key, label, Icon }) => <div key={key} className="flex items-center gap-3 border-b py-4"><Icon className="size-4 shrink-0 text-primary" /><label htmlFor={key} className="flex-1 text-sm leading-5">{label}</label><Switch id={key} checked={form[key]} disabled={!!busy || query.isLoading} onCheckedChange={(checked) => setForm({ ...form, [key]: checked })} /></div>)}
    </section>
    <div className="mb-4 flex flex-wrap items-center gap-3"><Button disabled={!!busy || query.isLoading || !dirty} onClick={() => void act("save")}>{busy === "save" ? <Loader2 className="animate-spin" /> : <Save />}Save settings</Button>{message && <p role="status" className="text-xs text-primary">{message}</p>}{(error || query.error) && <p role="alert" className="text-xs text-destructive">{error || query.error?.message}</p>}</div>
    <section className="glow-frame notification-terminal mt-auto shrink-0 overflow-hidden rounded-md border bg-background" aria-label="Webhook payload stream">
      <header className="flex items-center gap-2 border-b bg-card px-3 py-2"><Terminal className="size-4 text-primary" /><span className="font-mono text-xs">PAYLOAD STREAM</span><span className="ml-auto font-mono text-[10px] text-muted-foreground">{query.data?.logs.length ?? 0} EVENTS</span></header>
      <div ref={terminal} role="log" aria-live="polite" className="h-52 overflow-auto p-3 font-mono text-[11px] leading-5">
        {!query.data?.logs.length ? <div className="text-muted-foreground"><p className="mb-2 text-warning">MOCK PREVIEW / NOT DISPATCHED</p><pre>{JSON.stringify({ timestamp: "—", actor_id: "current_user", task_type: "generation_completed", credits_deducted: null }, null, 2)}</pre></div> : [...query.data.logs].reverse().map((log) => <div key={log.id} className="mb-3 border-b pb-3"><p className={log.status === "delivered" ? "text-primary" : log.status === "failed" ? "text-destructive" : "text-warning"}>{log.status.toUpperCase()}{log.http_status ? ` / HTTP ${log.http_status}` : ""}</p><pre className="text-muted-foreground">{JSON.stringify(log.payload, null, 2)}</pre></div>)}
      </div>
    </section>
  </div>;
}