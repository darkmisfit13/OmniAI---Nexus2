import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { Loader2, Upload, Shirt, ScanFace, Download, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { generate } from "@/lib/ai.functions";
import { EnhanceButton, type MediaRef } from "@/components/MediaComposer";
import { useAccount } from "@/components/AccountProvider";
import { useCreditApproval } from "@/components/CreditApprovalProvider";

const readAsDataUrl = (file: File) => new Promise<string>((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(String(r.result)); r.onerror = () => reject(r.error); r.readAsDataURL(file); });

function Slider({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <label className="block text-xs text-muted-foreground">{label}
      <div className="mt-1 flex items-center gap-2">
        <input type="range" min={0} max={100} value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full accent-primary" aria-label={label} />
        <span className="w-8 text-right font-mono text-xs text-primary">{value}</span>
      </div>
    </label>
  );
}

function UploadTile({ label, icon: Icon, media, onPick, onClear }: { label: string; icon: typeof Upload; media: MediaRef | null; onPick: (f: File) => void; onClear: () => void }) {
  const input = useRef<HTMLInputElement>(null);
  return (
    <div className="recessed relative grid min-h-32 place-items-center overflow-hidden p-2 text-center">
      {media ? (
        <>
          {media.mediaType.startsWith("video/") ? <video src={media.url} muted className="max-h-40 w-full rounded-md object-contain" /> : <img src={media.url} alt={label} className="max-h-40 w-full rounded-md object-contain" />}
          <button type="button" aria-label={`Remove ${label}`} onClick={onClear} className="absolute right-1 top-1 rounded-full bg-background/80 p-1"><X className="size-3" /></button>
        </>
      ) : (
        <button type="button" onClick={() => input.current?.click()} className="flex flex-col items-center gap-1 text-xs text-muted-foreground hover:text-primary">
          <Icon className="size-5" />{label}
        </button>
      )}
      <input ref={input} type="file" accept="image/*,video/*" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) onPick(f); e.target.value = ""; }} />
    </div>
  );
}

export function OmniStyle() {
  const { user } = useAccount();
  const gen = useServerFn(generate);
  const authorizeCredits = useCreditApproval();
  const [base, setBase] = useState<MediaRef | null>(null);
  const [anchor, setAnchor] = useState<MediaRef | null>(null);
  const [prompt, setPrompt] = useState("");
  const [expression, setExpression] = useState(50);
  const [matchWeight, setMatchWeight] = useState(70);
  const [skinBlend, setSkinBlend] = useState(60);
  const [lightMatch, setLightMatch] = useState(65);
  const [busy, setBusy] = useState(false);
  const [after, setAfter] = useState<string | null>(null);

  if (!user) return <div className="grid h-full place-items-center p-6"><Button asChild><Link to="/auth">Sign in to restyle photos</Link></Button></div>;

  const pick = (setter: (m: MediaRef) => void) => async (f: File) => {
    if (!f.type.startsWith("image/") && !f.type.startsWith("video/")) { toast.error("Images or video frames only."); return; }
    if (f.size > 10 * 1024 * 1024) { toast.error("Max 10 MB."); return; }
    setter({ url: await readAsDataUrl(f), mediaType: f.type, filename: f.name });
  };

  const run = async () => {
    if (!base || !prompt.trim() || busy) return;
    setBusy(true); setAfter(null);
    const refs = [base, ...(anchor ? [anchor] : [])];
    const detailed = [
      `Wardrobe / appearance change: ${prompt}.`,
      anchor ? "A face identity anchor image is attached as the second reference — keep the person's identity consistent with it (identity-guided edit; a dedicated face-swap provider is not connected)." : "",
      `Facial expression intensity ${expression}/100, identity matching weight ${matchWeight}/100, skin tone blend ${skinBlend}/100, lighting & shadow matching ${lightMatch}/100.`,
    ].filter(Boolean).join(" ").slice(0, 4000);
    try {
      const approvalId = await authorizeCredits({ operation: "image", target: "style", prompt: detailed, refUrls: refs.map((r) => r.url) });
      const result = await gen({ data: { studio: "style", prompt: detailed, refs, approvalId } });
      if (result?.url) setAfter(result.url);
      else toast.error("No edit came back. Try again.");
    } catch (e) { toast.error(e instanceof Error ? e.message : "Style edit failed."); }
    finally { setBusy(false); }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-y-auto p-4">
      <div className="grid min-h-0 flex-1 gap-3 lg:grid-cols-3">
        <section className="holo hud-corners flex flex-col gap-3 p-4">
          <span className="hud-label">Source & identity</span>
          <UploadTile label="Drop in a photo or video frame" icon={Upload} media={base} onPick={(f) => void pick(setBase)(f)} onClear={() => setBase(null)} />
          <UploadTile label="Face identity anchor (optional)" icon={ScanFace} media={anchor} onPick={(f) => void pick(setAnchor)(f)} onClear={() => setAnchor(null)} />
          <p className="text-[11px] text-muted-foreground">The identity anchor guides likeness in the edit. True face-swap needs a dedicated provider connection.</p>
        </section>
        <section className="holo hud-corners flex flex-col gap-3 p-4">
          <span className="hud-label">Wardrobe & look console</span>
          <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={4} aria-label="Wardrobe prompt"
            placeholder="Change the outfit to a tailored midnight-blue suit with a silver tie…"
            className="w-full resize-none rounded-md border bg-background/60 p-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          <EnhanceButton value={prompt} onChange={setPrompt} studio="style" disabled={busy} />
          <Slider label="Facial expression" value={expression} onChange={setExpression} />
          <Slider label="Identity matching weight" value={matchWeight} onChange={setMatchWeight} />
          <Slider label="Skin tone blend" value={skinBlend} onChange={setSkinBlend} />
          <Slider label="Lighting & shadow match" value={lightMatch} onChange={setLightMatch} />
          <Button className="mt-auto bevel" disabled={busy || !base || !prompt.trim()} onClick={() => void run()}>
            {busy ? <Loader2 className="animate-spin" /> : <Shirt />}Apply style change
          </Button>
        </section>
        <section className="holo hud-corners flex flex-col gap-3 p-4">
          <span className="hud-label">Before / After</span>
          <div className="grid flex-1 grid-rows-2 gap-2">
            <div className="recessed grid place-items-center overflow-hidden p-1">
              {base ? (base.mediaType.startsWith("video/") ? <video src={base.url} muted controls className="max-h-full w-full rounded-md object-contain" /> : <img src={base.url} alt="Before" className="max-h-full w-full rounded-md object-contain" />) : <span className="text-xs text-muted-foreground">Before</span>}
            </div>
            <div className="recessed relative grid place-items-center overflow-hidden p-1">
              {busy && <span className="flex items-center gap-2 text-xs text-muted-foreground"><Loader2 className="size-4 animate-spin" /> Editing…</span>}
              {!busy && after && <img src={after} alt="After" className="max-h-full w-full rounded-md object-contain" />}
              {!busy && !after && <span className="text-xs text-muted-foreground">After</span>}
            </div>
          </div>
          {after && <a href={after} download="omnistyle.png" className="inline-flex items-center gap-1 text-xs text-primary"><Download className="size-3" /> Download result</a>}
        </section>
      </div>
    </div>
  );
}
