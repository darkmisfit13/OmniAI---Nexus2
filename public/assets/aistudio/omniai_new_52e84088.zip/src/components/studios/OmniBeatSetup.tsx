import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AudioLines, ImagePlus, ArrowRight, Loader2, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { EnhanceButton } from "@/components/MediaComposer";
import { OmniStatusGauge } from "@/components/OmniStatusGauge";
import { OmniBeatBudget } from "./OmniBeatBudget";
import { DEFAULT_BUDGET, type BudgetConfig } from "@/lib/omnibeat-budget";
import { supabase } from "@/integrations/supabase/client";
import { useAccount } from "@/components/AccountProvider";
import type { ProductionAsset, ProductionState } from "@/lib/music-video";
export function OmniBeatSetup() {
  const { user } = useAccount(); const navigate = useNavigate(); const [track, setTrack] = useState<File | null>(null), [images, setImages] = useState<File[]>([]), [prompt, setPrompt] = useState("");
  const [config, setConfig] = useState<BudgetConfig>(DEFAULT_BUDGET), [approval, setApproval] = useState<string | null>(null), [busy, setBusy] = useState(false);
  const [previews, setPreviews] = useState<string[]>([]), [trackUrl, setTrackUrl] = useState("");
  const saved = useQuery({ queryKey: ["music-productions", user?.id], enabled: !!user, queryFn: async () => { const r = await supabase.from("studio_projects").select("id,title").eq("kind", "music-production").order("created_at", { ascending: false }); if (r.error) throw r.error; return r.data; } });
  async function submit() {
    if (!user || !track || !prompt.trim() || !images.length || !approval || busy) return; setBusy(true);
    try {
      const upload = async (f: File, duration = 0): Promise<ProductionAsset> => { const path = `${user.id}/music-video/${crypto.randomUUID()}-${f.name.replace(/[^\w.-]/g, "_")}`; const r = await supabase.storage.from("studio-assets").upload(path, f, { contentType: f.type }); if (r.error) throw r.error; return { path, name: f.name, mediaType: f.type, duration }; };
      const duration = await new Promise<number>((resolve, reject) => { const a = document.createElement("audio"); a.onloadedmetadata = () => resolve(a.duration); a.onerror = () => reject(new Error("Track could not be decoded.")); a.src = trackUrl; });
      const state: ProductionState = { track: await upload(track, duration), references: await Promise.all(images.map((f) => upload(f))), prompt, config: { ...config, stopped: false }, authorizationId: approval, stage: 0, results: {}, images: [], clips: [], logs: [{ role: "assistant", content: "Track and performer received. Ready to analyze your song." }], paused: false, correctionCount: 0, renderSeconds: 0, final: [] };
      const r = await supabase.from("studio_projects").insert({ user_id: user.id, studio: "music-video", kind: "music-production", title: track.name.replace(/\.[^.]+$/, ""), state: JSON.parse(JSON.stringify(state)) }).select("id").single(); if (r.error) throw r.error;
      await navigate({ to: "/music-video/$projectId", params: { projectId: r.data.id } });
    } catch (e) { toast.error(e instanceof Error ? e.message : "Production could not be started."); } finally { setBusy(false); }
  }
  return <div className="flex h-full min-h-0 gap-2 overflow-hidden p-2">
    <aside className="holo hidden w-64 shrink-0 flex-col gap-3 overflow-y-auto p-3 md:flex xl:w-72"><span className="hud-label text-primary">Omni · Film director</span><OmniStatusGauge /><p className="text-sm text-muted-foreground">Your track. Your performer. Your world.</p><div className="mt-auto space-y-2"><span className="hud-label">Saved productions</span>{saved.data?.map((p) => <Button key={p.id} asChild variant="ghost" className="w-full justify-start truncate"><Link to="/music-video/$projectId" params={{ projectId: p.id }}><span className="truncate">{p.title}</span></Link></Button>)}</div></aside>
    <main className="min-h-0 min-w-0 flex-1 overflow-y-auto px-2 py-3 sm:px-5">
      <div className="mx-auto max-w-4xl"><span className="hud-label text-primary">OmniBeat / New production</span><h2 className="mb-6 mt-2 text-3xl">Create your music film</h2>
      <div className="grid gap-5 md:grid-cols-2"><section className="space-y-3"><h3 className="flex items-center gap-2 text-sm"><AudioLines className="size-4 text-primary" />01 · Music track</h3><label className="recessed flex min-h-32 cursor-pointer flex-col items-center justify-center gap-3 p-4 text-sm"><AudioLines className="size-7 text-primary" /><span className="max-w-full truncate">{track?.name ?? "Upload a song"}</span><input aria-label="Music track" type="file" accept="audio/mpeg,audio/wav,audio/x-wav,audio/mp4,audio/ogg,audio/flac,audio/webm,audio/aac" hidden onChange={(e) => { const f = e.target.files?.[0]; if (!f) return; if (f.size > 20 * 1024 * 1024) { toast.error("Track must be under 20 MB."); return; } if (trackUrl) URL.revokeObjectURL(trackUrl); setTrack(f); setTrackUrl(URL.createObjectURL(f)); }} /></label>{trackUrl && <audio src={trackUrl} controls className="w-full" />}</section>
      <section className="space-y-3"><h3 className="flex items-center gap-2 text-sm"><ImagePlus className="size-4 text-accent" />02 · Performer & references</h3><label className="recessed flex min-h-32 cursor-pointer flex-col items-center justify-center gap-3 p-4 text-sm"><ImagePlus className="size-7 text-accent" /><span>Upload character images</span><input aria-label="Performer reference images" type="file" multiple accept="image/png,image/jpeg,image/webp" hidden onChange={(e) => { const files = Array.from(e.target.files ?? []); if (files.some((f) => f.size > 10 * 1024 * 1024)) { toast.error("Images must be under 10 MB."); return; } const next = [...images, ...files].slice(0, 8); previews.forEach(URL.revokeObjectURL); setImages(next); setPreviews(next.map((f) => URL.createObjectURL(f))); }} /></label><div className="flex flex-wrap gap-2">{previews.map((url, i) => <div key={url} className="relative size-16 overflow-hidden rounded-md border"><img src={url} alt={images[i]?.name ?? "Performer reference"} className="size-full object-cover" /><Button aria-label={`Remove reference ${i + 1}`} size="icon-xs" variant="outline" className="absolute right-0 top-0" onClick={() => { URL.revokeObjectURL(url); setImages((all) => all.filter((_, n) => n !== i)); setPreviews((all) => all.filter((_, n) => n !== i)); }}><X /></Button></div>)}</div></section></div>
      <section className="my-6 space-y-3"><h3 className="text-sm">03 · Creative direction</h3><div className="recessed p-3"><textarea aria-label="Music video prompt" value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Describe the performer, visual world, mood and movement…" rows={3} className="w-full resize-none bg-transparent text-sm outline-none" /><EnhanceButton value={prompt} onChange={setPrompt} studio="music-video" disabled={busy} /></div></section>
      <OmniBeatBudget value={config} onChange={(v) => { setConfig(v); setApproval(null); }} onAuthorized={setApproval} />
      <div className="py-5"><Button className="h-12 w-full" disabled={busy || !user || !track || !images.length || !prompt.trim() || !approval || config.stopped} onClick={() => void submit()}>{busy ? <Loader2 className="animate-spin" /> : <ArrowRight />}Submit production</Button>{config.stopped && <p className="mt-2 text-xs text-muted-foreground">Turn off the stop estimate to authorize a new production.</p>}{!user && <Button asChild variant="link"><Link to="/auth">Sign in to create</Link></Button>}</div>
      </div>
    </main>
  </div>;
}