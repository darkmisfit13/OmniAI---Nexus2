import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { Loader2, Component, Copy, Send, Check } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { generate } from "@/lib/ai.functions";
import { EnhanceButton } from "@/components/MediaComposer";
import { useAccount } from "@/components/AccountProvider";

const STARTERS = [
  { name: "Glass pricing card", code: `<div class="rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur-md">\n  <h3 class="text-lg font-bold">Pro</h3>\n  <p class="text-3xl font-mono">$49<span class="text-sm">/mo</span></p>\n  <button class="mt-4 w-full rounded-lg bg-cyan-400 py-2 font-semibold text-black">Upgrade</button>\n</div>` },
  { name: "Bevel toggle", code: `<button class="rounded-full border border-white/15 bg-gradient-to-b from-white/10 to-transparent px-4 py-2 shadow-[inset_0_1px_0_rgba(255,255,255,.2),0_2px_6px_rgba(0,0,0,.6)] active:translate-y-px">\n  Engage\n</button>` },
  { name: "HUD stat chip", code: `<span class="rounded border border-cyan-400/40 bg-cyan-400/10 px-2 py-0.5 font-mono text-xs text-cyan-300">SYS · NOMINAL</span>` },
];

export function OmniCosmicUI() {
  const { user } = useAccount();
  const gen = useServerFn(generate);
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);
  const [output, setOutput] = useState("");
  const [copied, setCopied] = useState<string | null>(null);

  if (!user) return <div className="grid h-full place-items-center p-6"><Button asChild><Link to="/auth">Sign in to generate components</Link></Button></div>;

  const run = async () => {
    if (!prompt.trim() || busy) return;
    setBusy(true); setOutput("");
    try {
      const result = await gen({ data: { studio: "cosmic-ui", prompt: `Generate a production-ready UI component (HTML + Tailwind classes, dark matte-black theme, cyan/violet accents) for: ${prompt}. Return the code plus a one-line usage note.`, refs: [] } });
      setOutput(result?.text ?? "");
    } catch (e) { toast.error(e instanceof Error ? e.message : "Generation failed."); }
    finally { setBusy(false); }
  };

  const copy = async (key: string, text: string) => { await navigator.clipboard.writeText(text); setCopied(key); setTimeout(() => setCopied(null), 1500); };

  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-y-auto p-4">
      <section className="holo hud-corners shrink-0 space-y-2 p-4">
        <span className="hud-label"><Component className="mr-1 inline size-3" />Component generator</span>
        <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={2} aria-label="Component prompt"
          placeholder="A glassmorphic pricing card with a glowing CTA…"
          className="w-full resize-none rounded-md border bg-background/60 p-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
        <div className="flex items-center gap-2">
          <EnhanceButton value={prompt} onChange={setPrompt} studio="cosmic-ui" disabled={busy} />
          <Button className="ml-auto bevel" disabled={busy || !prompt.trim()} onClick={() => void run()}>{busy ? <Loader2 className="animate-spin" /> : <Send />}Generate component</Button>
        </div>
      </section>
      {output && (
        <section className="holo hud-corners space-y-2 p-4">
          <div className="flex items-center justify-between"><span className="hud-label">Generated component</span><Button variant="outline" size="sm" className="bevel" onClick={() => void copy("gen", output)}>{copied === "gen" ? <Check /> : <Copy />}Copy code</Button></div>
          <pre className="recessed max-h-72 overflow-auto whitespace-pre-wrap p-3 font-mono text-xs text-primary/90">{output}</pre>
        </section>
      )}
      <section className="grid gap-3 md:grid-cols-3">
        {STARTERS.map((s) => (
          <div key={s.name} className="holo hud-corners space-y-2 p-4">
            <div className="flex items-center justify-between"><p className="text-sm font-semibold">{s.name}</p><Button variant="outline" size="icon-sm" aria-label={`Copy ${s.name}`} className="bevel" onClick={() => void copy(s.name, s.code)}>{copied === s.name ? <Check /> : <Copy />}</Button></div>
            <pre className="recessed max-h-40 overflow-auto p-2 font-mono text-[10px] text-muted-foreground">{s.code}</pre>
          </div>
        ))}
      </section>
    </div>
  );
}
