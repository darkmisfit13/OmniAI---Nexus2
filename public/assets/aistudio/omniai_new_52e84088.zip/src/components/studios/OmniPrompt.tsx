import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { Loader2, SquareTerminal, Play, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { askModel, CHAT_MODELS } from "@/lib/ai.functions";
import { EnhanceButton } from "@/components/MediaComposer";
import { listProjects, saveProject } from "@/lib/private.functions";
import { useAccount } from "@/components/AccountProvider";

export function OmniPrompt() {
  const { user } = useAccount();
  const ask = useServerFn(askModel);
  const save = useServerFn(saveProject);
  const load = useServerFn(listProjects);
  const qc = useQueryClient();
  const [prompt, setPrompt] = useState("");
  const [model, setModel] = useState(CHAT_MODELS[0]!.id);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState("");
  const saved = useQuery({ queryKey: ["prompts", user?.id], queryFn: () => load({ data: { studio: "prompt" } }), enabled: !!user });

  if (!user) return <div className="grid h-full place-items-center p-6"><Button asChild><Link to="/auth">Sign in to use the prompt studio</Link></Button></div>;

  const testRun = async () => {
    if (!prompt.trim() || busy) return;
    setBusy(true); setResult("");
    try {
      const r = await ask({ data: { model, messages: [{ role: "user", content: prompt }] } });
      setResult(r.text);
    } catch (e) { toast.error(e instanceof Error ? e.message : "Test run failed."); }
    finally { setBusy(false); }
  };

  const saveToLibrary = async () => {
    if (!prompt.trim()) return;
    try {
      await save({ data: { studio: "prompt", title: prompt.slice(0, 80), content: prompt } });
      await qc.invalidateQueries({ queryKey: ["prompts"] });
      toast.success("Prompt saved to your library.");
    } catch (e) { toast.error(e instanceof Error ? e.message : "Couldn't save prompt."); }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-hidden p-4">
      <div className="grid min-h-0 flex-1 gap-3 lg:grid-cols-3">
        <section className="holo hud-corners flex flex-col gap-3 p-4 lg:col-span-2">
          <span className="hud-label"><SquareTerminal className="mr-1 inline size-3" />Prompt workbench</span>
          <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={6} aria-label="Prompt"
            placeholder="A prompt that turns meeting notes into action items…"
            className="w-full resize-none rounded-md border bg-background/60 p-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          <div className="flex flex-wrap items-center gap-2">
            <EnhanceButton value={prompt} onChange={setPrompt} studio="prompt" disabled={busy} />
            <select value={model} onChange={(e) => setModel(e.target.value)} aria-label="Model" className="rounded-md border bg-background/60 p-1.5 text-xs">
              {CHAT_MODELS.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
            </select>
            <Button variant="outline" size="sm" className="bevel" disabled={!prompt.trim()} onClick={() => void saveToLibrary()}><Save />Save</Button>
            <Button size="sm" className="ml-auto bevel" disabled={busy || !prompt.trim()} onClick={() => void testRun()}>{busy ? <Loader2 className="animate-spin" /> : <Play />}Test run</Button>
          </div>
          <div className="recessed min-h-0 flex-1 overflow-auto p-3">
            {busy && <span className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" /> Running…</span>}
            {!busy && !result && <p className="text-sm text-muted-foreground">Test the prompt against a model — the response appears here.</p>}
            {result && <div className="whitespace-pre-wrap text-sm">{result}</div>}
          </div>
        </section>
        <section className="holo hud-corners flex min-h-0 flex-col gap-2 p-4">
          <span className="hud-label">Prompt library</span>
          <div className="min-h-0 flex-1 space-y-2 overflow-y-auto">
            {(saved.data ?? []).map((p) => (
              <button key={p.id} type="button" onClick={() => setPrompt(p.content ?? "")} className="group flex w-full items-start justify-between gap-2 rounded-md border border-border bg-background/50 p-2 text-left hover:border-primary/50">
                <span className="line-clamp-2 text-xs text-muted-foreground group-hover:text-foreground">{p.title}</span>
                <Trash2 className="size-3 shrink-0 opacity-0 group-hover:opacity-60" />
              </button>
            ))}
            {!saved.isLoading && (saved.data ?? []).length === 0 && <p className="text-xs text-muted-foreground">Saved prompts appear here.</p>}
          </div>
        </section>
      </div>
    </div>
  );
}
