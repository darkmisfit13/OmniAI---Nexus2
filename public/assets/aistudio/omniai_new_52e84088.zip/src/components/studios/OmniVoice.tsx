import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Mic, Languages, AudioWaveform, Download } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { generate } from "@/lib/ai.functions";
import { EnhanceButton } from "@/components/MediaComposer";
import { useAccount } from "@/components/AccountProvider";
import { Link } from "@tanstack/react-router";

type Tab = "voiceover" | "dubbing" | "enhance";
const TABS: { id: Tab; label: string; icon: typeof Mic }[] = [
  { id: "voiceover", label: "Voiceover", icon: Mic },
  { id: "dubbing", label: "Dubbing", icon: Languages },
  { id: "enhance", label: "Enhance", icon: AudioWaveform },
];
const LANGUAGES = ["Spanish", "French", "German", "Italian", "Portuguese", "Japanese", "Korean", "Hindi", "Arabic", "Mandarin"];
const TONES = ["Warm narrator", "Energetic promo", "Calm documentary", "Cinematic trailer", "Friendly conversational"];
const PACING = ["Relaxed", "Natural", "Brisk", "Dramatic pauses"];

export function OmniVoice() {
  const { user } = useAccount();
  const gen = useServerFn(generate);
  const [tab, setTab] = useState<Tab>("voiceover");
  const [script, setScript] = useState("");
  const [tone, setTone] = useState(TONES[0]!);
  const [pacing, setPacing] = useState(PACING[1]!);
  const [language, setLanguage] = useState(LANGUAGES[0]!);
  const [busy, setBusy] = useState(false);
  const [audio, setAudio] = useState<{ url: string; label: string } | null>(null);

  if (!user) return <div className="grid h-full place-items-center p-6"><Button asChild><Link to="/auth">Sign in to create voice audio</Link></Button></div>;

  const run = async () => {
    if (!script.trim() || busy) return;
    setBusy(true); setAudio(null);
    const prompt = tab === "dubbing"
      ? `Dub this script into ${language} with natural native delivery, ${tone.toLowerCase()} tone, ${pacing.toLowerCase()} pacing:\n\n${script}`
      : tab === "enhance"
        ? `Re-record this script with enhanced studio clarity, cleaned pacing and polished delivery, ${tone.toLowerCase()} tone:\n\n${script}`
        : `${tone} voiceover, ${pacing.toLowerCase()} pacing:\n\n${script}`;
    try {
      const result = await gen({ data: { studio: "voice", prompt: prompt.slice(0, 4000), refs: [] } });
      if (result?.url) setAudio({ url: result.url, label: tab === "dubbing" ? `${language} dub` : tab });
      else toast.error("No audio came back. Try again.");
    } catch (e) { toast.error(e instanceof Error ? e.message : "Voice generation failed."); }
    finally { setBusy(false); }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-y-auto p-4">
      <div className="flex gap-2">
        {TABS.map((t) => <Button key={t.id} variant={tab === t.id ? "default" : "outline"} size="sm" className="bevel" onClick={() => setTab(t.id)}><t.icon />{t.label}</Button>)}
      </div>
      <div className="grid min-h-0 flex-1 gap-3 lg:grid-cols-2">
        <section className="holo hud-corners flex flex-col gap-3 p-4">
          <span className="hud-label">{tab === "dubbing" ? "Script to dub" : tab === "enhance" ? "Script to enhance" : "Voiceover script"}</span>
          <textarea value={script} onChange={(e) => setScript(e.target.value)} rows={8} aria-label="Script"
            placeholder={tab === "dubbing" ? "Paste the original-language script…" : "Welcome to the future of sound…"}
            className="min-h-40 flex-1 resize-none rounded-md border bg-background/60 p-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          <div className="grid grid-cols-2 gap-2">
            <label className="text-xs text-muted-foreground">Tone
              <select value={tone} onChange={(e) => setTone(e.target.value)} className="mt-1 w-full rounded-md border bg-background/60 p-2 text-sm">{TONES.map((t) => <option key={t}>{t}</option>)}</select></label>
            {tab === "dubbing" ? (
              <label className="text-xs text-muted-foreground">Target language
                <select value={language} onChange={(e) => setLanguage(e.target.value)} className="mt-1 w-full rounded-md border bg-background/60 p-2 text-sm">{LANGUAGES.map((l) => <option key={l}>{l}</option>)}</select></label>
            ) : (
              <label className="text-xs text-muted-foreground">Pacing
                <select value={pacing} onChange={(e) => setPacing(e.target.value)} className="mt-1 w-full rounded-md border bg-background/60 p-2 text-sm">{PACING.map((p) => <option key={p}>{p}</option>)}</select></label>
            )}
          </div>
          <div className="flex items-center gap-2">
            <EnhanceButton value={script} onChange={setScript} studio="voice" disabled={busy} />
            <Button className="ml-auto bevel" disabled={busy || !script.trim()} onClick={() => void run()}>
              {busy ? <Loader2 className="animate-spin" /> : <Mic />}{tab === "dubbing" ? `Dub to ${language}` : tab === "enhance" ? "Enhance audio" : "Generate voiceover"}
            </Button>
          </div>
        </section>
        <section className="holo hud-corners flex flex-col gap-3 p-4">
          <span className="hud-label">Output monitor</span>
          {busy && <div className="recessed scanline flex flex-1 items-center justify-center gap-2 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" /> Synthesizing audio…</div>}
          {!busy && !audio && <div className="recessed flex flex-1 items-center justify-center text-sm text-muted-foreground">Your generated audio appears here.</div>}
          {audio && !busy && (
            <div className="flex flex-1 flex-col gap-3">
              <p className="text-sm font-semibold capitalize">{audio.label}</p>
              <audio src={audio.url} controls autoPlay className="w-full" />
              <a href={audio.url} download="omnivoice.mp3" className="inline-flex items-center gap-1 text-xs text-primary"><Download className="size-3" /> Download audio</a>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
