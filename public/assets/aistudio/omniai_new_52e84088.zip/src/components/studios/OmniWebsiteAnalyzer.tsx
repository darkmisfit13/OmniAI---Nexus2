import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { Loader2, ScanSearch, Globe } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { analyzeSite } from "@/lib/ai.functions";
import { useAccount } from "@/components/AccountProvider";

const SUGGESTIONS = ["https://yourstore.com", "https://tiktok.com/@yourhandle", "https://instagram.com/yourbrand", "https://facebook.com/yourpage"];

export function OmniWebsiteAnalyzer() {
  const { user } = useAccount();
  const analyze = useServerFn(analyzeSite);
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [report, setReport] = useState("");
  const [note, setNote] = useState("");

  if (!user) return <div className="grid h-full place-items-center p-6"><Button asChild><Link to="/auth">Sign in to audit sites</Link></Button></div>;

  const run = async () => {
    if (!url.trim() || busy) return;
    setBusy(true); setReport(""); setNote("");
    try {
      const r = await analyze({ data: { url } });
      setReport(r.text); setNote(r.fetchNote);
    } catch (e) { toast.error(e instanceof Error ? e.message : "Audit failed."); }
    finally { setBusy(false); }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-y-auto p-4">
      <section className="holo hud-corners shrink-0 space-y-3 p-4">
        <span className="hud-label"><ScanSearch className="mr-1 inline size-3" />Audit site structure</span>
        <p className="text-xs text-muted-foreground">Audit your website, TikTok, Instagram, Facebook — any public URL — and get a list of what needs fixing and updating.</p>
        <div className="flex gap-2">
          <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://mysite.com" aria-label="URL to audit"
            className="min-w-0 flex-1 rounded-md border bg-background/60 p-2 font-mono text-sm outline-none focus:ring-2 focus:ring-ring"
            onKeyDown={(e) => { if (e.key === "Enter") void run(); }} />
          <Button className="bevel" disabled={busy || !url.trim()} onClick={() => void run()}>{busy ? <Loader2 className="animate-spin" /> : <Globe />}Audit</Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {SUGGESTIONS.map((s) => <button key={s} type="button" onClick={() => setUrl(s)} className="hud-chip">{s}</button>)}
        </div>
      </section>
      <section className="holo hud-corners flex min-h-0 flex-1 flex-col gap-2 p-4">
        <span className="hud-label">Audit report</span>
        {note && <p className="text-[11px] text-muted-foreground">{note}</p>}
        <div className="min-h-0 flex-1 overflow-y-auto">
          {busy && <span className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" /> Crawling and auditing…</span>}
          {!busy && !report && <p className="text-sm text-muted-foreground">The audit report appears here — fixes, updates and what's already working.</p>}
          {report && <div className="whitespace-pre-wrap text-sm">{report}</div>}
        </div>
      </section>
    </div>
  );
}
