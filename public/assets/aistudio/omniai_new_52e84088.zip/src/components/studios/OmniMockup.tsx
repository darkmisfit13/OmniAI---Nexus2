import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { Smartphone, ShieldAlert, Archive, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { listAllProjects, saveProject } from "@/lib/private.functions";
import { useAccount } from "@/components/AccountProvider";

type Platform = { id: string; label: string; aspect: string; safe: { top: number; bottom: number; left: number; right: number } };
const PLATFORMS: Platform[] = [
  { id: "tiktok", label: "TikTok", aspect: "9/19.5", safe: { top: 12, bottom: 22, left: 4, right: 18 } },
  { id: "reels", label: "Instagram Reels", aspect: "9/19.5", safe: { top: 14, bottom: 24, left: 4, right: 16 } },
  { id: "shorts", label: "YouTube Shorts", aspect: "9/19.5", safe: { top: 10, bottom: 20, left: 4, right: 20 } },
  { id: "spotify", label: "Spotify Canvas", aspect: "9/16", safe: { top: 16, bottom: 26, left: 6, right: 6 } },
  { id: "appstore", label: "Apple App Store", aspect: "9/19.5", safe: { top: 8, bottom: 8, left: 6, right: 6 } },
];

export function OmniMockup() {
  const { user } = useAccount();
  const loadAll = useServerFn(listAllProjects);
  const save = useServerFn(saveProject);
  const qc = useQueryClient();
  const [platform, setPlatform] = useState<Platform>(PLATFORMS[0]!);
  const [handle, setHandle] = useState("@creator");
  const [caption, setCaption] = useState("");
  const [hashtags, setHashtags] = useState("");
  const [audioLabel, setAudioLabel] = useState("");
  const [safeOn, setSafeOn] = useState(true);
  const [asset, setAsset] = useState<{ url: string; title: string } | null>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [saving, setSaving] = useState(false);
  const phoneRef = useRef<HTMLDivElement>(null);

  const vault = useQuery({ queryKey: ["vault", user?.id], queryFn: () => loadAll(), enabled: !!user });
  const images = (vault.data ?? []).filter((p) => p.url && p.kind === "image");

  if (!user) return <div className="grid h-full place-items-center p-6"><Button asChild><Link to="/auth">Sign in to build mockups</Link></Button></div>;

  const onTilt = (e: React.PointerEvent) => {
    const box = phoneRef.current?.getBoundingClientRect();
    if (!box) return;
    const px = (e.clientX - box.left) / box.width - 0.5;
    const py = (e.clientY - box.top) / box.height - 0.5;
    setTilt({ x: -py * 14, y: px * 18 });
  };

  const pushToVault = async () => {
    if (!asset || saving) return;
    setSaving(true);
    try {
      await save({ data: { studio: "mockup", title: `${platform.label} mockup — ${asset.title}`, content: JSON.stringify({ platform: platform.id, handle, caption, hashtags, audioLabel, assetTitle: asset.title }, null, 2) } });
      await qc.invalidateQueries({ queryKey: ["vault"] });
      toast.success("Mockup pushed to your vault.");
    } catch (e) { toast.error(e instanceof Error ? e.message : "Couldn't save mockup."); }
    finally { setSaving(false); }
  };

  const s = platform.safe;
  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-hidden p-4">
      <div className="grid min-h-0 flex-1 gap-3 lg:grid-cols-4">
        <section className="holo hud-corners flex flex-col gap-3 overflow-y-auto p-4">
          <span className="hud-label">Placement configurator</span>
          <label className="text-xs text-muted-foreground">Platform
            <select value={platform.id} onChange={(e) => setPlatform(PLATFORMS.find((p) => p.id === e.target.value) ?? PLATFORMS[0]!)} className="mt-1 w-full rounded-md border bg-background/60 p-2 text-sm">
              {PLATFORMS.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
            </select></label>
          <label className="text-xs text-muted-foreground">Creator handle
            <input value={handle} onChange={(e) => setHandle(e.target.value)} className="mt-1 w-full rounded-md border bg-background/60 p-2 text-sm" /></label>
          <label className="text-xs text-muted-foreground">Caption & description
            <textarea value={caption} onChange={(e) => setCaption(e.target.value)} rows={2} className="mt-1 w-full resize-none rounded-md border bg-background/60 p-2 text-sm" /></label>
          <label className="text-xs text-muted-foreground">Hashtag injection
            <input value={hashtags} onChange={(e) => setHashtags(e.target.value)} placeholder="#fyp #launch" className="mt-1 w-full rounded-md border bg-background/60 p-2 text-sm" /></label>
          <label className="text-xs text-muted-foreground">Custom audio track label
            <input value={audioLabel} onChange={(e) => setAudioLabel(e.target.value)} placeholder="Original sound — …" className="mt-1 w-full rounded-md border bg-background/60 p-2 text-sm" /></label>
          <Button className="bevel" disabled={!asset || saving} onClick={() => void pushToVault()}>{saving ? <Loader2 className="animate-spin" /> : <Archive />}Push mockup to vault</Button>
        </section>

        <section className="holo hud-corners relative flex flex-col items-center justify-center gap-3 overflow-hidden p-4 lg:col-span-2" style={{ perspective: "900px" }}>
          <span className="hud-label absolute left-3 top-3">Interactive device sandbox</span>
          <div ref={phoneRef} onPointerMove={onTilt} onPointerLeave={() => setTilt({ x: 0, y: 0 })}
            className="relative w-56 overflow-hidden rounded-[2rem] border-2 border-border bg-black shadow-glow transition-transform duration-150"
            style={{ aspectRatio: platform.aspect, transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)` }}>
            {asset ? <img src={asset.url} alt={asset.title} className="absolute inset-0 size-full object-cover" /> : <div className="grid size-full place-items-center text-xs text-muted-foreground">Drag a vault asset here</div>}
            <div className="absolute inset-x-0 top-0 flex items-center justify-between p-3 text-[10px] text-white/90" style={{ textShadow: "0 1px 2px #000" }}>
              <span>{platform.label}</span><span>{handle}</span>
            </div>
            <div className="absolute inset-x-0 bottom-0 p-3 text-[10px] text-white/90" style={{ textShadow: "0 1px 2px #000" }}>
              {audioLabel && <p className="truncate">♪ {audioLabel}</p>}
              {caption && <p className="line-clamp-2">{caption}</p>}
              {hashtags && <p className="truncate text-cyan-300">{hashtags}</p>}
            </div>
            {safeOn && (
              <div className="pointer-events-none absolute inset-0">
                <div className="absolute inset-x-0 top-0 border-b border-dashed border-red-500/70 bg-red-500/15" style={{ height: `${s.top}%` }} />
                <div className="absolute inset-x-0 bottom-0 border-t border-dashed border-red-500/70 bg-red-500/15" style={{ height: `${s.bottom}%` }} />
                <div className="absolute inset-y-0 left-0 border-r border-dashed border-red-500/70 bg-red-500/15" style={{ width: `${s.left}%` }} />
                <div className="absolute inset-y-0 right-0 border-l border-dashed border-red-500/70 bg-red-500/15" style={{ width: `${s.right}%` }} />
              </div>
            )}
          </div>
          <label className="flex items-center gap-2 text-xs text-muted-foreground">
            <input type="checkbox" checked={safeOn} onChange={(e) => setSafeOn(e.target.checked)} className="accent-primary" /> Show platform safe zones
          </label>
        </section>

        <section className="flex min-h-0 flex-col gap-3 overflow-y-auto">
          <div className="holo hud-corners space-y-2 p-4">
            <span className="hud-label"><ShieldAlert className="mr-1 inline size-3" />{platform.label} safeguard report</span>
            <dl className="space-y-1 font-mono text-[11px] text-muted-foreground">
              <div className="flex justify-between"><dt>Top UI region (profile + title)</dt><dd className="text-primary">{s.top}%</dd></div>
              <div className="flex justify-between"><dt>Bottom UI region (buttons + captions)</dt><dd className="text-primary">{s.bottom}%</dd></div>
              <div className="flex justify-between"><dt>Left column</dt><dd className="text-primary">{s.left}%</dd></div>
              <div className="flex justify-between"><dt>Right column (like/comment/share)</dt><dd className="text-primary">{s.right}%</dd></div>
            </dl>
            <p className="text-[11px] text-muted-foreground">Keep vital text inside the clear region. The red grid shows where social app UI blocks your media.</p>
          </div>
          <div className="holo hud-corners flex min-h-0 flex-1 flex-col gap-2 p-4">
            <span className="hud-label"><Smartphone className="mr-1 inline size-3" />Vault assets</span>
            <div className="grid min-h-0 flex-1 auto-rows-min grid-cols-3 gap-2 overflow-y-auto">
              {vault.isLoading && <Loader2 className="size-4 animate-spin text-muted-foreground" />}
              {images.map((p) => (
                <button key={p.id} type="button" draggable onDragStart={(e) => e.dataTransfer.setData("text/asset", p.id)} onClick={() => setAsset({ url: p.url!, title: p.title })}
                  className={`overflow-hidden rounded-md border ${asset?.url === p.url ? "border-primary shadow-glow" : "border-border"}`}>
                  <img src={p.url!} alt={p.title} className="aspect-square w-full object-cover" />
                </button>
              ))}
              {!vault.isLoading && images.length === 0 && <p className="col-span-3 text-xs text-muted-foreground">No images in your vault yet — generate some in Omni Imagine.</p>}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
