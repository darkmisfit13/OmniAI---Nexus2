import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Github, CreditCard, FileText, Slack, Target, ShoppingBag, Youtube, Table, AudioLines, X, Loader2, RefreshCw, Trash2, Activity, KeyRound } from "lucide-react";
import { CONNECTORS } from "@/lib/connectors";
import { listConnections, saveConnection, refreshConnection } from "@/lib/connectors.functions";
import { useAccount } from "@/components/AccountProvider";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { OmniNotifications } from "./OmniNotifications";

const ICONS: Record<string, typeof Github> = { github: Github, stripe: CreditCard, notion: FileText, slack: Slack, hubspot: Target, shopify: ShoppingBag, youtube: Youtube, airtable: Table, elevenlabs: AudioLines };

export function OmniConnect() {
  const { user } = useAccount();
  const qc = useQueryClient();
  const list = useServerFn(listConnections), save = useServerFn(saveConnection), refresh = useServerFn(refreshConnection);
  const q = useQuery({ queryKey: ["connections", user?.id], queryFn: () => list(), enabled: !!user });
  const [open, setOpen] = useState<string | null>(null);
  const [form, setForm] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [view, setView] = useState<"accounts" | "notifications">("notifications");
  const def = CONNECTORS.find((c) => c.id === open);
  const conns = q.data ?? [];
  const byId = Object.fromEntries(conns.map((c) => [c.provider, c]));
  const reload = () => qc.invalidateQueries({ queryKey: ["connections"] });

  if (!user) return <div className="grid h-full place-items-center"><Button asChild><Link to="/auth">Sign in to connect your accounts</Link></Button></div>;

  const act = async (id: string, fn: () => Promise<unknown>) => {
    setBusy(id); setErr(null);
    try { await fn(); await reload(); return true; } catch (e) { setErr((e as Error).message); return false; } finally { setBusy(null); }
  };

  return (
    <div className="flex h-full min-h-0 min-w-0 flex-col gap-2 p-2">
      <nav aria-label="OmniConnect settings" className="flex shrink-0 gap-2 border-b pb-2"><Button size="sm" variant={view === "accounts" ? "default" : "ghost"} onClick={() => setView("accounts")}><KeyRound />Accounts</Button><Button size="sm" variant={view === "notifications" ? "default" : "ghost"} onClick={() => setView("notifications")}><Activity />Notifications</Button></nav>
      {view === "notifications" ? <OmniNotifications /> : <div className="connect-accounts flex min-h-0 flex-1 flex-col gap-2">
      <section className="holo hud-corners min-h-0 flex-1 overflow-y-auto p-4">
        <div className="mb-3 flex items-center justify-between"><span className="hud-label text-primary">Connector matrix</span><span className="hud-chip">{conns.length}/{CONNECTORS.length} linked</span></div>
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {CONNECTORS.map((c) => {
            const Icon = ICONS[c.id] ?? KeyRound; const live = byId[c.id];
            return (
              <button key={c.id} onClick={() => { setOpen(c.id); setForm({}); setErr(null); }} className={`glow-frame holo flex flex-col gap-3 p-4 text-left ${live ? "glow-active" : ""}`}>
                <div className="flex items-center gap-3">
                  <span className="recessed grid size-11 place-items-center text-primary"><Icon className="size-5" /></span>
                  <div className="min-w-0 flex-1"><p className="font-semibold">{c.name}</p><p className="truncate text-xs text-muted-foreground">{live ? live.account_label : c.desc}</p></div>
                  <span className={`size-2 rounded-full ${live ? "bg-success animate-pulse" : "bg-muted"}`} />
                </div>
                {live && <div className="grid grid-cols-3 gap-1.5">{live.metrics.slice(0, 3).map((m) => <div key={m.label} className="recessed px-2 py-1.5"><p className="truncate font-mono text-sm text-primary">{m.value}</p><p className="hud-label truncate">{m.label}</p></div>)}</div>}
              </button>
            );
          })}
        </div>
      </section>

      <aside className="holo hud-corners flex min-h-0 w-full shrink-0 flex-col p-4 md:w-80">
        <span className="hud-label mb-3 flex items-center gap-2 text-primary"><Activity className="size-3" /> Live telemetry</span>
        <div className="min-h-0 flex-1 space-y-2 overflow-y-auto">
          {conns.length === 0 && <p className="text-sm text-muted-foreground">No accounts linked yet. Pick a connector and paste its key — it's checked against the real service before saving.</p>}
          {conns.map((c) => (
            <div key={c.provider} className="recessed p-3">
              <div className="flex items-center justify-between"><p className="text-sm font-semibold">{CONNECTORS.find((d) => d.id === c.provider)?.name}</p>
                <button aria-label="Refresh" onClick={() => act(c.provider, () => refresh({ data: { provider: c.provider } }))} className="text-muted-foreground hover:text-primary">{busy === c.provider ? <Loader2 className="size-3.5 animate-spin" /> : <RefreshCw className="size-3.5" />}</button></div>
              <p className="font-mono text-[10px] text-muted-foreground">synced {new Date(c.last_checked).toLocaleTimeString()}</p>
              {c.metrics.map((m) => <div key={m.label} className="flex justify-between text-xs"><span className="text-muted-foreground">{m.label}</span><span className="font-mono text-primary">{m.value}</span></div>)}
            </div>
          ))}
        </div>
        {err && !def && <p className="mt-2 text-xs text-destructive">{err}</p>}
      </aside>
      </div>}

      {def && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-background/80 p-4 backdrop-blur" onClick={() => setOpen(null)}>
          <div onClick={(e) => e.stopPropagation()} className="holo hud-corners w-full max-w-md p-6">
            <div className="mb-4 flex items-center justify-between"><h3 className="flex items-center gap-2 font-display text-lg font-bold"><KeyRound className="size-5 text-primary" /> {byId[def.id] ? "Update" : "Connect"} {def.name}</h3><button aria-label="Close" onClick={() => setOpen(null)}><X className="size-5 text-muted-foreground" /></button></div>
            <p className="mb-4 text-xs text-muted-foreground">Where to find it: {def.help}. Keys are stored privately on your account and never shown again.</p>
            <div className="space-y-3">
              {def.fields.map((f) => (
                <label key={f.key} className="block text-xs text-muted-foreground">{f.label}
                  <input type={f.secret ? "password" : "text"} placeholder={f.placeholder} value={form[f.key] ?? ""} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} className="recessed mt-1 w-full p-2 font-mono text-sm text-foreground outline-none focus:ring-1 focus:ring-ring" />
                </label>
              ))}
              {err && <p className="text-xs text-destructive">{err}</p>}
              <Button className="w-full" disabled={busy === def.id || def.fields.some((f) => !form[f.key])} onClick={async () => { if (await act(def.id, () => save({ data: { provider: def.id, credentials: form } }))) setOpen(null); }}>
                {busy === def.id ? <><Loader2 className="size-4 animate-spin" /> Verifying with {def.name}…</> : "Verify & connect"}
              </Button>
              {byId[def.id] && <Button variant="outline" className="w-full" onClick={async () => { if (await act(def.id, async () => { const { error } = await supabase.from("user_connections").delete().eq("provider", def.id).eq("user_id", user.id); if (error) throw error; })) setOpen(null); }}><Trash2 className="size-4" /> Disconnect</Button>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
