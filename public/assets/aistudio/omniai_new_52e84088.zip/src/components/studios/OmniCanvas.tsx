import { useEffect, useRef, useState } from "react";
import { useParams, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, Eraser, Expand, ImagePlus, Loader2, Maximize2, Palette, Send, Sparkles, Trash2, Type, Wand2 } from "lucide-react";
import { toast } from "sonner";
import { generate } from "@/lib/ai.functions";
import { listProjects } from "@/lib/private.functions";
import { useAccount } from "@/components/AccountProvider";
import { useWorkspaceState } from "@/components/WorkspaceStateProvider";
import { Button } from "@/components/ui/button";
import { EnhanceButton } from "@/components/MediaComposer";
import { useCreditApproval } from "@/components/CreditApprovalProvider";
import { useStudioActions } from "@/lib/studio-actions";

type Mode = "generate" | "edit" | "expand" | "upscale" | "remove-bg";
type Layer = { id: number; text: string; x: number; y: number; size: number; color: string; weight: number };

const MODES: { id: Mode; label: string; icon: typeof Wand2; needsImage: boolean; hint: string }[] = [
  { id: "generate", label: "Generate", icon: Sparkles, needsImage: false, hint: "Create a new image from words" },
  { id: "edit", label: "Generative fill", icon: Wand2, needsImage: true, hint: "Change the selected image" },
  { id: "expand", label: "Expand", icon: Expand, needsImage: true, hint: "Extend the scene outward" },
  { id: "upscale", label: "Upscale", icon: Maximize2, needsImage: true, hint: "Sharper, more detail" },
  { id: "remove-bg", label: "Remove BG", icon: Eraser, needsImage: true, hint: "Isolate the subject" },
];
const STYLES = ["None", "Cinematic", "Photoreal", "Anime", "3D render", "Neon noir", "Watercolor", "Minimal flat"];
const FORMATS = [
  { id: "square", label: "Square 1:1", ratio: "1 / 1", hint: "square 1:1 composition" },
  { id: "post", label: "Instagram 4:5", ratio: "4 / 5", hint: "4:5 portrait social post" },
  { id: "story", label: "Story 9:16", ratio: "9 / 16", hint: "tall 9:16 story layout" },
  { id: "wide", label: "Slide 16:9", ratio: "16 / 9", hint: "wide 16:9 presentation slide" },
  { id: "poster", label: "Poster 2:3", ratio: "2 / 3", hint: "2:3 poster" },
];
const PALETTE = ["#ffffff", "#00f2fe", "#7f00ff", "#0575e6", "#000000"];

async function toDataUrl(url: string) {
  const blob = await (await fetch(url)).blob();
  return new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.onerror = rej; r.readAsDataURL(blob); });
}

export function OmniCanvas() {
  const { id: studio = "image" } = useParams({ strict: false }) as { id?: string };
  const design = studio === "design";
  const { user } = useAccount(); const qc = useQueryClient(); const { setPhase } = useWorkspaceState();
  const authorizeCredits = useCreditApproval();
  const gen = useServerFn(generate); const load = useServerFn(listProjects);
  const [mode, setMode] = useState<Mode>("generate");
  const [style, setStyle] = useState("None");
  const [format, setFormat] = useState(FORMATS[design ? 1 : 0]!);
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [uploads, setUploads] = useState<{ name: string; url: string }[]>([]);
  const [layers, setLayers] = useState<Layer[]>([]);
  const [active, setActive] = useState<number | null>(null);
  const stage = useRef<HTMLDivElement>(null);
  const drag = useRef<{ id: number; dx: number; dy: number } | null>(null);

  const saved = useQuery({ queryKey: ["projects", studio, user?.id], enabled: !!user, queryFn: () => load({ data: { studio } }) });
  const images = (saved.data ?? []).filter((p) => p.kind === "image" && p.url);
  const current = selected ? (uploads.find((u) => u.url === selected)?.url ?? images.find((p) => p.id === selected)?.url ?? null) : null;
  useEffect(() => { if (!selected && images[0]) setSelected(images[0].id); }, [images, selected]);

  const modeInfo = MODES.find((m) => m.id === mode)!;

  async function run(text = prompt, m: Mode = mode) {
    const info = MODES.find((x) => x.id === m)!;
    if (busy || !user) return;
    if (info.needsImage && !current) { toast.error("Pick or upload an image first."); return; }
    if (m === "generate" && !text.trim()) return;
    const base = { edit: text, expand: `Outpaint and extend this image outward naturally. ${text}`, upscale: `Upscale this image: sharper detail, clean edges, same composition. ${text}`, "remove-bg": "Remove the background completely, keep only the main subject on a pure white background.", generate: text }[m];
    const full = [base, style !== "None" ? `Style: ${style}.` : "", `Format: ${format.hint}.`].filter(Boolean).join(" ").slice(0, 4000);
    setBusy(true); setPhase("classified");
    try {
      const refs = info.needsImage && current ? [{ url: await toDataUrl(current), mediaType: "image/png", filename: "source.png" }] : [];
      const approvalId = await authorizeCredits({ operation: "image", target: studio, prompt: full, refUrls: refs.map((r) => r.url) });
      setPhase("routed");
      await gen({ data: { studio, prompt: full, refs, approvalId } });
      setPhase("streaming");
      setSelected(null); setPrompt("");
      await qc.invalidateQueries({ queryKey: ["projects", studio] });
      setPhase("succeeded"); toast.success("Saved to your account");
    } catch (e) { setPhase("failed"); toast.error(e instanceof Error ? e.message : "Generation failed"); }
    finally { setBusy(false); }
  }

  function addLayer(text = "Your headline") {
    const l: Layer = { id: Date.now(), text, x: 50, y: 20 + layers.length * 12, size: 8, color: "#ffffff", weight: 800 };
    setLayers((all) => [...all, l]); setActive(l.id);
  }
  const patch = (id: number, u: Partial<Layer>) => setLayers((all) => all.map((l) => (l.id === id ? { ...l, ...u } : l)));
  const activeLayer = layers.find((l) => l.id === active);

  async function exportPng() {
    if (!current) return;
    const img = new Image(); img.src = await toDataUrl(current); await img.decode();
    const c = document.createElement("canvas"); c.width = img.naturalWidth; c.height = img.naturalHeight;
    const ctx = c.getContext("2d")!; ctx.drawImage(img, 0, 0);
    for (const l of layers) {
      ctx.font = `${l.weight} ${(l.size / 100) * c.width}px "Space Grotesk", sans-serif`; ctx.fillStyle = l.color; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.shadowColor = "rgba(0,0,0,.6)"; ctx.shadowBlur = c.width / 80; ctx.fillText(l.text, (l.x / 100) * c.width, (l.y / 100) * c.height);
    }
    const a = document.createElement("a"); a.href = c.toDataURL("image/png"); a.download = `omni-${studio}.png`; a.click();
  }

  useStudioActions([
    { name: "canvas_describe", description: `Read the ${design ? "design canvas" : "image studio"} state: mode, style, format, whether an image is selected, text layers and saved image titles.`, run: () => JSON.stringify({ mode, style, format: format.id, hasImage: !!current, layers: layers.map((l) => l.text), saved: images.map((p) => p.title).slice(0, 20) }) },
    { name: "canvas_generate", description: "Run a tool now (real output, saved). mode: generate|edit|expand|upscale|remove-bg. Non-generate modes work on the selected image.", args: `{ "mode": string, "prompt"?: string }`, run: async (a) => { const m = (MODES.find((x) => x.id === a.mode)?.id ?? "generate") as Mode; setMode(m); await run(String(a.prompt ?? ""), m); return "Done — new image saved and shown."; } },
    { name: "canvas_settings", description: `Set style (${STYLES.join(", ")}) and/or format (${FORMATS.map((f) => f.id).join(", ")}).`, args: `{ "style"?: string, "format"?: string }`, run: (a) => { if (STYLES.includes(a.style)) setStyle(a.style); const f = FORMATS.find((x) => x.id === a.format); if (f) setFormat(f); return "Settings updated."; } },
    { name: "canvas_select", description: "Select a saved image by title.", args: `{ "title": string }`, run: (a) => { const p = images.find((x) => x.title.toLowerCase().includes(String(a.title).toLowerCase())); if (!p) throw new Error("Not found."); setSelected(p.id); return `Selected ${p.title}.`; } },
    { name: "canvas_add_text", description: "Add a text layer on top of the image (design overlay).", args: `{ "text": string }`, run: (a) => { addLayer(String(a.text ?? "Headline")); return "Text layer added."; } },
    { name: "canvas_export", description: "Download the selected image with text layers as PNG.", run: async () => { await exportPng(); return "Exported."; } },
  ]);

  if (!user) return <div className="grid h-full place-items-center"><Button asChild><Link to="/auth">Sign in to create and save images</Link></Button></div>;

  const panelTitle = (t: string) => <span className="hud-label text-primary">{t}</span>;
  return <div className="canvas-layout grid h-full min-w-0 max-w-full grid-cols-1 gap-2 overflow-hidden p-2">
    {/* Tools */}
    <aside className="canvas-tools holo hud-corners hidden min-h-0 min-w-0 flex-col gap-3 overflow-y-auto p-3">
      {panelTitle(design ? "Design tools" : "Image tools")}
      <div className="grid gap-1.5">{MODES.map((m) => <button key={m.id} onClick={() => setMode(m.id)} className={`flex items-center gap-2 rounded-md border px-3 py-2 text-left text-sm transition ${mode === m.id ? "border-primary/50 bg-primary/10 glow-active" : "border-border/50 bg-background/40 text-muted-foreground hover:text-foreground"}`}><m.icon className="size-4 text-primary" /><span className="min-w-0"><span className="block">{m.label}</span><span className="block truncate text-[10px] text-muted-foreground">{m.hint}</span></span></button>)}</div>
      {panelTitle("Format")}
      <div className="grid grid-cols-2 gap-1.5">{FORMATS.map((f) => <button key={f.id} onClick={() => setFormat(f)} className={`rounded-md border px-2 py-1.5 text-[11px] ${format.id === f.id ? "border-primary/50 bg-primary/10 text-foreground" : "border-border/50 text-muted-foreground"}`}>{f.label}</button>)}</div>
      {panelTitle("Style")}
      <div className="flex flex-wrap gap-1.5">{STYLES.map((s) => <button key={s} onClick={() => setStyle(s)} className={`hud-chip ${style === s ? "border-primary/60 text-primary" : ""}`}>{s}</button>)}</div>
      {panelTitle("Text layers")}
      <Button size="sm" variant="outline" onClick={() => addLayer()} disabled={!current}><Type />Add text</Button>
      {activeLayer && <div className="recessed space-y-2 p-2 text-xs">
        <input aria-label="Layer text" value={activeLayer.text} onChange={(e) => patch(activeLayer.id, { text: e.target.value })} className="w-full rounded border bg-background/60 px-2 py-1 outline-none" />
        <label className="flex items-center gap-2">Size<input type="range" min={3} max={20} value={activeLayer.size} onChange={(e) => patch(activeLayer.id, { size: +e.target.value })} className="flex-1" /></label>
        <div className="flex items-center gap-1.5">{PALETTE.map((c) => <button key={c} aria-label={`Color ${c}`} onClick={() => patch(activeLayer.id, { color: c })} className={`size-5 rounded-full border ${activeLayer.color === c ? "ring-2 ring-primary" : ""}`} style={{ background: c }} />)}
          <Button size="icon-xs" variant="ghost" className="ml-auto" aria-label="Delete layer" onClick={() => { setLayers((all) => all.filter((l) => l.id !== activeLayer.id)); setActive(null); }}><Trash2 /></Button></div>
      </div>}
    </aside>

    {/* Canvas */}
    <section className="flex min-h-0 min-w-0 flex-col gap-2">
      <div className={`holo hud-corners relative flex min-h-0 flex-1 items-center justify-center overflow-hidden p-4 ${busy ? "hud-trace" : ""}`}>
        <div className="absolute left-3 top-3 flex gap-1.5"><span className="hud-chip">{modeInfo.label}</span><span className="hud-chip">{format.label}</span></div>
        <div className="absolute right-3 top-3 flex gap-1"><Button size="icon-sm" variant="outline" aria-label="Export PNG" disabled={!current} onClick={() => void exportPng()}><Download /></Button></div>
        <div ref={stage} className="recessed scanline relative max-h-full max-w-full overflow-hidden" style={{ aspectRatio: format.ratio, height: "100%", containerType: "inline-size" }}
          onPointerMove={(e) => { const d = drag.current; const r = stage.current?.getBoundingClientRect(); if (!d || !r) return; patch(d.id, { x: Math.min(98, Math.max(2, ((e.clientX - r.left) / r.width) * 100)), y: Math.min(98, Math.max(2, ((e.clientY - r.top) / r.height) * 100)) }); }}
          onPointerUp={() => { drag.current = null; }} onPointerLeave={() => { drag.current = null; }}>
          {current ? <img src={current} alt="Selected canvas" className="h-full w-full object-contain" draggable={false} />
            : <div className="grid h-full place-items-center p-6 text-center text-sm text-muted-foreground"><div><Palette className="mx-auto mb-3 size-8 text-primary" />{busy ? "Rendering…" : design ? "Describe a poster, post or slide below." : "Describe an image below, or upload one to edit."}</div></div>}
          {current && layers.map((l) => <span key={l.id} onPointerDown={(e) => { (e.target as HTMLElement).setPointerCapture?.(e.pointerId); setActive(l.id); drag.current = { id: l.id, dx: 0, dy: 0 }; }}
            className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-move select-none whitespace-nowrap font-display drop-shadow-lg ${active === l.id ? "outline outline-1 outline-primary/70" : ""}`}
            style={{ left: `${l.x}%`, top: `${l.y}%`, color: l.color, fontWeight: l.weight, fontSize: `${l.size * 0.9}cqw` }}>{l.text}</span>)}
          {busy && <div className="absolute inset-0 grid place-items-center bg-background/50"><Loader2 className="size-8 animate-spin text-primary" /></div>}
        </div>
      </div>
      <form className="holo shrink-0 space-y-2 p-3" onSubmit={(e) => { e.preventDefault(); void run(); }}>
        <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={2} aria-label="Image prompt" placeholder={mode === "generate" ? (design ? "Instagram post announcing a summer sale, bold neon type" : "Portrait of an astronaut in sunflowers, film photo") : `${modeInfo.label}: describe the change (optional)`}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void run(); } }} className="w-full resize-none rounded-md border bg-background/60 p-2 text-sm outline-none focus:border-primary/60" />
        <div className="flex flex-wrap items-center gap-2">
          <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs text-muted-foreground hover:text-foreground"><ImagePlus className="size-4" />Upload<input type="file" accept="image/*" multiple hidden onChange={(e) => { const fs = Array.from(e.target.files ?? []).filter((f) => f.size <= 10 * 1024 * 1024).slice(0, 8); const next = fs.map((f) => ({ name: f.name, url: URL.createObjectURL(f) })); setUploads((u) => [...next, ...u].slice(0, 8)); if (next[0]) { setSelected(next[0].url); if (mode === "generate") setMode("edit"); } e.target.value = ""; }} /></label>
          <EnhanceButton value={prompt} onChange={setPrompt} studio={studio} disabled={busy} />
          <span className="hidden text-xs text-muted-foreground sm:inline">{style !== "None" ? style : ""}</span>
          <Button className="ml-auto" size="sm" disabled={busy || (mode === "generate" && !prompt.trim())}>{busy ? <Loader2 className="animate-spin" /> : <Send />}{modeInfo.label}</Button>
        </div>
      </form>
    </section>

    {/* Library */}
    <aside className="canvas-library holo hud-corners hidden min-h-0 min-w-0 flex-col gap-2 overflow-hidden p-3">
      <div className="flex items-center justify-between">{panelTitle("Library")}<span className="hud-label">{images.length + uploads.length}</span></div>
      <div className="min-h-0 flex-1 overflow-y-auto pr-1">
        {uploads.length > 0 && <><span className="hud-label">Uploads</span><div className="mb-3 mt-1 grid grid-cols-2 gap-2">{uploads.map((u) => <button key={u.url} onClick={() => setSelected(u.url)} className={`overflow-hidden rounded-md border ${selected === u.url ? "border-primary glow-active" : "border-border/50"}`}><img src={u.url} alt={u.name} className="aspect-square w-full object-cover" /></button>)}</div></>}
        <span className="hud-label">Saved</span>
        {saved.isLoading ? <Loader2 className="mt-3 size-4 animate-spin text-primary" /> : images.length === 0 ? <p className="mt-2 text-xs text-muted-foreground">Nothing yet — your creations save here.</p>
          : <div className="mt-1 grid grid-cols-2 gap-2">{images.map((p) => <button key={p.id} title={p.title} onClick={() => setSelected(p.id)} className={`overflow-hidden rounded-md border ${selected === p.id ? "border-primary glow-active" : "border-border/50"}`}><img src={p.url!} alt={p.title} loading="lazy" className="aspect-square w-full object-cover" /></button>)}</div>}
      </div>
    </aside>
  </div>;
}
