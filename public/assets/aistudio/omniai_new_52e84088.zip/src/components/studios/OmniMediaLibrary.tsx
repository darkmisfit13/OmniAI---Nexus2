import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { LibraryBig, Loader2, Download, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { listAllProjects } from "@/lib/private.functions";
import { useAccount } from "@/components/AccountProvider";
import { studios } from "@/lib/studios";

const KINDS = ["all", "image", "video", "audio", "text"] as const;

export function OmniMediaLibrary() {
  const { user } = useAccount();
  const loadAll = useServerFn(listAllProjects);
  const [kind, setKind] = useState<(typeof KINDS)[number]>("all");
  const [studio, setStudio] = useState("all");
  const vault = useQuery({ queryKey: ["vault", user?.id], queryFn: () => loadAll(), enabled: !!user });

  if (!user) return <div className="grid h-full place-items-center p-6"><Button asChild><Link to="/auth">Sign in to open your vault</Link></Button></div>;

  const items = (vault.data ?? []).filter((p) => (kind === "all" || p.kind === kind) && (studio === "all" || p.studio === studio));
  const studioName = (id: string) => studios.find((s) => s.id === id)?.name ?? id;

  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-hidden p-4">
      <section className="holo hud-corners flex shrink-0 flex-wrap items-center gap-2 p-3">
        <span className="hud-label"><LibraryBig className="mr-1 inline size-3" />Vault filters</span>
        <div className="flex flex-wrap gap-1.5">
          {KINDS.map((k) => <Button key={k} variant={kind === k ? "default" : "outline"} size="sm" className="bevel capitalize" onClick={() => setKind(k)}>{k}</Button>)}
        </div>
        <select value={studio} onChange={(e) => setStudio(e.target.value)} aria-label="Filter by studio" className="ml-auto rounded-md border bg-background/60 p-1.5 text-xs">
          <option value="all">All studios</option>
          {studios.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      </section>
      <div className="grid min-h-0 flex-1 auto-rows-min gap-3 overflow-y-auto sm:grid-cols-2 lg:grid-cols-4">
        {vault.isLoading && <p className="col-span-full flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" /> Opening vault…</p>}
        {!vault.isLoading && items.length === 0 && <p className="col-span-full text-sm text-muted-foreground">Nothing here yet — generate media in any studio and it lands in this vault.</p>}
        {items.map((p) => (
          <div key={p.id} className="holo hud-corners flex flex-col gap-2 p-3">
            <p className="line-clamp-2 text-xs font-semibold">{p.title}</p>
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{studioName(p.studio)} · {p.kind}</p>
            {p.url && p.kind === "image" && <img src={p.url} alt={p.title} className="aspect-square w-full rounded-md object-cover" />}
            {p.url && p.kind === "video" && <video src={p.url} controls className="aspect-video w-full rounded-md object-cover" />}
            {p.url && p.kind === "audio" && <audio src={p.url} controls className="w-full" />}
            {p.content && <p className="flex max-h-24 items-start gap-1 overflow-hidden text-[11px] text-muted-foreground"><FileText className="mt-0.5 size-3 shrink-0" />{p.content.slice(0, 180)}…</p>}
            {p.url && <a href={p.url} download className="mt-auto inline-flex items-center gap-1 text-xs text-primary"><Download className="size-3" />Download</a>}
          </div>
        ))}
      </div>
    </div>
  );
}
