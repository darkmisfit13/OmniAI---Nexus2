import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Check, ShieldCheck, AudioLines, Images, Cpu, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { useAccount } from "@/components/AccountProvider";
import { calculateBudget, type BudgetConfig } from "@/lib/omnibeat-budget";
import { pipelineCredits } from "@/lib/omni-plans";
import { quoteOmniBeat, authorizeOmniBeatBudget } from "@/lib/omnibeat-budget.functions";
export function OmniBeatBudget({ value, onChange, onAuthorized }: { value: BudgetConfig; onChange: (v: BudgetConfig) => void; onAuthorized?: (id: string) => void }) {
  const quoteServer = useServerFn(quoteOmniBeat), authorize = useServerFn(authorizeOmniBeatBudget); const { user } = useAccount();
  const [quote, setQuote] = useState(() => calculateBudget(value)); const [status, setStatus] = useState(""); const [busy, setBusy] = useState(false); const [approved, setApproved] = useState(false);
  useEffect(() => { let current = true; setApproved(false); setStatus(""); const timer = setTimeout(() => { void quoteServer({ data: value }).then((q) => { if (current) setQuote(q); }).catch((e: Error) => { if (current) setStatus(e.message); }); }, 150); return () => { current = false; clearTimeout(timer); }; }, [value, quoteServer]);
  const local = calculateBudget(value); const fresh = quote.totalMicros === local.totalMicros;
  return <section aria-label="OmniBeat compute budget" className="holo hud-corners mx-auto w-full max-w-4xl space-y-5 rounded-md p-6">
    <div className="flex items-center justify-between gap-2"><div><span className="hud-label text-primary">Compute architecture</span><h2 className="mt-1 text-xl">Production budget</h2></div><Cpu className="size-6 text-accent" /></div>
    <div className="grid gap-6 md:grid-cols-2"><div className="space-y-5">
      <Range label="Video length" value={value.seconds} min={15} max={300} unit="s" onChange={(seconds) => onChange({ ...value, seconds })} />
      <Range label="Target image variants" value={value.variants} min={4} max={32} unit=" images" onChange={(variants) => onChange({ ...value, variants })} />
      <label className="flex items-center justify-between gap-3 text-sm">High-detail references <Switch aria-label="High-detail references" checked={value.highDetail} onCheckedChange={(highDetail) => onChange({ ...value, highDetail })} /></label>
      <label className="flex items-center justify-between gap-3 text-sm">Estimate a pipeline stop <Switch aria-label="Estimate a pipeline stop" checked={value.stopped} onCheckedChange={(stopped) => onChange({ ...value, stopped })} /></label>
      <Range label="Pipeline disruption / stop point" value={value.stopPercent} min={0} max={100} unit="%" disabled={!value.stopped} onChange={(stopPercent) => onChange({ ...value, stopPercent })} />
    </div><div className="recessed space-y-4 p-4">
      <span className="hud-label text-primary">Live compute telemetry</span>
      {([["Audio vibe track mapping", 5, AudioLines], ["Reference frame synthesis", value.variants * 3, Images], [value.stopped ? "Processed diffusion nodes" : "Final video diffusion", value.stopped ? value.seconds * 8 * value.stopPercent / 100 : value.seconds * 8, Cpu], ["Stop fee", 0, RotateCcw]] as const).map(([label, amount, Icon]) => <div key={label} className="flex items-center justify-between gap-3 border-b pb-3 text-xs"><span className="flex items-center gap-2 text-muted-foreground"><Icon className="size-4 shrink-0 text-primary" />{label}</span><AnimatedMoney value={amount} /></div>)}
      <div className="flex flex-wrap items-end justify-between gap-3"><span className="hud-label">Estimated total</span><span className="whitespace-nowrap font-display text-3xl text-primary"><AnimatedMoney value={pipelineCredits(value.stopped ? value.seconds * value.stopPercent / 100 : value.seconds, value.variants)} /></span></div>
      <p className="text-xs text-muted-foreground">Starting reservation: 400 CR. Analysis 5 CR · references 3 CR each · animation 8 CR/sec. Unused credits return on completion or stop. Additional compute requires approval.</p>
    </div></div>
    <Button className="h-auto min-h-12 w-full whitespace-normal py-3 shadow-glow" disabled={!user || busy || !fresh || approved} onClick={async () => { setBusy(true); try { const r = await authorize({ data: value }); setApproved(true); setStatus("Production settings saved · authorize the reservation in production"); onAuthorized?.(r.id); } catch (e) { setStatus(e instanceof Error ? e.message : "Approval failed"); } finally { setBusy(false); } }}>{approved ? <Check /> : <ShieldCheck />}{approved ? "Budget authorized" : busy ? "Authorizing…" : `Save production settings · ${pipelineCredits(value.seconds, value.variants)} CR estimate`}</Button>
    {!user && <p className="text-xs text-muted-foreground">Sign in to authorize a budget.</p>}{status && <p role="status" className="text-xs text-primary">{status}</p>}
  </section>;
}
function Range({ label, value, min, max, unit, disabled = false, onChange }: { label: string; value: number; min: number; max: number; unit: string; disabled?: boolean; onChange: (n: number) => void }) { return <div className="space-y-3"><div className="flex justify-between gap-2 text-xs"><span>{label}</span><output className="font-mono text-primary">{value}{unit}</output></div><Slider aria-label={label} min={min} max={max} step={1} value={[value]} disabled={disabled} onValueChange={(v) => { if (v[0] !== undefined) onChange(v[0]); }} /></div>; }
function AnimatedMoney({ value }: { value: number }) { const [display, setDisplay] = useState(value); const current = useRef(value); useEffect(() => { if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { current.current = value; setDisplay(value); return; } const from = current.current, start = performance.now(); let raf = 0; const tick = (now: number) => { const p = Math.min(1, (now - start) / 260); current.current = Math.round(from + (value - from) * (1 - (1 - p) ** 3)); setDisplay(current.current); if (p < 1) raf = requestAnimationFrame(tick); }; raf = requestAnimationFrame(tick); return () => cancelAnimationFrame(raf); }, [value]); return <span className="tabular-nums">{display} CR</span>; }