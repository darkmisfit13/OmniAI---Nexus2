import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { Loader2, Clapperboard, Send } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { generate } from "@/lib/ai.functions";
import { EnhanceButton } from "@/components/MediaComposer";
import { useAccount } from "@/components/AccountProvider";

type Scene = { title: string; body: string };

function parseScenes(markdown: string): Scene[] {
  const parts = markdown.split(/^(?=#{1,3}\s)/m).filter((p) => p.trim());
  const scenes = parts
    .map((p) => {
      const m = p.match(/^#{1,3}\s+(.+)/);
      if (!m) return null;
      return { title: m[1]!.trim(), body: p.slice(m[0].length).trim() };
    })
    .filter((s): s is Scene => !!s && /scene|shot|act|beat/i.test(s.title));
  return scenes;
}

export function OmniStoryboard() {
  const { user } = useAccount();
  const gen = useServerFn(generate);
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);
  const [script, setScript] = useState("");
  const [scenes, setScenes] = useState<Scene[]>([]);

  if (!user) return <div className="grid h-full place-items-center p-6"><Button asChild><Link to="/auth">Sign in to write storyboards</Link></Button></div>;

  const run = async () => {
    if (!prompt.trim() || busy) return;
    setBusy(true); setScript(""); setScenes([]);
    try {
      const brief = `Write a complete production script with a shot-by-shot storyboard for: ${prompt}\n\nFormat: a short logline, then one markdown heading per scene (## Scene 1 — title) with visual description, camera shot, action, dialogue/voiceover and duration under each.`;
      const result = await gen({ data: { studio: "storyboard", prompt: brief.slice(0, 4000), refs: [] } });
      const text = result?.text ?? "";
      setScript(text);
      setScenes(parseScenes(text));
    } catch (e) { toast.error(e instanceof Error ? e.message : "Storyboard failed."); }
    finally { setBusy(false); }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-hidden p-4">
      <section className="holo hud-corners shrink-0 space-y-2 p-4">
        <span className="hud-label">Story brief</span>
        <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={2} aria-label="Story brief"
          placeholder="A 60-second product launch video for a smart water bottle…"
          className="w-full resize-none rounded-md border bg-background/60 p-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
        <div className="flex items-center gap-2">
          <EnhanceButton value={prompt} onChange={setPrompt} studio="storyboard" disabled={busy} />
          <Button className="ml-auto bevel" disabled={busy || !prompt.trim()} onClick={() => void run()}>{busy ? <Loader2 className="animate-spin" /> : <Send />}Write script & scenes</Button>
        </div>
      </section>
      <div className="grid min-h-0 flex-1 gap-3 lg:grid-cols-5">
        <section className="holo hud-corners flex min-h-0 flex-col gap-2 p-4 lg:col-span-2">
          <span className="hud-label">Script</span>
          <div className="min-h-0 flex-1 overflow-y-auto whitespace-pre-wrap text-sm text-muted-foreground">
            {busy ? <span className="flex items-center gap-2"><Loader2 className="size-4 animate-spin" /> Writing…</span> : script || "The full script appears here."}
          </div>
        </section>
        <section className="holo hud-corners flex min-h-0 flex-col gap-2 p-4 lg:col-span-3">
          <span className="hud-label">Scene board</span>
          <div className="grid min-h-0 flex-1 auto-rows-min gap-3 overflow-y-auto sm:grid-cols-2">
            {scenes.length === 0 && !busy && <p className="text-sm text-muted-foreground">Scenes appear as cards once the script is written.</p>}
            {scenes.map((s, i) => (
              <div key={i} className="holo space-y-2 p-3">
                <p className="flex items-center gap-2 text-sm font-semibold"><Clapperboard className="size-4 text-primary" />{s.title}</p>
                <p className="max-h-40 overflow-y-auto whitespace-pre-wrap text-xs text-muted-foreground">{s.body}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
