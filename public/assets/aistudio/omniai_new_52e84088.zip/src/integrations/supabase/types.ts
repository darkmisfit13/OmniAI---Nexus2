export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      ai_memories: {
        Row: {
          content: string
          created_at: string
          id: string
          source_thread_id: string | null
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          source_thread_id?: string | null
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          source_thread_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_memories_source_thread_id_fkey"
            columns: ["source_thread_id"]
            isOneToOne: false
            referencedRelation: "chat_threads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ai_memories_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_processing_blocks: {
        Row: {
          created_at: string
          message: string
          model: string
          status: number
        }
        Insert: {
          created_at?: string
          message: string
          model: string
          status: number
        }
        Update: {
          created_at?: string
          message?: string
          model?: string
          status?: number
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          created_at: string
          id: string
          message: Json
          sdk_id: string
          thread_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: Json
          sdk_id: string
          thread_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: Json
          sdk_id?: string
          thread_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "chat_threads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chat_messages_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_threads: {
        Row: {
          created_at: string
          id: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_threads_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      council_members: {
        Row: {
          created_at: string
          created_by: string
          credential_ciphertext: string
          enabled: boolean
          id: string
          label: string
          last_checked: string | null
          model: string
          provider: string
        }
        Insert: {
          created_at?: string
          created_by: string
          credential_ciphertext: string
          enabled?: boolean
          id?: string
          label: string
          last_checked?: string | null
          model: string
          provider: string
        }
        Update: {
          created_at?: string
          created_by?: string
          credential_ciphertext?: string
          enabled?: boolean
          id?: string
          label?: string
          last_checked?: string | null
          model?: string
          provider?: string
        }
        Relationships: []
      }
      music_generation_jobs: {
        Row: {
          approval_id: string
          completed_count: number
          created_at: string
          error: string | null
          id: string
          status: string
          user_id: string
        }
        Insert: {
          approval_id: string
          completed_count?: number
          created_at?: string
          error?: string | null
          id?: string
          status?: string
          user_id: string
        }
        Update: {
          approval_id?: string
          completed_count?: number
          created_at?: string
          error?: string | null
          id?: string
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "music_generation_jobs_approval_id_fkey"
            columns: ["approval_id"]
            isOneToOne: true
            referencedRelation: "studio_credit_approvals"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_deliveries: {
        Row: {
          created_at: string
          event_key: string
          http_status: number | null
          id: string
          payload: Json
          status: string
          user_id: string
        }
        Insert: {
          created_at?: string
          event_key: string
          http_status?: number | null
          id?: string
          payload: Json
          status?: string
          user_id: string
        }
        Update: {
          created_at?: string
          event_key?: string
          http_status?: number | null
          id?: string
          payload?: Json
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      notification_settings: {
        Row: {
          compilation_enabled: boolean
          generation_enabled: boolean
          security_enabled: boolean
          updated_at: string
          user_id: string
          verified_at: string | null
          webhook_url: string
        }
        Insert: {
          compilation_enabled?: boolean
          generation_enabled?: boolean
          security_enabled?: boolean
          updated_at?: string
          user_id: string
          verified_at?: string | null
          webhook_url?: string
        }
        Update: {
          compilation_enabled?: boolean
          generation_enabled?: boolean
          security_enabled?: boolean
          updated_at?: string
          user_id?: string
          verified_at?: string | null
          webhook_url?: string
        }
        Relationships: []
      }
      omni_credit_grants: {
        Row: {
          amount: number
          created_at: string
          id: string
          reference: string
          source: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          reference: string
          source: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          reference?: string
          source?: string
          user_id?: string
        }
        Relationships: []
      }
      omni_pipeline_ledger: {
        Row: {
          amount: number
          created_at: string
          entry_type: string
          id: string
          reservation_id: string
          step_id: string | null
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          entry_type: string
          id?: string
          reservation_id: string
          step_id?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          entry_type?: string
          id?: string
          reservation_id?: string
          step_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "omni_pipeline_ledger_reservation_id_fkey"
            columns: ["reservation_id"]
            isOneToOne: false
            referencedRelation: "omni_pipeline_reservations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "omni_pipeline_ledger_step_id_fkey"
            columns: ["step_id"]
            isOneToOne: false
            referencedRelation: "omni_pipeline_steps"
            referencedColumns: ["id"]
          },
        ]
      }
      omni_pipeline_reservations: {
        Row: {
          created_at: string
          id: string
          monthly_released: number
          monthly_reserved: number
          next_required: number
          pending: number
          project_id: string
          released: number
          reserved: number
          spent: number
          status: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          monthly_released?: number
          monthly_reserved?: number
          next_required?: number
          pending?: number
          project_id: string
          released?: number
          reserved?: number
          spent?: number
          status?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          monthly_released?: number
          monthly_reserved?: number
          next_required?: number
          pending?: number
          project_id?: string
          released?: number
          reserved?: number
          spent?: number
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "omni_pipeline_reservations_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "studio_projects"
            referencedColumns: ["id"]
          },
        ]
      }
      omni_pipeline_steps: {
        Row: {
          cost: number
          created_at: string
          id: string
          operation: string
          output_project_id: string | null
          request_hash: string
          reservation_id: string
          status: string
          step_key: string
          user_id: string
        }
        Insert: {
          cost: number
          created_at?: string
          id?: string
          operation: string
          output_project_id?: string | null
          request_hash: string
          reservation_id: string
          status?: string
          step_key: string
          user_id: string
        }
        Update: {
          cost?: number
          created_at?: string
          id?: string
          operation?: string
          output_project_id?: string | null
          request_hash?: string
          reservation_id?: string
          status?: string
          step_key?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "omni_pipeline_steps_output_project_id_fkey"
            columns: ["output_project_id"]
            isOneToOne: false
            referencedRelation: "studio_projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "omni_pipeline_steps_reservation_id_fkey"
            columns: ["reservation_id"]
            isOneToOne: false
            referencedRelation: "omni_pipeline_reservations"
            referencedColumns: ["id"]
          },
        ]
      }
      omni_subscriptions: {
        Row: {
          payment_reference: string | null
          period_end: string
          period_start: string
          plan: string
          status: string
          user_id: string
        }
        Insert: {
          payment_reference?: string | null
          period_end: string
          period_start: string
          plan?: string
          status?: string
          user_id: string
        }
        Update: {
          payment_reference?: string | null
          period_end?: string
          period_start?: string
          plan?: string
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      omniwave_credit_wallets: {
        Row: {
          balance: number
          user_id: string
        }
        Insert: {
          balance?: number
          user_id: string
        }
        Update: {
          balance?: number
          user_id?: string
        }
        Relationships: []
      }
      omniwave_subscriptions: {
        Row: {
          payment_reference: string | null
          period_end: string
          period_start: string
          plan: string
          status: string
          user_id: string
        }
        Insert: {
          payment_reference?: string | null
          period_end: string
          period_start: string
          plan: string
          status?: string
          user_id: string
        }
        Update: {
          payment_reference?: string | null
          period_end?: string
          period_start?: string
          plan?: string
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          display_name: string
          id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string
          id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string
          id?: string
        }
        Relationships: []
      }
      studio_credit_approvals: {
        Row: {
          amount: number
          confirmed_at: string | null
          created_at: string
          expires_at: string
          id: string
          monthly_used: number
          music_preview: boolean
          operation: string
          request_hash: string
          status: string
          units: number
          user_id: string
          wallet_scope: string
        }
        Insert: {
          amount: number
          confirmed_at?: string | null
          created_at?: string
          expires_at?: string
          id?: string
          monthly_used?: number
          music_preview?: boolean
          operation: string
          request_hash: string
          status?: string
          units: number
          user_id: string
          wallet_scope?: string
        }
        Update: {
          amount?: number
          confirmed_at?: string | null
          created_at?: string
          expires_at?: string
          id?: string
          monthly_used?: number
          music_preview?: boolean
          operation?: string
          request_hash?: string
          status?: string
          units?: number
          user_id?: string
          wallet_scope?: string
        }
        Relationships: []
      }
      studio_credit_ledger: {
        Row: {
          amount: number
          approval_id: string
          created_at: string
          entry_type: string
          id: string
          user_id: string
        }
        Insert: {
          amount: number
          approval_id: string
          created_at?: string
          entry_type: string
          id?: string
          user_id: string
        }
        Update: {
          amount?: number
          approval_id?: string
          created_at?: string
          entry_type?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "studio_credit_ledger_approval_id_fkey"
            columns: ["approval_id"]
            isOneToOne: false
            referencedRelation: "studio_credit_approvals"
            referencedColumns: ["id"]
          },
        ]
      }
      studio_credit_wallets: {
        Row: {
          balance: number
          booster_balance: number
          monthly_balance: number
          user_id: string
        }
        Insert: {
          balance?: number
          booster_balance?: number
          monthly_balance?: number
          user_id: string
        }
        Update: {
          balance?: number
          booster_balance?: number
          monthly_balance?: number
          user_id?: string
        }
        Relationships: []
      }
      studio_projects: {
        Row: {
          asset_path: string | null
          content: string | null
          created_at: string
          id: string
          job_id: string | null
          kind: string
          state: Json
          studio: string
          title: string
          user_id: string
        }
        Insert: {
          asset_path?: string | null
          content?: string | null
          created_at?: string
          id?: string
          job_id?: string | null
          kind: string
          state?: Json
          studio: string
          title: string
          user_id: string
        }
        Update: {
          asset_path?: string | null
          content?: string | null
          created_at?: string
          id?: string
          job_id?: string | null
          kind?: string
          state?: Json
          studio?: string
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "studio_projects_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_connections: {
        Row: {
          account_label: string | null
          created_at: string
          credentials: Json
          id: string
          last_checked: string
          metrics: Json
          provider: string
          user_id: string
        }
        Insert: {
          account_label?: string | null
          created_at?: string
          credentials?: Json
          id?: string
          last_checked?: string
          metrics?: Json
          provider: string
          user_id: string
        }
        Update: {
          account_label?: string | null
          created_at?: string
          credentials?: Json
          id?: string
          last_checked?: string
          metrics?: Json
          provider?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      workspace_settings: {
        Row: {
          id: string
          orb_enabled: boolean
        }
        Insert: {
          id?: string
          orb_enabled?: boolean
        }
        Update: {
          id?: string
          orb_enabled?: boolean
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      claim_omni_pipeline_step: {
        Args: {
          p_hash: string
          p_id: string
          p_key: string
          p_operation: string
          p_units: number
          p_user: string
        }
        Returns: Json
      }
      confirm_studio_credit_charge: { Args: { p_id: string }; Returns: number }
      consume_studio_credit_charge: {
        Args: {
          p_hash: string
          p_id: string
          p_operation: string
          p_user: string
        }
        Returns: undefined
      }
      extend_omni_pipeline: { Args: { p_id: string }; Returns: number }
      finish_omni_pipeline_step: {
        Args: {
          p_output?: string
          p_step: string
          p_success: boolean
          p_user: string
        }
        Returns: undefined
      }
      has_omniwave_pro: { Args: { p_user: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      omni_wallet_take: {
        Args: { p_amount: number; p_user: string }
        Returns: number
      }
      provision_omni_monthly: {
        Args: { p_source: string; p_user: string }
        Returns: number
      }
      refund_studio_credit_charge: {
        Args: { p_id: string; p_user: string }
        Returns: undefined
      }
      refund_unfinished_music: {
        Args: { p_completed: number; p_id: string; p_user: string }
        Returns: undefined
      }
      release_omni_pipeline: {
        Args: { p_id: string; p_user: string }
        Returns: number
      }
      reserve_omni_pipeline: { Args: { p_project: string }; Returns: string }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
    },
  },
} as const
