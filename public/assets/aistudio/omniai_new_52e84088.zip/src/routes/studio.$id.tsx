import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { listProjects } from "@/lib/private.functions";
import { useAccount } from "@/components/AccountProvider";
import { Button } from "@/components/ui/button";
import { Sparkles, Loader2 } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { studios } from "@/lib/studios";
import { generate, startVideoJob, checkVideoJob } from "@/lib/ai.functions";
import { OmniMotion } from "@/components/studios/OmniMotion";
import { OmniForge } from "@/components/studios/OmniForge";
import { OmniSite } from "@/components/studios/OmniSite";
import { OmniConnect } from "@/components/studios/OmniConnect";
import { OmniCanvas } from "@/components/studios/OmniCanvas";
import { ChatEntry } from "@/components/ChatEntry";
import { MediaComposer, type MediaRef } from "@/components/MediaComposer";
import { HoloOrb } from "@/components/HoloOrb";
import { useStudioActions } from "@/lib/studio-actions";
import { useCreditApproval } from "@/components/CreditApprovalProvider";
import { OmniBeatSetup } from "@/components/studios/OmniBeatSetup";
import { OmniWave } from "@/components/studios/OmniWave";
import { OmniVoice } from "@/components/studios/OmniVoice";
import { OmniStoryboard } from "@/components/studios/OmniStoryboard";
import { OmniStyle } from "@/components/studios/OmniStyle";
import { OmniSpatial } from "@/components/studios/OmniSpatial";
import { OmniVector } from "@/components/studios/OmniVector";
import { OmniMockup } from "@/components/studios/OmniMockup";
import { OmniBackend } from "@/components/studios/OmniBackend";
import { OmniCosmicUI } from "@/components/studios/OmniCosmicUI";
import { OmniApiLab } from "@/components/studios/OmniApiLab";
import { OmniPrompt } from "@/components/studios/OmniPrompt";
import { OmniMediaLibrary } from "@/components/studios/OmniMediaLibrary";
import { OmniWebsiteAnalyzer } from "@/components/studios/OmniWebsiteAnalyzer";
import { OmniInbox } from "@/components/studios/OmniInbox";

const special: Record<string, () => React.ReactElement> = {
  music: OmniWave,
  "music-video": OmniBeatSetup,
  video: OmniMotion,
  "app-builder": OmniForge, website: OmniSite, code: OmniForge,
  image: OmniCanvas, design: OmniCanvas,
  connectors: OmniConnect, chat: ChatEntry,
  voice: OmniVoice, storyboard: OmniStoryboard, style: OmniStyle,
  "3d": OmniSpatial, vector: OmniVector, mockup: OmniMockup,
  backend: OmniBackend, "cosmic-ui": OmniCosmicUI, "api-lab": OmniApiLab,
  prompt: OmniPrompt, "media-library": OmniMediaLibrary,
  "website-analyzer": OmniWebsiteAnalyzer, inbox: OmniInbox,
};

export const Route = createFileRoute("/studio/$id")({
  validateSearch: (search: Record<string, unknown>): { source?: string | undefined; production?: string | undefined } => ({ source: typeof search["source"] === "string" ? search["source"] : undefined, production: typeof search["production"] === "string" ? search["production"] : undefined }),
  loader: ({ params }) => {
    const studio = studios.find((s) => s.id === params.id);
    if (!studio) throw notFound();
    return { id: studio.id };
  },
  head: ({ loaderData }) => {
    const s = studios.find((x) => x.id === loaderData?.id);
    const title = s ? `${s.name} — Omni AI Hub` : "Studio — Omni";
    const desc = s ? `${s.tagline}. Like ${s.like}, inside Omni.` : "An Omni AI studio.";
    return {
      meta: [
        { title }, { name: "description", content: desc },
        { property: "og:title", content: title }, { property: "og:description", content: desc },
        { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
      ],
    };
  },
  component: StudioPage,
});

type Item = { prompt: string; status: "loading" | "done" | "error"; kind?: "image" | "audio" | "video" | "text"; url?: string; text?: string; error?: string; progress?: string };
const VIDEO = ["video-gen", "music-video"];

function StudioPage() {
  const { id } = Route.useLoaderData();
  const { source, production } = Route.useSearch();
  const s = studios.find((x) => x.id === id);
  const Special = special[id];
  const [items, setItems] = useState<Item[]>([]);
  const authorizeCredits = useCreditApproval();
  const gen = useServerFn(generate);
  const startV = useServerFn(startVideoJob);
  const checkV = useServerFn(checkVideoJob);
  const { user } = useAccount();
  const loadProjects = useServerFn(listProjects);
  const qc = useQueryClient();
  const saved = useQuery({ queryKey: ["projects", id, user?.id], queryFn: () => loadProjects({ data: { studio: id } }), enabled: !!user });
  useStudioActions(Special || !s ? [] : [
    { name: "studio_generate", description: `Generate in this ${s.name} studio right now (real output, saved to the user's account). Write a detailed creative prompt.`, args: `{ "prompt": string }`, run: async (a) => { const p = String(a.prompt ?? "").trim(); if (!p) throw new Error("Missing prompt."); if (!user) throw new Error("Sign in first."); await run(p); return "Studio request completed or declined; check its result."; } },
    { name: "studio_list_saved", description: "List what the user has already made in this studio.", run: () => JSON.stringify(saved.data?.map((p) => ({ title: p.title, kind: p.kind })) ?? []) },
  ]);
  if (!s) return null;

  const run = async (p: string, refs: MediaRef[] = []) => {
    setItems((all) => [{ prompt: p, status: "loading" }, ...all]);
    const set = (u: Partial<Item>) => setItems((all) => all.map((x) => (x.prompt === p && x.status === "loading" ? { ...x, ...u } : x)));
    try {
      if (VIDEO.includes(id)) {
        const prompt = (id === "music-video" ? `Music video: ${p}. Synced to an energetic beat.` : p).slice(0, 3000);
        const approvalId = await authorizeCredits({ operation: "video", target: id, prompt, seconds: 8 });
        const { id: job } = await startV({ data: { studio: id, prompt, approvalId } });
        for (;;) {
          await new Promise((r) => setTimeout(r, 8000));
          const st = await checkV({ data: { id: job } });
          if (st.status === "failed") throw new Error(st.error ?? "Video failed");
          if (st.url) { setItems((all) => all.filter((x) => x.prompt !== p)); await qc.invalidateQueries({ queryKey: ["projects", id] }); return; }
          set({ progress: `${Math.round(st.progress)}%` });
        }
      }
      const prompt = p.slice(0, 4000);
      const approvalId = ["image", "design", "3d"].includes(id) ? await authorizeCredits({ operation: "image", target: id, prompt, refUrls: refs.slice(0, 8).map((r) => r.url) }) : undefined;
      await gen({ data: { studio: id, prompt, refs, ...(approvalId ? { approvalId } : {}) } });
      setItems((all) => all.filter((x) => x.prompt !== p));
      await qc.invalidateQueries({ queryKey: ["projects", id] });
    } catch (e) {
      set({ status: "error", error: (e as Error).message });
    }
  };

  const loading = items.some((i) => i.status === "loading");
  return (
    <div className="studio-page flex h-full w-full max-w-full flex-col gap-2 overflow-hidden p-2">
      <div className="flex min-h-0 flex-1 gap-2">
      <main className="flex min-w-0 flex-1 flex-col gap-2 overflow-hidden">
        <div className={`holo hud-corners flex min-h-0 flex-1 flex-col overflow-hidden ${loading ? "hud-trace" : ""}`}>
        <div className="flex shrink-0 flex-wrap items-center gap-3 border-b px-4 py-2">
          <div className="recessed size-10 shrink-0 p-0.5 md:hidden"><HoloOrb /></div>
          <div className="min-w-0"><h1 className="truncate font-display text-xl font-bold">{s.name}</h1><p className="truncate text-xs text-muted-foreground">{s.tagline}</p></div>
          {!Special && <div className="ml-auto hidden flex-wrap gap-1.5 lg:flex">{s.tools.slice(0, 5).map((t) => <span key={t} className="hud-chip">{t}</span>)}</div>}
        </div>
        {Special ? <div className="min-h-0 flex-1">{id === "video" ? <OmniMotion sourceProjectId={source} sourceProductionId={production} /> : <Special />}</div> : <>
        <div className="flex-1 overflow-auto p-6">
          {items.length === 0 && !saved.data?.length ? (
            <div className="grid h-full place-items-center text-center">
              <div>
                <div className="recessed mx-auto mb-5 grid size-16 place-items-center"><Sparkles className="size-7 text-primary" /></div>
                <p className="font-display text-3xl">What do you want to make?</p>
                <p className="mt-1 text-sm text-muted-foreground">Try: “{s.placeholder}”</p>
              </div>
            </div>
          ) : (
            <div className="grid gap-4 lg:grid-cols-2">
              {saved.data?.map((project) => <div key={project.id} className="holo hud-corners p-4"><p className="mb-3 text-sm font-semibold">{project.title}</p><span className="text-xs text-success">Saved</span>{project.url && project.kind === "image" && <img src={project.url} alt={project.title} className="mt-2 w-full rounded-md" />}{project.url && project.kind === "audio" && <audio src={project.url} controls className="mt-2 w-full" />}{project.url && project.kind === "video" && <video src={project.url} controls className="mt-2 w-full rounded-md" />}{project.content && <div className="max-h-96 overflow-y-auto whitespace-pre-wrap text-sm">{project.content}</div>}{project.kind === "pending-video" && project.job_id && <Button variant="outline" size="sm" onClick={async () => { try { const result = await checkV({ data: { id: project.job_id ?? "" } }); if (result.error) throw new Error(result.error); await qc.invalidateQueries({ queryKey: ["projects", id] }); } catch (e) { setItems((all) => [{ prompt: project.title, status: "error", error: String(e) }, ...all]); } }}>Check video progress</Button>}{project.url && <a className="mt-3 block text-xs text-primary" href={project.url} download>Download</a>}</div>)}
              {items.map((it, i) => (
                <div key={i} className={`holo p-4 ${it.status === "loading" ? "glow-active" : ""}`}>
                  <p className="mb-3 text-sm font-semibold">{it.prompt}</p>
                  {it.status === "loading" && <div className="flex aspect-video items-center justify-center gap-2 recessed scanline hud-sweep text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" /> Generating… {it.progress ?? (VIDEO.includes(id) ? "(videos take 1–3 min)" : "")}</div>}
                  {it.url && it.kind === "image" && <a href={it.url} download="omniai.png"><img src={it.url} alt={it.prompt} className="w-full rounded-xl" /></a>}
                  {it.url && it.kind === "video" && <video src={it.url} controls autoPlay loop className="w-full rounded-xl" />}
                  {it.url && it.kind === "audio" && <audio src={it.url} controls className="w-full" />}
                  {it.url && it.kind !== "image" && <a href={it.url} download={`omniai.${it.kind === "video" ? "mp4" : "mp3"}`} className="mt-2 inline-block text-xs text-primary">Download</a>}
                  {it.text && <div className="max-h-96 overflow-y-auto whitespace-pre-wrap text-sm text-muted-foreground">{it.text}</div>}
                  {it.error && <p className="text-sm text-destructive">{it.error}</p>}
                </div>
              ))}
            </div>
          )}
        </div>

        {saved.error && <p role="alert" className="px-4 text-sm text-destructive">{saved.error.message}</p>}
        </>}
        </div>
        {!Special && <section className="holo shrink-0"><div className="px-4 pt-3"><span className="hud-label">Creation console</span></div>{!user ? <div className="p-4"><Button asChild><Link to="/auth">Sign in to create and save</Link></Button></div> : <MediaComposer placeholder={s.placeholder} studio={id} disabled={loading} onSubmit={(p, refs) => run(p, refs)} />}</section>}
      </main>
      </div>
    </div>
  );
}
