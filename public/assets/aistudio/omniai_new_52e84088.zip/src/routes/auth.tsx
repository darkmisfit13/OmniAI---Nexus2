import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import "@lovable.dev/cloud-auth-js/styles.css";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAccount } from "@/components/AccountProvider";

export const Route = createFileRoute("/auth")({ head: () => ({ meta: [{ title: "Sign in — OmniAI" }, { name: "description", content: "Access your private OmniAI projects and conversations." }, { property: "og:title", content: "Sign in — OmniAI" }, { property: "og:description", content: "Your private creative AI workspace." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }), component: AuthPage });
function AuthPage() {
  const [mode, setMode] = useState<"signin" | "signup" | "forgot" | "confirm">("signin");
  const [email, setEmail] = useState(""); const [password, setPassword] = useState(""); const [name, setName] = useState("");
  const [busy, setBusy] = useState(false); const [notice, setNotice] = useState(""); const [error, setError] = useState("");
  const { user } = useAccount(); const navigate = useNavigate();
  useEffect(() => { if (user) void navigate({ to: "/", replace: true }); }, [user, navigate]);
  async function submit() {
    setBusy(true); setError(""); setNotice("");
    try {
      if (mode === "confirm") {
        const r = await supabase.auth.resend({ type: "signup", email: email.trim(), options: { emailRedirectTo: window.location.origin } });
        if (r.error) throw r.error;
        setNotice("Confirmation email requested. Check your inbox and spam folder, then open the link to sign in.");
      } else if (mode === "forgot") {
        const r = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/reset-password` }); if (r.error) throw r.error; setNotice("Check your email for a password reset link.");
      } else if (mode === "signup") {
        const r = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin, data: { display_name: name } } }); if (r.error) throw r.error;
        if (!r.data.session) { setMode("confirm"); setNotice("Check your inbox and spam folder to confirm your account. You can request another confirmation below."); }
      } else { const r = await supabase.auth.signInWithPassword({ email, password }); if (r.error) throw r.error; await navigate({ to: "/", replace: true }); }
    } catch (e) {
      if (typeof e === "object" && e !== null && "code" in e && e.code === "email_not_confirmed") {
        setMode("confirm"); setError("Your email hasn’t been confirmed yet. Request a new confirmation link below.");
      } else setError(e instanceof Error ? e.message : "Sign-in failed.");
    } finally { setBusy(false); }
  }
  async function social(provider: "google" | "lovable") {
    setError(""); const r = await lovable.auth.signInWithOAuth(provider, { redirect_uri: `${window.location.origin}/auth` }); if (r.error) setError(r.error.message); if (!r.error && !r.redirected) await navigate({ to: "/", replace: true });
  }
  return <main className="flex min-h-screen items-center justify-center px-5"><div className="w-full max-w-sm space-y-5">
    <h1 className="text-3xl font-bold">OmniAI</h1><h2 className="text-xl">{mode === "signup" ? "Create your account" : mode === "forgot" ? "Reset your password" : mode === "confirm" ? "Confirm your email" : "Welcome back"}</h2>
    <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); void submit(); }}>
      {mode === "signup" && <label className="block text-sm">Display name<Input value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" /></label>}
      <label className="block text-sm">Email<Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" /></label>
      {(mode === "signin" || mode === "signup") && <label className="block text-sm">Password<Input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === "signup" ? "new-password" : "current-password"} /></label>}
      <Button className="w-full" disabled={busy}>{busy ? "Please wait…" : mode === "signup" ? "Create account" : mode === "forgot" ? "Send reset link" : mode === "confirm" ? "Send confirmation link" : "Sign in"}</Button>
    </form>
    {notice && <p role="status" className="text-sm text-success">{notice}</p>}{error && <p role="alert" className="text-sm text-destructive">{error}</p>}
    {(mode === "signin" || mode === "signup") && <div className="space-y-3"><Button variant="outline" className="w-full" onClick={() => void social("google")}>Continue with Google</Button><Button className="lovable-auth-button w-full" onClick={() => void social("lovable")}>Continue with Lovable</Button></div>}
    <div className="flex justify-between"><Button variant="link" size="sm" disabled={busy} onClick={() => { setMode(mode === "signin" ? "signup" : "signin"); setNotice(""); setError(""); }}>{mode === "signin" ? "Create account" : "Back to sign in"}</Button>{mode === "signin" && <Button variant="link" size="sm" disabled={busy} onClick={() => { setMode("forgot"); setNotice(""); setError(""); }}>Forgot password?</Button>}</div>
    {mode === "signin" && <Button variant="link" className="w-full" disabled={busy} onClick={() => { setMode("confirm"); setNotice(""); setError(""); }}>Resend confirmation email</Button>}
  </div></main>;
}