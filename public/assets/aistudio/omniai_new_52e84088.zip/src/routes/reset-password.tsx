import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
export const Route = createFileRoute("/reset-password")({ head: () => ({ meta: [{ title: "Reset password — OmniAI" }, { name: "description", content: "Securely reset your OmniAI password." }, { property: "og:title", content: "Reset password — OmniAI" }, { property: "og:description", content: "Recover your OmniAI account." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }), component: ResetPassword });
function ResetPassword() {
  const [recovery, setRecovery] = useState(false); const [password, setPassword] = useState(""); const [notice, setNotice] = useState(""); const [busy, setBusy] = useState(false);
  useEffect(() => { setRecovery(new URLSearchParams(window.location.hash.slice(1)).get("type") === "recovery"); }, []);
  return <main className="flex min-h-screen items-center justify-center p-6"><form className="w-full max-w-sm space-y-4" onSubmit={async (e) => { e.preventDefault(); setBusy(true); const r = await supabase.auth.updateUser({ password }); setNotice(r.error?.message ?? "Password updated."); setBusy(false); }}><h1 className="text-2xl">Reset your password</h1>{recovery ? <><label>New password<Input type="password" minLength={8} required value={password} onChange={(e) => setPassword(e.target.value)} /></label><Button disabled={busy}>Update password</Button></> : <p>Open your password reset email to continue.</p>}<p role="status">{notice}</p><Button asChild variant="link"><Link to="/auth">Back to sign in</Link></Button></form></main>;
}