import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, Sparkles } from "lucide-react";
import { studios, categories } from "@/lib/studios";
import { OmniPlans } from "@/components/OmniPlans";
import { HoloOrb } from "@/components/HoloOrb";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "OmniAI — Every AI tool in one hub" },
      { name: "description", content: "Video, music, images, design, app builders, automations and connectors — all AI, one place." },
      { property: "og:title", content: "OmniAI — Every AI tool in one hub" },
      { property: "og:description", content: "Stop juggling 20 apps. Every AI studio in one place." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [cat, setCat] = useState<string>("All");
  const [q, setQ] = useState("");
  const list = studios.filter(
    (s) => (cat === "All" || s.category === cat) &&
      (s.name + s.like + s.tagline).toLowerCase().includes(q.toLowerCase()),
  );

  return (
    <div className="min-h-screen">

      <section className="mx-auto max-w-4xl px-6 pb-6 pt-4 text-center">
        <div className="mx-auto h-48 w-48 md:h-60 md:w-60"><HoloOrb /></div>
        <h1 className="text-5xl font-bold leading-tight md:text-7xl">
          Every AI tool.<br /><span className="text-brand">One hub.</span>
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-lg text-muted-foreground">
          Edit video, make songs, generate images, build apps and automate your work — without switching between 20 apps.
        </p>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search tools… try “Suno”, “CapCut”, “Lovable”"
          className="mx-auto mt-10 block w-full max-w-xl rounded-2xl border bg-card/80 px-5 py-4 text-base outline-none backdrop-blur focus:ring-2 focus:ring-ring"
        />
      </section>

      <main className="mx-auto max-w-7xl px-6 pb-24">
        <div className="mb-8 flex flex-wrap justify-center gap-2">
          {["All", ...categories].map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`rounded-full border px-4 py-1.5 text-sm transition ${cat === c ? "bg-primary text-primary-foreground" : "bg-card/60 text-muted-foreground hover:text-foreground"}`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {list.map((s) => (
            <Link
              key={s.id}
              to="/studio/$id"
              params={{ id: s.id }}
              className="group relative flex flex-col rounded-2xl bg-card/70 p-5 backdrop-blur transition hover:-translate-y-1 glow-frame"
            >
              <div className="mb-4 flex items-center justify-between">
                <span className="grid size-11 place-items-center rounded-xl bg-secondary text-primary"><s.icon className="size-5" /></span>
                <span className="text-xs uppercase tracking-wider text-muted-foreground">{s.category}</span>
              </div>
              <h3 className="text-lg font-semibold">{s.name}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{s.tagline}</p>
              <p className="mt-4 text-xs text-muted-foreground/80">Like {s.like}</p>
              <ArrowRight className="absolute bottom-5 right-5 size-4 text-primary opacity-0 transition group-hover:opacity-100" />
            </Link>
          ))}
        </div>
        <div className="mt-10"><OmniPlans /></div>
        {list.length === 0 && <p className="text-center text-muted-foreground">No tools match.</p>}
      </main>
    </div>
  );
}
