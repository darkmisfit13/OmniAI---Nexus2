import { createFileRoute } from "@tanstack/react-router";
import { OmniBeatProduction } from "@/components/studios/OmniBeatProduction";
export const Route = createFileRoute("/_authenticated/music-video/$projectId")({
  head: () => ({ meta: [{ title: "OmniBeat production — OmniAI" }, { name: "description", content: "Private staged music film production with OmniAI." }, { property: "og:title", content: "OmniBeat production — OmniAI" }, { property: "og:description", content: "Track analysis, visual direction, references, scenes, clips and final film." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: ProductionPage,
});
function ProductionPage() { const { projectId } = Route.useParams(); return <OmniBeatProduction key={projectId} projectId={projectId} />; }