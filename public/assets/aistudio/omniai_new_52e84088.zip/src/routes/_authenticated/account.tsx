import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getProfile, saveProfile, getMemories, forgetMemory } from "@/lib/private.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AccountControl } from "@/components/AccountProvider";
import { OmniPlans } from "@/components/OmniPlans";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
export const Route = createFileRoute("/_authenticated/account")({ head: () => ({ meta: [{ title: "My profile and memory — OmniAI" }, { name: "description", content: "Manage your OmniAI profile and private AI memory." }, { property: "og:title", content: "My account — OmniAI" }, { property: "og:description", content: "Your profile and private conversation memory." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }), component: Account });
function Account() {
  const profileFn = useServerFn(getProfile), memoriesFn = useServerFn(getMemories), saveFn = useServerFn(saveProfile), forgetFn = useServerFn(forgetMemory); const qc = useQueryClient();
  const profile = useQuery({ queryKey: ["profile"], queryFn: () => profileFn() }); const memories = useQuery({ queryKey: ["memories"], queryFn: () => memoriesFn() });
  return <main className="h-screen overflow-auto p-6"><header className="flex justify-between"><Button asChild variant="ghost"><Link to="/">← All studios</Link></Button><AccountControl /></header><div className="mx-auto max-w-2xl py-10 space-y-8"><h1 className="text-3xl">My account</h1>
    {profile.data && <form className="space-y-3" onSubmit={async (e) => { e.preventDefault(); const fd = new FormData(e.currentTarget); try { await saveFn({ data: { name: String(fd.get("name") ?? "") } }); await qc.invalidateQueries({ queryKey: ["profile"] }); toast.success("Profile saved"); } catch (err) { toast.error(String(err)); } }}><label>Display name<Input name="name" defaultValue={profile.data.display_name} /></label><Button>Save profile</Button></form>}
    <OmniPlans />
    <section><h2 className="text-xl mb-2">Private AI memory</h2><p className="text-sm text-muted-foreground mb-4">Your messages can be recalled across your conversations. Delete a memory here to stop future recall.</p>{memories.data?.map((m) => <div key={m.id} className="flex items-start justify-between gap-3 border-b py-3"><p className="text-sm whitespace-pre-wrap break-words">{m.content}</p><Button title="Forget memory" aria-label="Forget memory" size="icon-sm" variant="ghost" onClick={async () => { try { await forgetFn({ data: { id: m.id } }); await qc.invalidateQueries({ queryKey: ["memories"] }); } catch (e) { toast.error(String(e)); } }}><Trash2 /></Button></div>)}{memories.data?.length === 0 && <p className="text-muted-foreground">No memories yet.</p>}{memories.error && <p className="text-destructive">{memories.error.message}</p>}</section>
  </div></main>;
}