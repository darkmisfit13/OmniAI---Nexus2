import { createFileRoute } from "@tanstack/react-router";
import { loadThread } from "@/lib/private.functions";
import { OmniChat } from "@/components/studios/OmniChat";
import type { UIMessage } from "ai";
export const Route = createFileRoute("/_authenticated/chat/$threadId")({
  loader: ({ params }) => loadThread({ data: { id: params.threadId } }),
  head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.thread.title ?? "Conversation"} — OmniAI` }, { name: "description", content: "A private OmniAI conversation with cross-thread memory." }, { property: "og:title", content: "Private conversation — OmniAI" }, { property: "og:description", content: "Your creative AI partner." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: ThreadPage,
});
function ThreadPage() { const { threadId } = Route.useParams(); const data = Route.useLoaderData(); return <div className="h-screen overflow-hidden"><OmniChat key={threadId} threadId={threadId} initialMessages={data.messages as unknown as UIMessage[]} /></div>; }