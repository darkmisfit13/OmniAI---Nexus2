import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Plus, Trash2, Radio, ShieldCheck, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { councilAccess, listCouncil, saveCouncil, changeCouncil } from "@/lib/council.functions";
import { COUNCIL_PROVIDERS, type CouncilInput } from "@/lib/council";
import { setOrbMotion } from "@/lib/workspace-settings.functions";
import { useWorkspaceState } from "@/components/WorkspaceStateProvider";

export const Route = createFileRoute("/_authenticated/council")({
  head: () => ({ meta: [{ title: "Council administration — OmniAI" }, { name: "description", content: "Manage your privately connected LLM Council in OmniAI." }, { property: "og:title", content: "Council administration — OmniAI" }, { property: "og:description", content: "Private administrator controls for the OmniAI Council." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: CouncilPage,
});
function CouncilPage() {
  const motion = useServerFn(setOrbMotion);
  const { orbEnabled } = useWorkspaceState();
  const access = useServerFn(councilAccess), list = useServerFn(listCouncil), save = useServerFn(saveCouncil), change = useServerFn(changeCouncil);
  const qc = useQueryClient();
  const permission = useQuery({ queryKey: ["council-access"], queryFn: () => access() });
  const members = useQuery({ queryKey: ["council-members"], queryFn: () => list(), enabled: permission.data?.admin === true });
  const [form, setForm] = useState<CouncilInput>({ label: "", provider: "openai", model: "gpt-4.1", apiKey: "" });
  const [busy, setBusy] = useState(""); const [error, setError] = useState("");
  async function act(id: string, action: "enable" | "disable" | "remove" | "test") {
    setBusy(id); setError("");
    try { const r = await change({ data: { id, action } }); toast.success(r.message); await qc.invalidateQueries({ queryKey: ["council-members"] }); }
    catch (e) { setError(e instanceof Error ? e.message : "Council request failed."); } finally { setBusy(""); }
  }
  if (permission.isPending) return <div className="grid h-full place-items-center"><Loader2 className="animate-spin text-primary" /></div>;
  if (!permission.data?.admin) return <div className="p-6"><h1 className="text-2xl">Council administration</h1><p role="alert" className="mt-3 text-destructive">{permission.error?.message ?? "Administrator access required."}</p></div>;
  return <main className="h-full overflow-y-auto p-4 sm:p-6"><header className="mb-6 flex items-center gap-3"><ShieldCheck className="size-8 text-primary" /><div><span className="hud-label text-primary">OmniAI / Intelligence</span><h1 className="text-2xl font-display">Council administration</h1></div></header>
    {(error || members.error) && <p role="alert" className="mb-4 text-destructive">{error || members.error?.message}</p>}
    <section className="mb-6 flex max-w-3xl items-center justify-between gap-5 border-y py-5"><div><h2 className="text-lg">Global orb animation</h2><p className="mt-1 text-sm text-muted-foreground">Continuous while enabled. Reduced-motion preferences remain respected.</p></div><Switch aria-label="Global orb animation" checked={orbEnabled} disabled={!!busy} onCheckedChange={async enabled => { setBusy("motion"); try { await motion({ data: { enabled } }); qc.setQueryData(["orb-motion"], enabled); toast.success(enabled ? "Orb animation enabled." : "Orb animation paused."); } catch (e) { setError(e instanceof Error ? e.message : "Motion setting failed."); } finally { setBusy(""); } }} /></section>
    <section className="border-b pb-6"><h2 className="mb-4 text-lg">Connect a model</h2><form className="grid max-w-3xl gap-4 sm:grid-cols-2" onSubmit={async (e) => { e.preventDefault(); setBusy("save"); setError(""); try { await save({ data: form }); setForm((f) => ({ ...f, label: "", apiKey: "" })); await qc.invalidateQueries({ queryKey: ["council-members"] }); toast.success("Council model connected."); } catch (e) { setError(e instanceof Error ? e.message : "Connection could not be saved."); } finally { setBusy(""); } }}>
      <div className="space-y-2"><Label htmlFor="council-label">Member name</Label><Input id="council-label" required value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="Research specialist" /></div>
      <div className="space-y-2"><Label>Provider</Label><Select value={form.provider} onValueChange={(value) => { const p = COUNCIL_PROVIDERS.find((p) => p.id === value); if (p) setForm({ ...form, provider: p.id, model: p.model }); }}><SelectTrigger aria-label="Council provider"><SelectValue /></SelectTrigger><SelectContent>{COUNCIL_PROVIDERS.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent></Select></div>
      <div className="space-y-2"><Label htmlFor="council-model">Model ID</Label><Input id="council-model" required value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} /></div>
      <div className="space-y-2"><Label htmlFor="council-key">API key</Label><Input id="council-key" type="password" autoComplete="off" required value={form.apiKey} onChange={(e) => setForm({ ...form, apiKey: e.target.value })} /></div>
      <div className="sm:col-span-2 flex flex-wrap items-center gap-3"><Button disabled={!!busy} type="submit">{busy === "save" ? <Loader2 className="animate-spin" /> : <Plus />}Connect model</Button><span className="text-xs text-muted-foreground">Encrypted key · administrator only</span></div>
    </form></section>
    <section className="pt-6"><div className="mb-4 flex flex-wrap items-center justify-between gap-2"><h2 className="text-lg">Council members</h2><span className="hud-chip">{members.data?.filter((m) => m.enabled).length ?? 0} enabled</span></div>
      {!members.data?.length && <p className="text-sm text-muted-foreground">No models connected.</p>}
      <div className="space-y-3">{members.data?.map((m) => <article key={m.id} className="holo flex flex-wrap items-center gap-4 p-4"><Radio className={`size-5 ${m.enabled ? "text-primary" : "text-muted-foreground"}`} /><div className="min-w-0 flex-1"><h3 className="font-display">{m.label}</h3><p className="break-all text-xs text-muted-foreground">{m.provider} / {m.model}</p><p className="mt-1 text-xs text-muted-foreground">{m.last_checked ? `Last verified ${new Date(m.last_checked).toLocaleString()}` : "Not tested"}</p></div><div className="flex flex-wrap items-center gap-2"><Switch aria-label={`Enable ${m.label}`} checked={m.enabled} disabled={!!busy} onCheckedChange={(enabled) => void act(m.id, enabled ? "enable" : "disable")} /><Button size="sm" variant="outline" disabled={!!busy} onClick={() => void act(m.id, "test")}>{busy === m.id ? <Loader2 className="animate-spin" /> : <Radio />}Test connection</Button><Button size="icon-sm" variant="ghost" aria-label={`Remove ${m.label}`} title="Remove connection" disabled={!!busy} onClick={() => { if (window.confirm(`Remove ${m.label}?`)) void act(m.id, "remove"); }}><Trash2 /></Button></div></article>)}</div>
      <p className="mt-5 text-xs text-muted-foreground">Provider usage, including connection tests, is billed by your provider. With no enabled members, Council uses OmniAI’s default models.</p>
    </section>
  </main>;
}