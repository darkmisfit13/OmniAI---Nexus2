import { describe, expect, it } from "vitest";
import { eventEnabled, notificationPayload, validateWebhook } from "../lib/notifications";
describe("notification rules", () => {
  it("accepts Make scenario hooks", () => { expect(validateWebhook("https://hook.eu1.make.com/example")).toBe("https://hook.eu1.make.com/example"); });
  it("rejects private endpoints, credentials, insecure URLs and lookalike hosts", () => {
    for (const url of ["http://hook.eu1.make.com/x", "https://127.0.0.1/x", "https://localhost/x", "https://hook.eu1.make.com.evil.test/x", "https://user:pass@hook.eu1.make.com/x"]) expect(() => validateWebhook(url)).toThrow();
  });
  it("dispatches only the independently enabled event", () => {
    const settings = { webhook_url: "", generation_enabled: true, security_enabled: false, compilation_enabled: false };
    expect(eventEnabled(settings, "generation")).toBe(true); expect(eventEnabled(settings, "security")).toBe(false); expect(eventEnabled(settings, "compilation")).toBe(false);
  });
  it("uses exact telemetry fields without inventing deducted credits", () => { expect(notificationPayload("owner", "audio", null, "2026-10-20T04:23:00Z")).toEqual({ timestamp: "2026-10-20T04:23:00Z", actor_id: "owner", task_type: "audio", credits_deducted: null }); });
});