import { describe, expect, it, vi, beforeEach } from "vitest";
const { rpc } = vi.hoisted(() => ({ rpc: vi.fn() }));
vi.mock("@/integrations/supabase/client.server", () => ({ supabaseAdmin: { rpc } }));
import { chargedCompute } from "@/lib/studio-credit.server";
const task = { operation: "image" as const, target: "image", prompt: "robot" };
describe("secure processing release", () => {
  beforeEach(() => rpc.mockReset());
  it("never dispatches compute without explicit confirmation", async () => {
    const compute = vi.fn();
    await expect(chargedCompute(undefined, "owner", task, compute)).rejects.toThrow("Confirm & Deduct");
    expect(compute).not.toHaveBeenCalled();
    expect(rpc).not.toHaveBeenCalled();
  });
  it("never dispatches a rejected, mismatched or replayed approval", async () => {
    rpc.mockResolvedValue({ error: { message: "already used" } });
    const compute = vi.fn();
    await expect(chargedCompute("approval", "owner", task, compute)).rejects.toThrow("already used");
    expect(compute).not.toHaveBeenCalled();
  });
  it("releases only after the atomic owner/hash check", async () => {
    rpc.mockResolvedValue({ error: null });
    const compute = vi.fn(async () => "saved output");
    await expect(chargedCompute("approval", "owner", task, compute)).resolves.toBe("saved output");
    expect(rpc).toHaveBeenCalledWith("consume_studio_credit_charge", { p_id: "approval", p_user: "owner", p_operation: "image", p_hash: expect.stringMatching(/^[a-f0-9]{64}$/) });
    expect(compute).toHaveBeenCalledTimes(1);
  });
  it("records a refund if dispatched synchronous processing fails", async () => {
    rpc.mockResolvedValue({ error: null });
    await expect(chargedCompute("approval", "owner", task, async () => { throw new Error("provider failed"); })).rejects.toThrow("provider failed");
    expect(rpc).toHaveBeenLastCalledWith("refund_studio_credit_charge", { p_id: "approval", p_user: "owner" });
  });
});