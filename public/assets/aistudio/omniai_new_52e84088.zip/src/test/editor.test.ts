import { describe, expect, it } from "vitest";
import { clipDuration, curveRate } from "@/lib/editor";

describe("video editor rules", () => {
  it("2x speed halves a clip's timeline length", () => { expect(clipDuration({ in: 0, out: 10, speed: 2 })).toBe(5); });
  it("bullet curve slows the middle to 0.2x", () => { expect(curveRate("bullet", 0.5)).toBe(0.2); });
  it("normal curve keeps real-time playback", () => { expect(curveRate("none", 0.5)).toBe(1); });
});
