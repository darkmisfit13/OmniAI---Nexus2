import { describe, expect, it } from "vitest";
import { orbDynamics } from "@/lib/orb-lifecycle";

describe("Plasma chat lifecycle", () => {
  it("accelerates routing and streaming relative to accepted input", () => {
    expect(orbDynamics.routed.rotation).toBeGreaterThan(orbDynamics.classified.rotation);
    expect(orbDynamics.streaming.turbulence).toBeGreaterThan(orbDynamics.routed.turbulence);
  });
  it("settles on completion and slows on failure", () => {
    expect(orbDynamics.succeeded.pulse).toBeLessThan(orbDynamics.streaming.pulse);
    expect(orbDynamics.failed.rotation).toBeLessThan(orbDynamics.idle.rotation);
  });
});