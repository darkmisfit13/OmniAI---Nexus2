import { describe, expect, it } from "vitest";
import { musicCreditRequest, musicInput, musicModel, unfinishedMusicRefund } from "@/lib/music";
describe("OmniWave pricing and releases", () => {
  it("refunds only the unfinished song in a 48 CR pair", () => expect(unfinishedMusicRefund("pair", 1)).toBe(24));
  it("refunds 48 CR when neither song finishes", () => expect(unfinishedMusicRefund("pair", 0)).toBe(48));
  it("does not refund a completed pair", () => expect(unfinishedMusicRefund("pair", 2)).toBe(0));
  it("keeps the teaser on the 30-second clip model", () => expect(musicModel({ package: "teaser" })).toBe("google/lyria-3-clip-preview"));
  it("uses the full song model for the 24 CR package", () => expect(musicModel({ package: "song" })).toBe("google/lyria-3-pro-preview"));
  it("never implicitly turns a standard request into a paid preview", () => expect(musicInput.parse({ prompt: "jazz" }).preview).toBe(false));
  it("requires a separate full synthesis approval for Masters", () => {
    const d = musicInput.parse({ prompt: "jazz", preview: true, package: "song" });
    expect(musicCreditRequest(d)).toEqual({ operation: "music-song", target: "music", prompt: "jazz", refUrls: [], preview: true });
    expect(() => musicCreditRequest({ ...d, package: "teaser" })).toThrow();
  });
});