import { afterEach, describe, expect, it, vi } from "vitest";
import { renderMusicFilm } from "@/lib/music-video-render";

vi.mock("fix-webm-duration", () => ({ default: vi.fn(async (blob: Blob) => blob) }));

afterEach(() => { vi.restoreAllMocks(); vi.unstubAllGlobals(); });

function setup() {
  const events: string[] = [], videos: Array<Record<string, any>> = [];
  const audio = { duration: 30, currentTime: 0, ended: false, pause: () => events.push("audio pause"), play: async () => { events.push(`audio ${audio.currentTime}`); }, removeAttribute: vi.fn(), load() { queueMicrotask(() => this.onloadeddata?.()); }, onloadeddata: null as null | (() => void), src: "" };
  const ctx = { drawImage: () => events.push("frame") };
  const stream = { addTrack: vi.fn(), getTracks: () => [{ stop: vi.fn() }] };
  vi.spyOn(document, "createElement").mockImplementation(((tag: string) => {
    if (tag === "canvas") return { getContext: () => ctx, captureStream: () => stream };
    if (tag === "audio") return audio;
    const video: Record<string, any> = { duration: 8, videoWidth: 1280, videoHeight: 720, currentTime: 0, ended: false,
      load() { queueMicrotask(() => video['onloadeddata']?.()); }, pause: vi.fn(), removeAttribute: vi.fn(),
      async play() { video['onplaying']?.(); queueMicrotask(() => { video['ended'] = true; video['onended']?.(); }); },
    };
    videos.push(video); return video;
  }) as typeof document.createElement);
  vi.stubGlobal("requestAnimationFrame", () => 1); vi.stubGlobal("cancelAnimationFrame", vi.fn());
  vi.stubGlobal("AudioContext", class { destination = {}; createMediaStreamDestination() { return { stream: { getAudioTracks: () => [] } }; } createMediaElementSource() { return { connect: vi.fn() }; } async resume() {} async close() {} });
  vi.stubGlobal("MediaRecorder", class {
    static isTypeSupported() { return true; }
    state = "inactive"; ondataavailable?: (e: { data: Blob }) => void; onstop?: () => void;
    start() { events.push("start"); this.state = "recording"; }
    pause() { events.push("pause"); this.state = "paused"; }
    resume() { events.push("resume"); this.state = "recording"; }
    stop() { this.state = "inactive"; this.ondataavailable?.({ data: new Blob(["video"]) }); this.onstop?.(); }
  });
  return { events, videos };
}

describe("final-film merge recording", () => {
  it("draws a scene before recording and pauses at each scene boundary", async () => {
    const { events } = setup();
    const blob = await renderMusicFilm([{ url: "first" }, { url: "second" }], "song");
    expect(blob.size).toBe(5);
    expect(events.indexOf("frame")).toBeLessThan(events.indexOf("start"));
    expect(events.filter((event) => event === "pause")).toHaveLength(2);
    expect(events).toContain("resume");
    expect(events).toContain("audio 8");
    const { default: fix } = await import("fix-webm-duration");
    expect(fix).toHaveBeenLastCalledWith(blob, 16000, { logger: false });
  });
  it("rejects missing scenes before starting any recording", async () => {
    const { events } = setup();
    await expect(renderMusicFilm([{ url: "first" }, {}], "song")).rejects.toThrow("All clips must be ready");
    expect(events).not.toContain("start");
  });
});