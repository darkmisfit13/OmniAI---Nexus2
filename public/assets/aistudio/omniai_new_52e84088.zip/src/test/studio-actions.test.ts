import { describe, it, expect } from "vitest";
import { parseCompanionReply } from "@/lib/studio-actions";

describe("parseCompanionReply", () => {
  it("extracts reply and actions from fenced JSON", () => {
    const r = parseCompanionReply('```json\n{"reply":"On it","actions":[{"name":"editor_filter","args":{"filter":"Noir"}}]}\n```');
    expect(r.reply).toBe("On it");
    expect(r.actions).toEqual([{ name: "editor_filter", args: { filter: "Noir" } }]);
  });
  it("treats plain text as a reply with no actions", () => {
    expect(parseCompanionReply("Hello there")).toEqual({ reply: "Hello there", actions: [] });
  });
});
