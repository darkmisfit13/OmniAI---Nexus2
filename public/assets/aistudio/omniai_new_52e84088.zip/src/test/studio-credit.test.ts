import { describe, expect, it } from "vitest";
import { creditCost, canonicalCreditRequest } from "@/lib/studio-credit";
describe("locked studio rates", () => {
  it("charges analysis at 5 CR", () => expect(creditCost({ operation: "analysis", target: "music-video" })).toBe(5));
  it("charges each image at 3 CR regardless of style", () => expect(creditCost({ operation: "image", target: "image" })).toBe(3));
  it("charges video at 8 CR per second", () => expect(creditCost({ operation: "video", target: "video-gen", seconds: 8 })).toBe(64));
  it("charges corrections at 25 CR", () => expect(creditCost({ operation: "correction", target: "music-video" })).toBe(25));
  it("charges a 30-second teaser at 12 CR", () => expect(creditCost({ operation: "music-teaser", target: "music" })).toBe(12));
  it("charges a full song at 24 CR", () => expect(creditCost({ operation: "music-song", target: "music" })).toBe(24));
  it("charges the dual-song package at 48 CR", () => expect(creditCost({ operation: "music-pair", target: "music" })).toBe(48));
  it("binds preview approvals separately from the standard draft", () => {
    const r = { operation: "music-song" as const, target: "music", prompt: "city lights" };
    expect(canonicalCreditRequest(r)).not.toBe(canonicalCreditRequest({ ...r, preview: true }));
  });
  it("rejects duration manipulation", () => expect(() => creditCost({ operation: "video", target: "video-gen", seconds: -1 })).toThrow());
  it("binds approvals to exact prompts, references and project", () => {
    const request = { operation: "image" as const, target: "image", prompt: "cat", refUrls: ["data:image/png;base64,abc"] };
    expect(canonicalCreditRequest(request)).not.toBe(canonicalCreditRequest({ ...request, prompt: "dog" }));
    expect(canonicalCreditRequest(request)).not.toBe(canonicalCreditRequest({ ...request, projectId: "another" }));
    expect(canonicalCreditRequest(request)).not.toBe(canonicalCreditRequest({ ...request, refUrls: [] }));
  });
});