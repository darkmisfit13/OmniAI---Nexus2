import { beforeEach, describe, expect, it, vi } from "vitest";
const mocks = vi.hoisted(() => ({ release: vi.fn(), access: vi.fn(), save: vi.fn(), rpc: vi.fn(), from: vi.fn() }));
vi.mock("@/lib/studio-credit.server", () => ({ releaseCredit: mocks.release }));
vi.mock("@/lib/omniwave-access.server", () => ({ assertOmniWaveAccess: mocks.access }));
vi.mock("@/lib/media.server", () => ({ persistOutput: mocks.save }));
vi.mock("@/integrations/supabase/client.server", () => ({ supabaseAdmin: { rpc: mocks.rpc, from: mocks.from } }));
import { runMusicGeneration } from "@/lib/music.server";
import { musicInput } from "@/lib/music";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
describe("music processing release", () => {
  beforeEach(() => { vi.resetAllMocks(); vi.stubGlobal("fetch", vi.fn()); });
  it("rejects an expired upgrade before consuming approval or contacting Pro", async () => {
    mocks.access.mockRejectedValue(new Error("Active OmniWave Creators or OmniWave Masters required"));
    await expect(runMusicGeneration({} as SupabaseClient<Database>, "owner", musicInput.parse({ prompt: "jazz", package: "pair" }))).rejects.toThrow("required");
    expect(mocks.release).not.toHaveBeenCalled();
    expect(fetch).not.toHaveBeenCalled();
  });
  it("never calls the music endpoint before confirmation", async () => {
    mocks.release.mockRejectedValue(new Error("Explicit confirmation required"));
    await expect(runMusicGeneration({} as SupabaseClient<Database>, "owner", musicInput.parse({ prompt: "jazz" }))).rejects.toThrow("confirmation");
    expect(fetch).not.toHaveBeenCalled();
    expect(mocks.from).not.toHaveBeenCalled();
    expect(mocks.save).not.toHaveBeenCalled();
  });
  it("rejects mismatched and already consumed approvals before dispatch", async () => {
    mocks.release.mockRejectedValue(new Error("Already used or mismatched"));
    const d = musicInput.parse({ prompt: "jazz", package: "pair", approvalId: "00000000-0000-4000-8000-000000000001" });
    await expect(runMusicGeneration({} as SupabaseClient<Database>, "owner", d)).rejects.toThrow("mismatched");
    expect(fetch).not.toHaveBeenCalled();
  });
});