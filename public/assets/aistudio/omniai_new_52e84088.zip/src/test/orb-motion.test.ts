import { describe, expect, it } from "vitest";
import { orbMotionPaused } from "@/lib/orb-motion";
describe("global orb controls and accessibility", () => {
  it("runs continuously while enabled without reduced motion", () => expect(orbMotionPaused(true, false, null)).toBe(false));
  it("admin off overrides a local motion override", () => expect(orbMotionPaused(false, false, true)).toBe(true));
  it("respects reduced motion by default", () => expect(orbMotionPaused(true, true, null)).toBe(true));
  it("permits explicit accessible play only when globally enabled", () => expect(orbMotionPaused(true, true, true)).toBe(false));
});