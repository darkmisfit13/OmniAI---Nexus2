import { describe, it, expect, vi, beforeEach } from 'vitest';
import { OMNI_PLANS, pipelineCredits, escrowRemaining, omniPlan } from '@/lib/omni-plans';
import type { SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/integrations/supabase/types';
const { rpc } = vi.hoisted(() => ({ rpc: vi.fn() }));
vi.mock('@/integrations/supabase/client.server', () => ({ supabaseAdmin: { rpc } }));
import { pipelineCompute } from '@/lib/pipeline-escrow.server';
const client = { from: () => ({ select: () => ({ eq: () => ({ eq: () => ({ neq: () => ({ single: async () => ({ data: { id: 'reservation' }, error: null }) }) }) }) }) }) } as unknown as SupabaseClient<Database>;
describe('approved global plans', () => {
  it('Free allocates 100 CR at 0 monthly', () => expect([OMNI_PLANS[0].monthlyCredits, OMNI_PLANS[0].monthlyUsd]).toEqual([100, 0]));
  it('Plus allocates 1200 CR at 19 monthly', () => expect([OMNI_PLANS[1].monthlyCredits, OMNI_PLANS[1].monthlyUsd]).toEqual([1200, 19]));
  it('Pro allocates 4500 CR at 49 and unlocks Pro', () => expect([OMNI_PLANS[2].monthlyCredits, OMNI_PLANS[2].monthlyUsd, OMNI_PLANS[2].pro]).toEqual([4500, 49, true]));
  it('Ultra allocates 10000 CR at 99 and maximum priority', () => expect([OMNI_PLANS[3].monthlyCredits, OMNI_PLANS[3].monthlyUsd, OMNI_PLANS[3].priority]).toEqual([10000, 99, 'Maximum']));
  it('expired Pro has no active Pro entitlement', () => expect(omniPlan({ plan: 'pro', status: 'active', period_start: '2026-01-01', period_end: '2026-02-01' }, Date.parse('2026-03-01')).pro).toBe(false));
});
describe('400 CR starting reservation', () => {
  beforeEach(() => rpc.mockReset());
  it('charges audio analysis at 5 CR', () => expect(pipelineCredits(0, 0)).toBe(5));
  it('charges each reference at 3 CR', () => expect(pipelineCredits(0, 4)).toBe(17));
  it('charges animation at 8 CR/sec', () => expect(pipelineCredits(30, 0)).toBe(245));
  it('releases 140 CR from a 400 reservation after 260 completed', () => expect(escrowRemaining({ reserved: 400, spent: 260, pending: 0, released: 0 })).toBe(140));
  it('does not release in-flight cost on stop', () => expect(escrowRemaining({ reserved: 400, spent: 5, pending: 64, released: 0 })).toBe(331));
  it('does not dispatch over-budget steps or deduct extra without authorization', async () => {
    rpc.mockResolvedValue({ data: { additional: 24 }, error: null });
    const work = vi.fn();
    await expect(pipelineCompute(client, 'owner', 'project', 'clip-1', 'video', 8, {}, work, true)).rejects.toThrow('CONTINUATION_REQUIRED');
    expect(work).not.toHaveBeenCalled(); expect(rpc).toHaveBeenCalledTimes(1);
  });
  it('does not mark a submitted asynchronous job completed', async () => {
    rpc.mockResolvedValue({ data: { stepId: 'step' }, error: null });
    await pipelineCompute(client, 'owner', 'project', 'clip-1', 'video', 8, {}, async () => 'job', true);
    expect(rpc).toHaveBeenCalledTimes(1);
  });
  it('retains a dispatched job hold if saving fails', async () => {
    rpc.mockResolvedValue({ data: { stepId: 'step' }, error: null });
    await expect(pipelineCompute(client, 'owner', 'project', 'clip-1', 'video', 8, {}, async (_, dispatched) => { dispatched(); throw new Error('save failed'); }, true)).rejects.toThrow('remain held');
    expect(rpc).toHaveBeenCalledTimes(1);
  });
  it('refunds failed work before asynchronous dispatch', async () => {
    rpc.mockResolvedValue({ data: { stepId: 'step' }, error: null });
    await expect(pipelineCompute(client, 'owner', 'project', 'clip-1', 'video', 8, {}, async () => { throw new Error('input failed'); }, true)).rejects.toThrow('input failed');
    expect(rpc).toHaveBeenLastCalledWith('finish_omni_pipeline_step', { p_step: 'step', p_user: 'owner', p_success: false });
  });
});