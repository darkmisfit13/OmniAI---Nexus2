import { describe, it, expect } from "vitest";
import { memoryContext, userText } from "@/lib/chat-memory";

describe("Private cross-thread memory", () => {
  it("retains the user's blue jeans fact as dated context for a later conversation", () => {
    expect(memoryContext([{ content: "I am wearing blue jeans.", created_at: "2026-10-19" }])).toBe("[User said on 2026-10-19]: I am wearing blue jeans.");
  });
  it("extracts only user text and not tool content for personal memory", () => {
    expect(userText({ parts: [{ type: "text", text: "I am wearing blue jeans." }, { type: "tool-createStudioWork", text: "red jeans" }] })).toBe("I am wearing blue jeans.");
  });
});