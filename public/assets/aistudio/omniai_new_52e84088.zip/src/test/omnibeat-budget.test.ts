import { describe, expect, it } from "vitest";
import { calculateBudget, DEFAULT_BUDGET } from "@/lib/omnibeat-budget";
describe("OmniBeat user-defined estimate rules", () => {
  it("renders at $0.08 per second", () => { expect(calculateBudget({ ...DEFAULT_BUDGET, seconds: 300 }).fullRenderMicros).toBe(24_000_000); });
  it("charges $0.05 audio analysis", () => { expect(calculateBudget(DEFAULT_BUDGET).audioMicros).toBe(50_000); });
  it("charges $0.03 per image", () => { expect(calculateBudget({ ...DEFAULT_BUDGET, variants: 32 }).imagesMicros).toBe(960_000); });
  it("multiplies high-detail image baseline by 1.5", () => { expect(calculateBudget({ ...DEFAULT_BUDGET, variants: 5, highDetail: true }).imagesMicros).toBe(225_000); });
  it("retains exact processed rendering percentage", () => { expect(calculateBudget({ ...DEFAULT_BUDGET, seconds: 100, stopped: true, stopPercent: 37.5 }).renderMicros).toBe(3_000_000); });
  it("adds a $0.25 reset fee only when stopped", () => { expect(calculateBudget({ ...DEFAULT_BUDGET, stopped: true }).resetMicros).toBe(250_000); expect(calculateBudget(DEFAULT_BUDGET).resetMicros).toBe(0); });
  it("keeps zero and full stop boundaries", () => { expect(calculateBudget({ ...DEFAULT_BUDGET, stopped: true, stopPercent: 0 }).renderMicros).toBe(0); expect(calculateBudget({ ...DEFAULT_BUDGET, stopped: true, stopPercent: 100 }).renderMicros).toBe(2_400_000); });
  it("validates duration bounds of 15–300 seconds", () => { expect(() => calculateBudget({ ...DEFAULT_BUDGET, seconds: 14 })).toThrow(); expect(() => calculateBudget({ ...DEFAULT_BUDGET, seconds: 301 })).toThrow(); expect(calculateBudget({ ...DEFAULT_BUDGET, seconds: 15 }).fullRenderMicros).toBe(1_200_000); });
  it("validates image limits of 4–32", () => { expect(() => calculateBudget({ ...DEFAULT_BUDGET, variants: 3 })).toThrow(); expect(() => calculateBudget({ ...DEFAULT_BUDGET, variants: 33 })).toThrow(); });
  it("rejects invalid stop points", () => { expect(() => calculateBudget({ ...DEFAULT_BUDGET, stopPercent: 101 })).toThrow(); expect(() => calculateBudget({ ...DEFAULT_BUDGET, stopPercent: -1 })).toThrow(); });
  it("aggregates without inventing a platform-credit conversion", () => { const q = calculateBudget(DEFAULT_BUDGET); expect(q.totalUsd).toBe(2.57); expect(q.credits).toBeNull(); });
});