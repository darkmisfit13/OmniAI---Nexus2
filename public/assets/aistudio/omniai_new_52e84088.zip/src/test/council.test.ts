import { describe, expect, it, vi, afterEach } from "vitest";
import { councilInput, isCouncilAdmin } from "@/lib/council";
import { encryptCouncilKey, decryptCouncilKey, askCouncilMember } from "@/lib/council.server";
import { webcrypto } from "node:crypto";

afterEach(() => { vi.unstubAllGlobals(); vi.unstubAllEnvs(); });
describe("Council administrator rules", () => {
  it("only the separate admin role grants Council administration", () => {
    expect(isCouncilAdmin([{ role: "user" }, { role: "moderator" }])).toBe(false);
    expect(isCouncilAdmin([{ role: "admin" }])).toBe(true);
    expect(isCouncilAdmin([])).toBe(false);
  });
  it("rejects unknown endpoints and empty model identifiers", () => {
    expect(councilInput.safeParse({ label: "Member", provider: "custom", model: "model", apiKey: "test" }).success).toBe(false);
    expect(councilInput.safeParse({ label: "Member", provider: "openai", model: "", apiKey: "test" }).success).toBe(false);
  });
  it("encrypts credentials with unique IVs and rejects tampering", async () => {
    vi.stubGlobal("crypto", webcrypto); vi.stubEnv("COUNCIL_ENCRYPTION_SECRET", "test-only-not-a-production-secret");
    const first = await encryptCouncilKey("test-provider-key"), second = await encryptCouncilKey("test-provider-key");
    expect(first).not.toBe(second); expect(first).not.toContain("test-provider-key");
    expect(await decryptCouncilKey(first)).toBe("test-provider-key");
    const [iv, ciphertext] = first.split(".");
    await expect(decryptCouncilKey(`${iv}.${ciphertext?.startsWith("A") ? "B" : "A"}${ciphertext?.slice(1)}`)).rejects.toThrow();
  });
  it("routes a member to the fixed provider endpoint without exposing the key in its URL", async () => {
    const mocked = vi.fn(async (_url: string, _init: RequestInit) => Response.json({ choices: [{ message: { content: "Independent answer" } }] })); vi.stubGlobal("fetch", mocked);
    expect(await askCouncilMember({ provider: "openai", model: "test-model", apiKey: "test-provider-key" }, "Question")).toBe("Independent answer");
    expect(mocked.mock.calls[0]?.[0]).toBe("https://api.openai.com/v1/chat/completions");
  });
});