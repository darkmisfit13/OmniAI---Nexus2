import { describe, expect, it } from "vitest";
import { clipLengths, PRODUCTION_STAGES, sunkRenderMicros, correctedProduction, type ProductionState } from "@/lib/music-video";
describe("Music video production", () => {
  it("has the seven requested stages in order", () => { expect(PRODUCTION_STAGES.map((s) => s.name)).toEqual(["Track", "Visual Style", "Creative Brief", "Reference Images", "Scene Planning", "Video Clips", "Final Video"]); });
  it("covers the configured duration with supported clip lengths", () => { for (const seconds of [15, 30, 299, 300]) { const lengths = clipLengths(seconds); expect(lengths.reduce((a, b) => a + b, 0)).toBe(seconds); expect(lengths.every((n) => n >= 3 && n <= 10)).toBe(true); } });
  it("retains only completed rendering nodes at $0.08 per second", () => { expect(sunkRenderMicros(30, 8)).toBe(640_000); expect(sunkRenderMicros(30, 99)).toBe(2_400_000); });
  it("corrections invalidate downstream outputs while retaining completed compute and archived assets", () => {
    const s: ProductionState = { track: { path: "owner/track", name: "song", mediaType: "audio/wav", duration: 15 }, references: [], prompt: "Original", config: { seconds: 15, variants: 4, highDetail: false, stopped: false, stopPercent: 50 }, authorizationId: "approved", stage: 6, results: { "0": "Beat analysis", "1": "Old style" }, images: [{ path: "old-image" }], clips: [{ path: "old-clip" }], final: [], logs: [], paused: false, correctionCount: 0, renderSeconds: 8 };
    const next = correctedProduction(s, "Use a forest"); expect(next.stage).toBe(1); expect(next.results).toEqual({ "0": "Beat analysis" }); expect(next.clips).toEqual([]); expect(next.images).toEqual([]); expect(next.archived).toEqual([{ path: "old-image" }, { path: "old-clip" }]); expect(next.renderSeconds).toBe(8); expect(next.correctionCount).toBe(1);
  });
});