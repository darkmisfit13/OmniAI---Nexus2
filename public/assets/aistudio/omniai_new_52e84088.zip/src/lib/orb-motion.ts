export function orbMotionPaused(enabled: boolean, reduced: boolean, override: boolean | null) {
  return !enabled || (override === null ? reduced : !override);
}