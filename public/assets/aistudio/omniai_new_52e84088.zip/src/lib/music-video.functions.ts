import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { ProductionState } from "./music-video";
import { calculateBudget } from "./omnibeat-budget";
async function ownedWorkflow(context: { supabase: import("@supabase/supabase-js").SupabaseClient<import("@/integrations/supabase/types").Database>; userId: string }, id: string) {
  const r = await context.supabase.from("studio_projects").select("state").eq("id", id).eq("user_id", context.userId).eq("kind", "music-production").single();
  if (r.error) throw new Error("Production not found.");
  const state = r.data.state as unknown as ProductionState;
  calculateBudget(state.config);
  const approval = await context.supabase.from("studio_projects").select("state").eq("id", state.authorizationId).eq("user_id", context.userId).eq("kind", "budget-authorization").single();
  const approved = approval.data?.state as unknown as { config?: ProductionState["config"] } | undefined;
  if (approval.error || !approved?.config || approved.config.stopped || approved.config.seconds !== state.config.seconds || approved.config.variants !== state.config.variants || approved.config.highDetail !== state.config.highDetail) throw new Error("Authorize the matching production budget first.");
  return state;
}
export const analyzeMusicTrack = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: { projectId: string; approvalId?: string }) => data)
  .handler(async ({ data, context }) => {
    const state = await ownedWorkflow(context, data.projectId);
    const { pipelineCompute } = await import("./pipeline-escrow.server");
    return pipelineCompute(context.supabase, context.userId, data.projectId, `analysis-${state.correctionCount}`, "analysis", 1, { track: state.track.path }, async () => {
    if (!state.track.path.startsWith(`${context.userId}/`)) throw new Error("Track access denied.");
    const file = await context.supabase.storage.from("studio-assets").download(state.track.path);
    if (file.error || !file.data) throw new Error("Track could not be read.");
    if (file.data.size > 20 * 1024 * 1024) throw new Error("Track exceeds 20 MB.");
    const bytes = new Uint8Array(await file.data.arrayBuffer()); let raw = "";
    for (let i = 0; i < bytes.length; i += 0x8000) raw += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    const mime = state.track.mediaType;
    const format = mime.includes("wav") ? "wav" : mime.includes("webm") ? "webm" : mime.includes("ogg") ? "ogg" : mime.includes("flac") ? "flac" : mime.includes("aac") ? "aac" : mime.includes("mp4") ? "m4a" : "mp3";
    const { complete, MEDIA_MODEL } = await import("./ai.server");
    const text = await complete(MEDIA_MODEL, [{ role: "user", content: [{ type: "text", text: `Analyze this actual song for a music video. Identify style, approximate BPM with uncertainty, rhythm, mood, instruments, vocal structure and audible lyrics (mark uncertain words). Suggest dance/camera rhythm and section timings. Never claim stem isolation was performed. Creative intent: ${state.prompt.slice(0, 4000)}` }, { type: "input_audio", input_audio: { data: btoa(raw), format } }] }]);
    if (!text.trim()) throw new Error("No track analysis returned.");
    return { text };
    });
  });
export const createMusicVideoClip = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: { projectId: string; prompt: string; seconds: number; approvalId?: string }) => { if (!Number.isInteger(data.seconds) || data.seconds < 3 || data.seconds > 10) throw new Error("Clip duration must be 3–10 seconds."); return { ...data, prompt: data.prompt.slice(0, 6000) }; })
  .handler(async ({ data, context }) => {
    const state = await ownedWorkflow(context, data.projectId);
    const { pipelineCompute } = await import("./pipeline-escrow.server");
    return pipelineCompute(context.supabase, context.userId, data.projectId, `clip-${state.correctionCount}-${state.clips.length}`, "video", data.seconds, data, async (stepId, markDispatched) => {
    const parts: Record<string, unknown>[] = [{ type: "text", text: `${data.prompt}. Use <IMAGE_REF_0> as the performer reference. A single continuous shot, cinematic lighting, no dialogue. Keep identity and styling consistent.` }];
    const source = state.references[0];
    if (source) {
      if (!source.path.startsWith(`${context.userId}/`)) throw new Error("Reference access denied.");
      const file = await context.supabase.storage.from("studio-assets").download(source.path);
      if (file.error || !file.data) throw new Error("Reference could not be read.");
      if (file.data.size > 10 * 1024 * 1024) throw new Error("Reference exceeds 10 MB.");
      const bytes = new Uint8Array(await file.data.arrayBuffer()); let raw = ""; for (let i = 0; i < bytes.length; i += 0x8000) raw += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
      parts.push({ type: "image", data: btoa(raw), mime_type: source.mediaType });
    }
    const key = process.env["LOVABLE_API_KEY"]; if (!key) throw new Error("AI configuration is unavailable.");
    const response = await fetch("https://ai.gateway.lovable.dev/v1/videos", { method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" }, body: JSON.stringify({ model: "google/gemini-omni-1.1-flash", input: parts, response_format: { type: "video", resolution: "720p", duration: `${data.seconds}s`, aspect_ratio: "16:9" } }) });
    if (!response.ok) { const error = await response.json() as { message?: string }; throw new Error(error.message ?? `Video request failed (${response.status}).`); }
    markDispatched();
    const job = await response.json() as { id: string };
    const saved = await context.supabase.from("studio_projects").insert({ user_id: context.userId, studio: "music-video", kind: "pending-video", title: data.prompt, job_id: job.id }).select("id").single();
    if (saved.error) throw new Error("Clip job could not be saved.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const link = await supabaseAdmin.from("omni_pipeline_steps").update({ output_project_id: saved.data.id }).eq("id", stepId).eq("user_id", context.userId);
    if (link.error) throw new Error("Clip awaits credit reconciliation; do not regenerate.");
    return { jobId: job.id, projectId: saved.data.id };
    }, true);
  });
export const createMusicDirection = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: { projectId: string; approvalId?: string }) => data)
  .handler(async ({ data, context }) => {
    const state = await ownedWorkflow(context, data.projectId);
    if (![1, 2, 4].includes(state.stage)) throw new Error("Not a creative direction stage.");
    const { pipelineCompute } = await import("./pipeline-escrow.server");
    return pipelineCompute(context.supabase, context.userId, data.projectId, `direction-${state.correctionCount}-${state.stage}`, "direction", 1, { stage: state.stage, prompt: state.prompt }, async () => {
      const { complete } = await import("./ai.server");
      const { PRODUCTION_STAGES, clipLengths } = await import("./music-video");
      const text = await complete("openai/gpt-6-astra", [{ role: "user", content: `Track analysis: ${state.results["0"]}\nIntent: ${state.prompt}\nPrevious stages: ${JSON.stringify(state.results)}\nRuntime: ${state.config.seconds}s. Clips: ${clipLengths(state.config.seconds).join(", ")} seconds. User corrections: ${state.logs.filter((l) => l.role === "user").map((l) => l.content).join("\n")}` }], `You are OmniAI's music film director. Produce the finished ${PRODUCTION_STAGES[state.stage]?.name}, not instructions. Use concise markdown. Scene planning must specify sequential scene numbers, duration and actions matching runtime.`);
      if (!text.trim()) throw new Error("No creative output returned.");
      return { text };
    });
  });
export const applyMusicCorrection = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: { projectId: string; text: string; approvalId?: string }) => { if (!data.text.trim()) throw new Error("Enter a correction."); return { ...data, text: data.text.trim().slice(0, 4000) }; })
  .handler(async ({ data, context }) => {
    const state = await ownedWorkflow(context, data.projectId);
    const { chargedCompute } = await import("./studio-credit.server");
    return chargedCompute(data.approvalId, context.userId, { operation: "correction", target: "music-video", projectId: data.projectId, prompt: data.text }, async () => {
      const { correctedProduction } = await import("./music-video");
      const next = correctedProduction(state, data.text);
      const r = await context.supabase.from("studio_projects").update({ state: JSON.parse(JSON.stringify(next)) }).eq("id", data.projectId).eq("user_id", context.userId);
      if (r.error) throw new Error("Correction could not be saved.");
      return next;
    });
  });
export const stopMusicProduction = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: { projectId: string; approvalId?: string }) => data)
  .handler(async ({ data, context }) => {
    const state = await ownedWorkflow(context, data.projectId);
    const { pipelineReservation } = await import("./pipeline-escrow.server");
    const reservation = await pipelineReservation(context.supabase, context.userId, data.projectId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const release = await supabaseAdmin.rpc("release_omni_pipeline", { p_id: reservation.id, p_user: context.userId });
    if (release.error) throw new Error("Unused credit release unavailable.");
    const r = await context.supabase.from("studio_projects").update({ state: JSON.parse(JSON.stringify({ ...state, paused: true })) }).eq("id", data.projectId).eq("user_id", context.userId);
    if (r.error) throw new Error("Stop could not be saved.");
    return { paused: true };
  });
export const createMusicReference = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: { projectId: string }) => data)
  .handler(async ({ data, context }) => {
    const state = await ownedWorkflow(context, data.projectId);
    if (state.stage !== 3 || state.images.length >= state.config.variants) throw new Error("Not a reference stage.");
    const { pipelineCompute } = await import("./pipeline-escrow.server");
    return pipelineCompute(context.supabase, context.userId, data.projectId, `image-${state.correctionCount}-${state.images.length}`, "image", 1, { prompt: state.prompt, index: state.images.length }, async () => {
      const { editImage, generateImage } = await import("./ai.server");
      const refs = await Promise.all(state.references.map(async ref => {
        if (!ref.path.startsWith(`${context.userId}/`)) throw new Error("Reference access denied.");
        const file = await context.supabase.storage.from("studio-assets").download(ref.path);
        if (file.error || !file.data || file.data.size > 10 * 1024 * 1024) throw new Error("Reference unavailable.");
        const bytes = new Uint8Array(await file.data.arrayBuffer()); let raw = "";
        for (let i = 0; i < bytes.length; i += 0x8000) raw += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
        return { url: `data:${ref.mediaType};base64,${btoa(raw)}`, mediaType: ref.mediaType };
      }));
      const prompt = `Music film reference ${state.images.length + 1}. Preserve performer identity. ${state.prompt}\nVisual style: ${state.results["1"]}\nCreative brief: ${state.results["2"]}. Vary location and camera; no text.`.slice(0, 4000);
      const url = refs.length ? await editImage(prompt, refs) : await generateImage(prompt);
      const { persistOutput } = await import("./media.server");
      return persistOutput(context.supabase, context.userId, "music-video", prompt, { kind: "image", url });
    });
  });
