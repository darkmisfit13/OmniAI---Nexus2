import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { calculateBudget, type BudgetConfig } from "./omnibeat-budget";
export const quoteOmniBeat = createServerFn({ method: "POST" })
  .inputValidator((data: BudgetConfig) => { calculateBudget(data); return data; })
  .handler(({ data }) => calculateBudget(data));
export const authorizeOmniBeatBudget = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: BudgetConfig) => { calculateBudget(data); return data; })
  .handler(async ({ data, context }) => {
    const quote = calculateBudget(data);
    const row = await context.supabase.from("studio_projects").insert({ user_id: context.userId, studio: "music-video", kind: "budget-authorization", title: `OmniBeat ${data.seconds}s compute budget`, state: JSON.parse(JSON.stringify({ config: data, quote, authorizedAt: new Date().toISOString(), paymentCollected: false })) }).select("id").single();
    if (row.error) throw new Error("Budget approval could not be saved.");
    return { id: row.data.id, quote, paymentCollected: false };
  });