import type { BudgetConfig } from "./omnibeat-budget";
export const PRODUCTION_STAGES = [
  { name: "Track", subtitle: "Song analysis · style, beat, vibe and lyrics" },
  { name: "Visual Style", subtitle: "The look guiding the dance and final video" },
  { name: "Creative Brief", subtitle: "Your track, performer and visual world" },
  { name: "Reference Images", subtitle: "Performer, styling, locations and signature details" },
  { name: "Scene Planning", subtitle: "Scene structure and visual direction" },
  { name: "Video Clips", subtitle: "Generated clips in timeline order" },
  { name: "Final Video", subtitle: "Merge versions · preview, render, download, share or edit" },
] as const;
export type ProductionAsset = { path: string; name: string; mediaType: string; duration: number };
export type ProductionOutput = { projectId?: string; path?: string; url?: string; jobId?: string; seconds?: number; prompt?: string };
export type ProductionState = {
  track: ProductionAsset; references: ProductionAsset[]; prompt: string; config: BudgetConfig; authorizationId: string;
  stage: number; results: Record<string, string>; images: ProductionOutput[]; clips: ProductionOutput[];
  logs: { role: "user" | "assistant"; content: string }[]; paused: boolean; correctionCount: number; renderSeconds: number;
  final: ProductionOutput[];
  archived?: ProductionOutput[];
};
export function clipLengths(seconds: number) { const count = Math.ceil(seconds / 8), base = Math.floor(seconds / count), extra = seconds % count; return Array.from({ length: count }, (_, i) => base + (i < extra ? 1 : 0)); }
export function sunkRenderMicros(seconds: number, completedSeconds: number) { return Math.round(Math.max(0, Math.min(seconds, completedSeconds)) * 80_000); }
export function correctedProduction(state: ProductionState, text: string): ProductionState {
  return { ...state, prompt: `${state.prompt}\nCorrection: ${text}`, correctionCount: state.correctionCount + 1, stage: Math.min(state.stage, 1), paused: true,
    results: state.results["0"] ? { "0": state.results["0"] } : {}, images: [], clips: [], final: [],
    archived: [...(state.archived ?? []), ...state.images, ...state.clips, ...state.final],
    logs: [...state.logs, { role: "user", content: text }, { role: "assistant", content: "Correction recorded. Resume to recreate the affected stages. Previous assets remain in your saved library." }] };
}