import type { SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/integrations/supabase/types';
export async function pipelineReservation(client: SupabaseClient<Database>, userId: string, projectId: string) {
  const r = await client.from('omni_pipeline_reservations').select('*').eq('project_id', projectId).eq('user_id', userId).neq('status', 'settled').single();
  if (r.error) throw new Error('Confirm & Authorize Video Pipeline before processing.');
  return r.data;
}
export async function pipelineCompute<T>(client: SupabaseClient<Database>, userId: string, projectId: string, key: string, operation: string, units: number, request: unknown, work: (stepId: string, markDispatched: () => void) => Promise<T>, deferred = false): Promise<T> {
  const r = await pipelineReservation(client, userId, projectId);
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(JSON.stringify(request)));
  const hash = Array.from(new Uint8Array(bytes), n => n.toString(16).padStart(2, '0')).join('');
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
  const claim = await supabaseAdmin.rpc('claim_omni_pipeline_step', { p_id: r.id, p_user: userId, p_key: key, p_hash: hash, p_operation: operation, p_units: units });
  if (claim.error) throw new Error(claim.error.message);
  const result = claim.data as { additional?: number; stepId?: string };
  if (result.additional !== undefined) throw new Error('CONTINUATION_REQUIRED');
  const stepId = result.stepId;
  if (!stepId) throw new Error('Compute reservation unavailable.');
  let output: T;
  let dispatched = false;
  try { output = await work(stepId, () => { dispatched = true; }); }
  catch (error) {
    if (deferred && dispatched) throw new Error('Dispatched video awaits reconciliation; reserved credits remain held. Do not regenerate.');
    const settlement = await supabaseAdmin.rpc('finish_omni_pipeline_step', { p_step: stepId, p_user: userId, p_success: false });
    if (settlement.error) throw new Error('Failed work awaits credit reconciliation.');
    throw error;
  }
  if (!deferred) {
    const settlement = await supabaseAdmin.rpc('finish_omni_pipeline_step', { p_step: stepId, p_user: userId, p_success: true });
    if (settlement.error) throw new Error('Completed work awaits credit reconciliation; do not regenerate.');
  }
  return output;
}
export async function reconcilePipelineVideo(client: SupabaseClient<Database>, userId: string, outputId: string, success: boolean) {
  const step = await client.from('omni_pipeline_steps').select('id').eq('output_project_id', outputId).eq('user_id', userId).eq('status', 'pending').maybeSingle();
  if (step.error) throw new Error('Video credit status unavailable.');
  if (!step.data) return;
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
  const r = await supabaseAdmin.rpc('finish_omni_pipeline_step', { p_step: step.data.id, p_user: userId, p_success: success, ...(success ? { p_output: outputId } : {}) });
  if (r.error) throw new Error('Video credit settlement unavailable.');
}
