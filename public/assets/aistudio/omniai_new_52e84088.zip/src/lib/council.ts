import { z } from "zod";

export const COUNCIL_PROVIDERS = [
  { id: "openai", name: "OpenAI", model: "gpt-4.1" },
  { id: "anthropic", name: "Anthropic", model: "claude-sonnet-4-5" },
  { id: "google", name: "Google Gemini", model: "gemini-2.5-pro" },
  { id: "openrouter", name: "OpenRouter", model: "openai/gpt-4.1" },
  { id: "groq", name: "Groq", model: "llama-3.3-70b-versatile" },
  { id: "xai", name: "xAI", model: "grok-4" },
  { id: "deepseek", name: "DeepSeek", model: "deepseek-chat" },
] as const;
export const councilInput = z.object({
  label: z.string().trim().min(1).max(80),
  provider: z.enum(["openai", "anthropic", "google", "openrouter", "groq", "xai", "deepseek"]),
  model: z.string().trim().min(1).max(150).regex(/^[a-zA-Z0-9_./:@-]+$/),
  apiKey: z.string().trim().min(1).max(4096),
});
export type CouncilInput = z.infer<typeof councilInput>;
export const isCouncilAdmin = (roles: Array<{ role: string }>) => roles.some((r) => r.role === "admin");