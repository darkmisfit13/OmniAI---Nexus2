import { z } from "zod";

export const notificationEvents = ["generation", "security", "compilation"] as const;
export type NotificationEvent = (typeof notificationEvents)[number];
export const notificationSettingsSchema = z.object({
  webhook_url: z.string().trim().max(2048),
  generation_enabled: z.boolean(), security_enabled: z.boolean(), compilation_enabled: z.boolean(),
});
export function validateWebhook(value: string) {
  let url: URL;
  try { url = new URL(value); } catch { throw new Error("Enter a valid HTTPS webhook URL."); }
  const host = url.hostname.toLowerCase();
  // Fixed trusted webhook services prevent private-network requests and DNS rebinding.
  const allowed = host === "webhook.site" || host === "hooks.zapier.com" || /^hook(?:s)?\.[a-z0-9-]+\.make\.com$/.test(host) || /^hook\.[a-z0-9-]+\.integromat\.com$/.test(host) || /^[a-z0-9-]+\.m\.pipedream\.net$/.test(host);
  if (url.protocol !== "https:" || url.username || url.password || (url.port && url.port !== "443") || !allowed) throw new Error("Use an HTTPS Make.com, Zapier, Pipedream or Webhook.site endpoint.");
  url.hash = "";
  return url.href;
}
export function eventEnabled(settings: z.infer<typeof notificationSettingsSchema>, event: NotificationEvent) {
  return settings[`${event}_enabled`];
}
export function notificationPayload(actorId: string, taskType: string, credits: number | null, timestamp = new Date().toISOString()) {
  return { timestamp, actor_id: actorId, task_type: taskType, credits_deducted: credits };
}