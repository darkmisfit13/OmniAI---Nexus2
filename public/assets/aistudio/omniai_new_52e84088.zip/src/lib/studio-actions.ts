import { useEffect, useRef } from "react";

/** A control a studio exposes so the AI companion can operate it directly. */
export type StudioAction = {
  name: string;
  description: string;
  /** Plain description of the JSON args, e.g. `{ "prompt": string }`. */
  args?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- model-supplied JSON, validated inside each handler
  run: (args: any) => unknown | Promise<unknown>;
};

const registry = new Map<string, StudioAction>();

export const listStudioActions = () => [...registry.values()];
export const getStudioAction = (name: string) => registry.get(name);

export type ActionCall = { name: string; args?: Record<string, unknown> };

/** Parses the companion model's reply: `{ "reply": string, "actions": [...] }`, tolerating code fences or plain text. */
export function parseCompanionReply(raw: string): { reply: string; actions: ActionCall[] } {
  const m = raw.match(/\{[\s\S]*\}/);
  if (m) {
    try {
      const j = JSON.parse(m[0]) as { reply?: unknown; actions?: unknown };
      const actions = Array.isArray(j.actions) ? j.actions.filter((a): a is ActionCall => !!a && typeof (a as ActionCall).name === "string") : [];
      return { reply: typeof j.reply === "string" ? j.reply : "", actions };
    } catch { /* fall through */ }
  }
  return { reply: raw, actions: [] };
}

/** Registers a studio's actions while mounted. Handlers always see the latest render's state. */
export function useStudioActions(actions: StudioAction[]) {
  const latest = useRef(actions);
  latest.current = actions;
  const key = actions.map((a) => a.name).join("|");
  useEffect(() => {
    const names = latest.current.map((a) => a.name);
    for (const a of latest.current) registry.set(a.name, { ...a, run: (args) => latest.current.find((x) => x.name === a.name)!.run(args) });
    return () => { for (const n of names) registry.delete(n); };
  }, [key]);
}
