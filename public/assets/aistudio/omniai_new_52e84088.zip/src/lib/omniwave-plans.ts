export const OMNIWAVE_PLANS = [
  { id: "explorer", name: "OmniWave Explorer", monthlyUsd: 0, monthlyCredits: 0, pro: false },
  { id: "creators", name: "OmniWave Creators", monthlyUsd: 9, monthlyCredits: 600, pro: true },
  { id: "masters", name: "OmniWave Masters", monthlyUsd: 19, monthlyCredits: 1500, pro: true },
] as const;
export const OMNIWAVE_BOOSTERS = [
  { id: "track-analysis", name: "OmniWave Track Analysis Pack", usd: 5, credits: 500 },
  { id: "studio-single", name: "OmniWave Studio Single Pack", usd: 12, credits: 1200 },
  { id: "directors-album", name: "OmniWave Director's Album Pack", usd: 24, credits: 2400 },
] as const;
export type OmniWaveSubscription = { plan: string; status: string; period_start: string; period_end: string };
export function omniwavePlan(subscription: OmniWaveSubscription | null | undefined, now = Date.now()) {
  const active = subscription?.status === "active" && Date.parse(subscription.period_start) <= now && Date.parse(subscription.period_end) > now;
  return (active && OMNIWAVE_PLANS.find(p => p.id === subscription?.plan)) || OMNIWAVE_PLANS[0];
}
export function requireMusicAccess(pro: boolean, operation: string, preview = false) {
  if (preview && operation !== "music-song") throw new Error("Masters preview requires a separate full-song authorization.");
  if (!pro && operation !== "music-teaser" && !preview) throw new Error("Upgrade to OmniWave Creators or OmniWave Masters for Lyria Pro full songs.");
}