import { eventEnabled, notificationPayload, validateWebhook, type NotificationEvent } from "./notifications";

export async function sendWebhook(url: string, payload: unknown) {
  const response = await fetch(validateWebhook(url), { method: "POST", redirect: "manual", signal: AbortSignal.timeout(8000), headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  const status = response.status;
  await response.body?.cancel();
  return { status, ok: status >= 200 && status < 300 };
}

export async function dispatchNotification(userId: string, event: NotificationEvent, eventKey: string, taskType: string, credits: number | null = null) {
  // Trusted server callers only. No user-supplied content, credentials or media URLs in payloads.
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  try {
    const { data: settings } = await supabaseAdmin.from("notification_settings").select("*").eq("user_id", userId).maybeSingle();
    if (!settings?.verified_at || !settings.webhook_url || !eventEnabled(settings, event)) return;
    const payload = notificationPayload(userId, taskType, credits);
    const claim = await supabaseAdmin.from("notification_deliveries").insert({ user_id: userId, event_key: eventKey, payload }).select("id").single();
    if (claim.error) return; // Unique event key prevents repeated polling from resending.
    let status: number | null = null;
    let ok = false;
    try { const result = await sendWebhook(settings.webhook_url, payload); status = result.status; ok = result.ok; } catch { /* record failure without leaking the endpoint */ }
    await supabaseAdmin.from("notification_deliveries").update({ status: ok ? "delivered" : "failed", http_status: status }).eq("id", claim.data.id).eq("user_id", userId);
  } catch { /* Notification failure never fails the user's studio task. */ }
}