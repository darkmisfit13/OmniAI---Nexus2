import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { CONNECTORS, type Metric } from "./connectors";

type Creds = { token: string; shop?: string; channel?: string };

async function j(url: string, init: RequestInit = {}) {
  const res = await fetch(url, init);
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(res.status === 401 || res.status === 403 ? "The key was rejected by the provider." : `Provider error ${res.status}`);
  return body as any;
}
const bearer = (t: string) => ({ headers: { Authorization: `Bearer ${t}`, "User-Agent": "OmniAI" } });

async function probe(provider: string, c: Creds): Promise<{ label: string; metrics: Metric[] }> {
  switch (provider) {
    case "github": {
      const u = await j("https://api.github.com/user", bearer(c.token));
      return { label: u.login, metrics: [{ label: "Repos", value: String((u.public_repos ?? 0) + (u.total_private_repos ?? 0)) }, { label: "Followers", value: String(u.followers) }, { label: "Following", value: String(u.following) }] };
    }
    case "stripe": {
      const b = await j("https://api.stripe.com/v1/balance", bearer(c.token));
      const ch = await j("https://api.stripe.com/v1/charges?limit=100", bearer(c.token)).catch(() => ({ data: [] }));
      const a = b.available?.[0];
      return { label: b.livemode ? "Live mode" : "Test mode", metrics: [{ label: "Available", value: a ? `${(a.amount / 100).toFixed(2)} ${a.currency.toUpperCase()}` : "0" }, { label: "Pending", value: b.pending?.[0] ? (b.pending[0].amount / 100).toFixed(2) : "0" }, { label: "Recent charges", value: String(ch.data?.length ?? 0) }] };
    }
    case "notion": {
      const h = { headers: { Authorization: `Bearer ${c.token}`, "Notion-Version": "2022-06-28", "Content-Type": "application/json" } };
      const me = await j("https://api.notion.com/v1/users/me", h);
      const s = await j("https://api.notion.com/v1/search", { ...h, method: "POST", body: JSON.stringify({ page_size: 100 }) });
      return { label: me.bot?.workspace_name ?? me.name ?? "Notion", metrics: [{ label: "Shared items", value: String(s.results?.length ?? 0) + (s.has_more ? "+" : "") }, { label: "Type", value: me.type }] };
    }
    case "slack": {
      const a = await j("https://slack.com/api/auth.test", bearer(c.token));
      if (!a.ok) throw new Error(`Slack: ${a.error}`);
      const ch = await j("https://slack.com/api/conversations.list?limit=200", bearer(c.token));
      return { label: a.team, metrics: [{ label: "Channels", value: String(ch.channels?.length ?? 0) }, { label: "Bot user", value: a.user }] };
    }
    case "hubspot": {
      const d = await j("https://api.hubapi.com/account-info/v3/details", bearer(c.token));
      const ct = await j("https://api.hubapi.com/crm/v3/objects/contacts/search", { ...bearer(c.token), method: "POST", headers: { Authorization: `Bearer ${c.token}`, "Content-Type": "application/json" }, body: JSON.stringify({ limit: 1 }) }).catch(() => ({ total: "—" }));
      return { label: `Portal ${d.portalId}`, metrics: [{ label: "Contacts", value: String(ct.total) }, { label: "Time zone", value: d.timeZone ?? "—" }] };
    }
    case "shopify": {
      const shop = c.shop?.replace(/^https?:\/\//, "").replace(/\/.*$/, "");
      if (!shop?.endsWith(".myshopify.com")) throw new Error("Store domain must end in .myshopify.com");
      const h = { headers: { "X-Shopify-Access-Token": c.token } };
      const s = await j(`https://${shop}/admin/api/2024-10/shop.json`, h);
      const p = await j(`https://${shop}/admin/api/2024-10/products/count.json`, h).catch(() => ({ count: "—" }));
      const o = await j(`https://${shop}/admin/api/2024-10/orders/count.json?status=any`, h).catch(() => ({ count: "—" }));
      return { label: s.shop?.name, metrics: [{ label: "Products", value: String(p.count) }, { label: "Orders", value: String(o.count) }, { label: "Currency", value: s.shop?.currency }] };
    }
    case "youtube": {
      const r = await j(`https://www.googleapis.com/youtube/v3/channels?part=statistics,snippet&id=${encodeURIComponent(c.channel ?? "")}&key=${encodeURIComponent(c.token)}`);
      const ch = r.items?.[0];
      if (!ch) throw new Error("Channel not found.");
      const st = ch.statistics;
      return { label: ch.snippet.title, metrics: [{ label: "Subscribers", value: Number(st.subscriberCount).toLocaleString() }, { label: "Views", value: Number(st.viewCount).toLocaleString() }, { label: "Videos", value: st.videoCount }] };
    }
    case "airtable": {
      const w = await j("https://api.airtable.com/v0/meta/whoami", bearer(c.token));
      const b = await j("https://api.airtable.com/v0/meta/bases", bearer(c.token)).catch(() => ({ bases: [] }));
      return { label: w.email ?? w.id, metrics: [{ label: "Bases", value: String(b.bases?.length ?? 0) }, { label: "Scopes", value: String(w.scopes?.length ?? "—") }] };
    }
    case "elevenlabs": {
      const s = await j("https://api.elevenlabs.io/v1/user/subscription", { headers: { "xi-api-key": c.token } });
      return { label: `${s.tier} plan`, metrics: [{ label: "Characters used", value: Number(s.character_count).toLocaleString() }, { label: "Limit", value: Number(s.character_limit).toLocaleString() }, { label: "Status", value: s.status }] };
    }
  }
  throw new Error("Unknown connector.");
}

async function admin() {
  return (await import("@/integrations/supabase/client.server")).supabaseAdmin;
}

export const listConnections = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { data, error } = await context.supabase.from("user_connections").select("id, provider, account_label, metrics, last_checked").eq("user_id", context.userId);
  if (error) throw error;
  return data.map((r) => ({ ...r, metrics: r.metrics as Metric[] }));
});

export const saveConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ provider: z.string(), credentials: z.record(z.string(), z.string().trim().min(1).max(500)) }).parse(i))
  .handler(async ({ context, data }) => {
    const def = CONNECTORS.find((d) => d.id === data.provider);
    if (!def) throw new Error("Unknown connector.");
    for (const f of def.fields) if (!data.credentials[f.key]) throw new Error(`${f.label} is required.`);
    const r = await probe(def.id, data.credentials as Creds);
    const db = await admin();
    const { error } = await db.from("user_connections").upsert({ user_id: context.userId, provider: def.id, credentials: data.credentials, account_label: r.label ?? def.name, metrics: r.metrics, last_checked: new Date().toISOString() }, { onConflict: "user_id,provider" });
    if (error) throw new Error("Could not save the connection.");
    return r;
  });

export const refreshConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ provider: z.string() }).parse(i))
  .handler(async ({ context, data }) => {
    const db = await admin();
    const row = await db.from("user_connections").select("credentials").eq("user_id", context.userId).eq("provider", data.provider).single();
    if (row.error) throw new Error("Connection not found.");
    const r = await probe(data.provider, row.data.credentials as Creds);
    await db.from("user_connections").update({ account_label: r.label, metrics: r.metrics, last_checked: new Date().toISOString() }).eq("user_id", context.userId).eq("provider", data.provider);
    return r;
  });
