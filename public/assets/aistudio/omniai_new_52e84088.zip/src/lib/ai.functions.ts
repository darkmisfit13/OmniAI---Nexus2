import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const CHAT_MODELS = [
  { id: "openai/gpt-6-astra", label: "GPT-6 Astra" },
  { id: "anthropic/claude-sonnet-5", label: "Claude Sonnet 5" },
  { id: "google/gemini-3.1-pro-preview", label: "Gemini 3.1 Pro" },
  { id: "google/gemini-3.5-flash", label: "Gemini 3.5 Flash" },
];

type Msg = { role: "user" | "assistant"; content: string };

export const askModel = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { model: string; messages: Msg[]; system?: string }) => {
    if (!CHAT_MODELS.some((m) => m.id === d.model) && d.model !== "openai/gpt-6-astra") throw new Error("Unknown model");
    return { ...d, messages: d.messages.slice(-20).map((m) => ({ role: m.role, content: String(m.content).slice(0, 20000) })) };
  })
  .handler(async ({ data }) => {
    const { complete } = await import("./ai.server");
    const t = Date.now();
    const text = await complete(data.model, data.messages, data.system);
    return { text, ms: Date.now() - t };
  });

export const mergeAnswers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { question: string; answers: { model: string; text: string }[] }) => d)
  .handler(async ({ data }) => {
    const { complete } = await import("./ai.server");
    const prompt = `Question: ${data.question}\n\n${data.answers.map((a) => `### ${a.model}\n${a.text}`).join("\n\n")}\n\nWrite one best, merged answer combining the strongest points. Do not mention the models.`;
    const text = await complete("openai/gpt-6-astra", [{ role: "user", content: prompt }], "You synthesize multiple AI answers into one excellent answer. Use markdown.");
    return { text };
  });

export const generate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { studio: string; prompt: string; approvalId?: string; refs?: { url: string; mediaType: string; filename?: string }[] }) => {
    const refs = (d.refs ?? []).slice(0, 8);
    if (refs.some((r) => !/^data:(image|video)\//.test(r.url))) throw new Error("Only image and video uploads are supported.");
    return { studio: d.studio, prompt: d.prompt.slice(0, 4000), refs, approvalId: d.approvalId };
  })
  .handler(async ({ data, context }) => {
    const ai = await import("./ai.server");
    const { persistOutput } = await import("./media.server");
    const save = (result: { kind: "image" | "audio" | "text"; text?: string; url?: string }) => persistOutput(context.supabase, context.userId, data.studio, data.prompt, result);
    if (data.studio === "music") throw new Error("Open OmniWave to review music pricing and Confirm & Authorize Stream; no generation has started.");
    if (data.studio === "voice") return save({ kind: "audio" as const, url: await ai.generateSpeech(data.prompt) });
    const visual = ["image", "design", "3d", "style", "vector"].includes(data.studio);
    const images = data.refs.filter((r) => r.mediaType.startsWith("image/"));
    if (visual) {
      const { chargedCompute } = await import("./studio-credit.server");
      const style = data.studio === "design" ? "Polished graphic design layout: " : data.studio === "3d" ? "High-quality 3D render: " : data.studio === "style" ? "Photorealistic outfit and appearance edit, preserve the person, pose and background exactly: " : data.studio === "vector" ? "Clean flat vector-style brand artwork, bold geometric shapes, solid colors: " : data.studio === "image" ? "" : "Cinematic keyframe still: ";
      return chargedCompute(data.approvalId, context.userId, { operation: "image", target: data.studio, prompt: data.prompt, refUrls: data.refs.map((r) => r.url) }, async () => save({ kind: "image" as const, url: images.length ? await ai.editImage(style + data.prompt, images) : await ai.generateImage(style + data.prompt) }));
    }
    const system = `You are OmniAI's ${data.studio} studio. Produce the finished deliverable directly, high quality, using markdown. For code, include complete runnable code blocks. For music, write full song lyrics with structure, style and chord suggestions. For automations, give a step-by-step workflow. For voice, write the polished script with delivery notes.`;
    if (data.refs.length) return save({ kind: "text" as const, text: await ai.complete(ai.MEDIA_MODEL, [{ role: "user", content: [{ type: "text", text: data.prompt }, ...ai.mediaParts(data.refs)] }], system) });
    return save({ kind: "text" as const, text: await ai.complete("openai/gpt-6-astra", [{ role: "user", content: data.prompt }], system) });
  });

export const startVideoJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { prompt: string; vertical?: boolean; studio?: string; approvalId?: string }) => ({ prompt: d.prompt.slice(0, 3000), vertical: !!d.vertical, studio: d.studio ?? "video-gen", approvalId: d.approvalId }))
  .handler(async ({ data, context }) => {
    const { startVideo } = await import("./ai.server");
    const { chargedCompute } = await import("./studio-credit.server");
    return chargedCompute(data.approvalId, context.userId, { operation: "video", target: data.studio, prompt: data.prompt, seconds: 8 }, async () => {
    const id = await startVideo(data.prompt, data.vertical ? "9:16" : "16:9");
    const saved = await context.supabase.from("studio_projects").insert({ user_id: context.userId, studio: data.studio, title: data.prompt, kind: "pending-video", job_id: id }).select().single();
    if (saved.error) throw saved.error;
    return { id };
    });
  });

export const checkVideoJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => {
    if (!/^[\w-]+$/.test(d.id)) throw new Error("Bad id");
    return d;
  })
  .handler(async ({ data, context }) => {
    const project = await context.supabase.from("studio_projects").select("*").eq("user_id", context.userId).eq("job_id", data.id).single();
    if (project.error) throw new Error("Video job not found.");
    if (project.data.asset_path) {
      const signed = await context.supabase.storage.from("studio-assets").createSignedUrl(project.data.asset_path, 3600);
      if (signed.error) throw signed.error;
      const { reconcilePipelineVideo } = await import("./pipeline-escrow.server");
      await reconcilePipelineVideo(context.supabase, context.userId, project.data.id, true);
      return { status: "completed", progress: 100, error: null, url: signed.data.signedUrl };
    }
    const { checkVideo } = await import("./ai.server");
    const result = await checkVideo(data.id);
    if (result.url) { const { persistOutput } = await import("./media.server"); const saved = await persistOutput(context.supabase, context.userId, project.data.studio, project.data.title, { kind: "video", url: result.url }, project.data.id); const { reconcilePipelineVideo } = await import("./pipeline-escrow.server"); await reconcilePipelineVideo(context.supabase, context.userId, project.data.id, true); return { ...result, url: saved.url ?? null }; }
    if (result.status === "failed") { const { reconcilePipelineVideo } = await import("./pipeline-escrow.server"); await reconcilePipelineVideo(context.supabase, context.userId, project.data.id, false); }
    return result;
  });

export const enhancePrompt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { prompt: string; studio?: string }) => {
    if (!d.prompt?.trim()) throw new Error("Write a prompt first.");
    return { prompt: d.prompt.slice(0, 4000), studio: (d.studio ?? "chat").slice(0, 40) };
  })
  .handler(async ({ data }) => {
    const { complete } = await import("./ai.server");
    const text = await complete("openai/gpt-6-astra", [{ role: "user", content: data.prompt }], `Rewrite the user's prompt for OmniAI's ${data.studio} studio so it is vivid, specific and production-ready (subject, style, mood, composition, technical details as relevant). Keep the user's intent and language. Return only the improved prompt, no preamble or quotes.`);
    return { prompt: text.trim() };
  });

export const analyzeSite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { url: string }) => {
    let u: URL;
    try { u = new URL(d.url.trim()); } catch { throw new Error("Enter a full URL like https://example.com"); }
    if (!/^https?:$/.test(u.protocol)) throw new Error("Only http/https URLs.");
    return { url: u.toString() };
  })
  .handler(async ({ data }) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    let pageText = "";
    let fetchNote = "";
    try {
      const res = await fetch(data.url, { signal: controller.signal, redirect: "follow", headers: { "User-Agent": "OmniAI-Analyzer/1.0" } });
      const html = (await res.text()).slice(0, 200000);
      pageText = html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").slice(0, 12000);
      fetchNote = `HTTP ${res.status}`;
    } catch { fetchNote = "The site could not be fetched directly (it may block crawlers) — auditing from the URL and any available signals."; }
    finally { clearTimeout(timer); }
    const { complete } = await import("./ai.server");
    const text = await complete("openai/gpt-6-astra", [{ role: "user", content: `Audit this site: ${data.url}\nFetch status: ${fetchNote}\nVisible page text (may be empty):\n${pageText || "(none)"}` }], "You are OmniAI's website auditor. Produce a structured audit in markdown: ## Overall score (0-100), ## What needs fixing (bulleted, specific), ## What to update (content/SEO/structure/speed/accessibility), ## What's working. Be concrete and honest; if the page couldn't be fetched, say what could not be verified.");
    return { text, fetchNote };
  });

export const buildSite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { kind: string; prompt: string; html?: string }) => {
    if (!d.prompt?.trim()) throw new Error("Describe what to build.");
    return { kind: ["app-builder", "website", "code"].includes(d.kind) ? d.kind : "website", prompt: d.prompt.slice(0, 6000), html: (d.html ?? "").slice(0, 200000) };
  })
  .handler(async ({ data }) => {
    const { complete } = await import("./ai.server");
    const what = data.kind === "app-builder" ? "interactive web application with working state and logic" : data.kind === "code" ? "runnable interactive code demo" : "polished, responsive multi-section website";
    const system = `You are OmniAI's builder. Output ONE complete self-contained HTML document for a ${what}. Inline all CSS and JavaScript (no build step, no external JS except optional https CDN fonts). Make it beautiful, accessible and fully functional. Return ONLY the HTML starting with <!DOCTYPE html>, no markdown fences or commentary.`;
    const msg = data.html ? `Current HTML:\n${data.html}\n\nApply this change and return the full updated document:\n${data.prompt}` : data.prompt;
    const raw = await complete("openai/gpt-6-astra", [{ role: "user", content: msg }], system);
    const start = raw.search(/<!doctype html|<html/i);
    const end = raw.toLowerCase().lastIndexOf("</html>");
    if (start < 0) throw new Error("The builder didn't return a page. Try rephrasing.");
    return { html: raw.slice(start, end > start ? end + 7 : undefined) };
  });
