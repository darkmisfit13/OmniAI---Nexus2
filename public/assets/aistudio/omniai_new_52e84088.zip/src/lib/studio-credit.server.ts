import type { CreditRequest } from "./studio-credit";
import { canonicalCreditRequest } from "./studio-credit";
export async function creditHash(request: CreditRequest) {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonicalCreditRequest(request)));
  return Array.from(new Uint8Array(bytes), (n) => n.toString(16).padStart(2, "0")).join("");
}
/** Single-use release. No provider request may precede this atomic check. */
export async function releaseCredit(approvalId: string | undefined, userId: string, request: CreditRequest) {
  if (!approvalId) throw new Error("Confirm & Deduct Credits before generation.");
  const hash = await creditHash(request);
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const result = await supabaseAdmin.rpc("consume_studio_credit_charge", { p_id: approvalId, p_user: userId, p_operation: request.operation, p_hash: hash });
  if (result.error) throw new Error("Credit approval is missing, expired, already used or does not match this task.");
}
export async function refundCredit(approvalId: string, userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const r = await supabaseAdmin.rpc("refund_studio_credit_charge", { p_id: approvalId, p_user: userId });
  if (r.error) throw new Error("Credit refund could not be recorded.");
}
export async function chargedCompute<T>(approvalId: string | undefined, userId: string, request: CreditRequest, work: () => Promise<T>): Promise<T> {
  await releaseCredit(approvalId, userId, request);
  try { return await work(); }
  catch (error) { if (approvalId) await refundCredit(approvalId, userId); throw error; }
}
