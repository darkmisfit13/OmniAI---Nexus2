export type BudgetConfig = { seconds: number; variants: number; highDetail: boolean; stopped: boolean; stopPercent: number };
export const DEFAULT_BUDGET: BudgetConfig = { seconds: 30, variants: 4, highDetail: false, stopped: false, stopPercent: 50 };
export function calculateBudget(config: BudgetConfig) {
  const { seconds, variants, stopPercent } = config;
  if (!Number.isInteger(seconds) || seconds < 15 || seconds > 300) throw new Error("Video length must be 15–300 seconds.");
  if (!Number.isInteger(variants) || variants < 4 || variants > 32) throw new Error("Reference variants must be 4–32.");
  if (!Number.isFinite(stopPercent) || stopPercent < 0 || stopPercent > 100) throw new Error("Stop point must be 0–100%.");
  if (typeof config.highDetail !== "boolean" || typeof config.stopped !== "boolean") throw new Error("Invalid budget options.");
  // Integer micro-dollars preserve half-cent image pricing and fractional stop percentages.
  const audioMicros = 50_000;
  const imagesMicros = variants * (config.highDetail ? 45_000 : 30_000);
  const fullRenderMicros = seconds * 80_000;
  const renderMicros = config.stopped ? Math.round(fullRenderMicros * stopPercent / 100) : fullRenderMicros;
  const resetMicros = config.stopped ? 250_000 : 0;
  const totalMicros = audioMicros + imagesMicros + renderMicros + resetMicros;
  return { audioMicros, imagesMicros, fullRenderMicros, renderMicros, resetMicros, totalMicros, totalUsd: totalMicros / 1_000_000, currency: "USD" as const, credits: null, pricingVersion: "omnibeat-v1" };
}
export const usd = (micros: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2, maximumFractionDigits: 3 }).format(micros / 1_000_000);