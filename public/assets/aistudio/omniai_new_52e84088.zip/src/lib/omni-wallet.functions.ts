import { createServerFn } from '@tanstack/react-start';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { omniPlan } from './omni-plans';
export const getOmniWallet = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const [wallet, subscription, reservations] = await Promise.all([
    context.supabase.from('studio_credit_wallets').select('balance,monthly_balance,booster_balance').eq('user_id', context.userId).maybeSingle(),
    context.supabase.from('omni_subscriptions').select('plan,status,period_start,period_end').eq('user_id', context.userId).maybeSingle(),
    context.supabase.from('omni_pipeline_reservations').select('reserved,spent,pending,released').eq('user_id', context.userId).neq('status', 'settled'),
  ]);
  if (wallet.error || subscription.error || reservations.error) throw new Error('Omni Global Wallet unavailable.');
  return { balance: wallet.data?.balance ?? 0, monthly: wallet.data?.monthly_balance ?? 0, boosters: wallet.data?.booster_balance ?? 0, reserved: (reservations.data ?? []).reduce((n, r) => n + r.reserved - r.spent - r.released, 0), plan: omniPlan(subscription.data) };
});
