export type MemoryRecord = { content: string; created_at: string };

export function memoryContext(records: MemoryRecord[]) {
  return records.map((r) => `[User said on ${r.created_at}]: ${r.content}`).join("\n");
}

export function userText(message: { parts: { type: string; text?: string }[] }) {
  return message.parts.filter((p) => p.type === "text").map((p) => p.text ?? "").join("\n");
}