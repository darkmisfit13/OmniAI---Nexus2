const BASE = "https://ai.gateway.lovable.dev/v1";

function key() {
  const k = process.env["LOVABLE_API_KEY"];
  if (!k) throw new Error("AI is not configured (missing key).");
  return k;
}

async function fail(res: Response): Promise<never> {
  let msg = `AI request failed (${res.status})`;
  try {
    const j = (await res.json()) as { message?: string; error?: { message?: string } };
    msg = j.message ?? j.error?.message ?? msg;
  } catch {}
  if (res.status === 402) msg = "Out of AI credits — top up in Settings → Plans & credits.";
  if (res.status === 429) msg = "Rate limited — please wait a moment and try again.";
  throw new Error(msg);
}

async function readSSE(res: Response, onData: (json: any) => void) {
  const reader = res.body!.getReader();
  const dec = new TextDecoder();
  let buf = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line.startsWith("data:")) continue;
      const d = line.slice(5).trim();
      if (!d || d === "[DONE]") continue;
      try { onData(JSON.parse(d)); } catch {}
    }
  }
}

export type ChatMsg = { role: "user" | "assistant"; content: string | unknown[] };
export type MediaRef = { url: string; mediaType: string; filename?: string };

/** Streams from the gateway server-side and returns the final text. */
export async function complete(model: string, messages: ChatMsg[], system?: string): Promise<string> {
  if (model.startsWith("anthropic/")) {
    const res = await fetch(`${BASE}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${key()}`, "Content-Type": "application/json", "X-Lovable-AIG-SDK": "fetch" },
      body: JSON.stringify({ model, max_tokens: 4000, stream: true, ...(system ? { system } : {}), messages }),
    });
    if (!res.ok) await fail(res);
    let out = "";
    let refused = false;
    await readSSE(res, (j) => {
      if (j.type === "content_block_delta" && j.delta?.type === "text_delta") out += j.delta.text;
      if (j.type === "message_delta" && j.delta?.stop_reason === "refusal") refused = true;
    });
    if (refused && !out) throw new Error("The model declined this request.");
    return out;
  }
  const body: Record<string, unknown> = {
    model, stream: true,
    messages: [...(system ? [{ role: "system", content: system }] : []), ...messages],
  };
  if (model === "openai/gpt-6-astra") body["reasoning_effort"] = "low";
  const res = await fetch(`${BASE}/chat/completions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${key()}`, "Content-Type": "application/json", "X-Lovable-AIG-SDK": "fetch" },
    body: JSON.stringify(body),
  });
  if (!res.ok) await fail(res);
  let out = "";
  await readSSE(res, (j) => { out += j.choices?.[0]?.delta?.content ?? ""; });
  return out;
}

export async function generateImage(prompt: string): Promise<string> {
  const res = await fetch(`${BASE}/images/generations`, {
    method: "POST",
    headers: { Authorization: `Bearer ${key()}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: "openai/gpt-image-2.5-sunburst", prompt }),
  });
  if (!res.ok) await fail(res);
  const j = (await res.json()) as { data?: { b64_json?: string; url?: string }[] };
  const d = j.data?.[0];
  if (d?.b64_json) return `data:image/png;base64,${d.b64_json}`;
  if (d?.url) return d.url;
  throw new Error("No image returned.");
}

function toB64(buf: ArrayBuffer) {
  const bytes = new Uint8Array(buf);
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

export async function generateSpeech(text: string, voice = "Kore"): Promise<string> {
  const res = await fetch(`${BASE}/audio/speech`, {
    method: "POST",
    headers: { Authorization: `Bearer ${key()}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "google/gemini-3.1-flash-tts-preview",
      contents: [{ role: "user", parts: [{ text }] }],
      generationConfig: { responseModalities: ["AUDIO"], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } } },
    }),
  });
  if (!res.ok) await fail(res);
  const type = res.headers.get("content-type") ?? "audio/wav";
  return `data:${type.split(";")[0]};base64,${toB64(await res.arrayBuffer())}`;
}

export async function startVideo(prompt: string, aspect: "16:9" | "9:16" = "16:9"): Promise<string> {
  const res = await fetch(`${BASE}/videos`, {
    method: "POST",
    headers: { Authorization: `Bearer ${key()}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "google/gemini-omni-1.1-flash",
      input: `${prompt}. Cinematic, in a single continuous shot. Consider micro-detail, expression and timing.`,
      response_format: { type: "video", resolution: "720p", duration: "8s", aspect_ratio: aspect },
    }),
  });
  if (!res.ok) await fail(res);
  return ((await res.json()) as { id: string }).id;
}

export async function checkVideo(id: string): Promise<{ status: string; progress: number; url: string | null; error: string | null }> {
  const res = await fetch(`${BASE}/videos/${encodeURIComponent(id)}`, { headers: { Authorization: `Bearer ${key()}` } });
  if (!res.ok) await fail(res);
  const j = (await res.json()) as { status: string; progress?: number; error?: { message?: string } };
  if (j.status === "failed") return { status: "failed", progress: 0, url: null, error: j.error?.message ?? "Video generation failed." };
  if (j.status !== "completed") return { status: j.status, progress: j.progress ?? 0, url: null, error: null };
  const c = await fetch(`${BASE}/videos/${encodeURIComponent(id)}/content`, { headers: { Authorization: `Bearer ${key()}` } });
  if (!c.ok) await fail(c);
  return { status: "completed", progress: 100, error: null, url: `data:video/mp4;base64,${toB64(await c.arrayBuffer())}` };
}

function dataUrlToBlob(url: string): Blob {
  const m = /^data:([^;,]+);base64,(.*)$/.exec(url);
  if (!m?.[1] || m[2] === undefined) throw new Error("Attachment must be an uploaded file.");
  const bin = atob(m[2]); const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: m[1] });
}

/** Generates a new image guided by uploaded reference images. */
export async function editImage(prompt: string, refs: MediaRef[]): Promise<string> {
  const form = new FormData();
  form.append("model", "openai/gpt-image-2.5-sunburst");
  form.append("prompt", prompt);
  refs.forEach((r, i) => form.append("image[]", dataUrlToBlob(r.url), r.filename ?? `reference-${i}.png`));
  const res = await fetch(`${BASE}/images/edits`, { method: "POST", headers: { Authorization: `Bearer ${key()}` }, body: form });
  if (!res.ok) await fail(res);
  const j = (await res.json()) as { data?: { b64_json?: string; url?: string }[] };
  const d = j.data?.[0];
  if (d?.b64_json) return `data:image/png;base64,${d.b64_json}`;
  if (d?.url) return d.url;
  throw new Error("No image returned.");
}

/** Sends text plus uploaded images/videos to a multimodal model. */
export function mediaParts(refs: MediaRef[]) {
  return refs.map((r) => r.mediaType.startsWith("video/") ? { type: "video_url", video_url: { url: r.url } } : { type: "image_url", image_url: { url: r.url } });
}
export const MEDIA_MODEL = "google/gemini-3-flash-preview";
