export type ConnectorField = { key: string; label: string; secret?: boolean; placeholder?: string };
export type ConnectorDef = { id: string; name: string; desc: string; help: string; fields: ConnectorField[] };

export const CONNECTORS: ConnectorDef[] = [
  { id: "github", name: "GitHub", desc: "Repos, followers, activity", help: "GitHub → Settings → Developer settings → Personal access tokens", fields: [{ key: "token", label: "Personal access token", secret: true, placeholder: "ghp_…" }] },
  { id: "stripe", name: "Stripe", desc: "Balance & recent charges", help: "Stripe Dashboard → Developers → API keys (restricted read key works)", fields: [{ key: "token", label: "Secret or restricted key", secret: true, placeholder: "sk_live_… / rk_…" }] },
  { id: "notion", name: "Notion", desc: "Workspace pages & databases", help: "notion.so/my-integrations → New integration → Internal secret", fields: [{ key: "token", label: "Integration secret", secret: true, placeholder: "ntn_…" }] },
  { id: "slack", name: "Slack", desc: "Workspace, channels", help: "api.slack.com/apps → OAuth & Permissions → Bot token", fields: [{ key: "token", label: "Bot token", secret: true, placeholder: "xoxb-…" }] },
  { id: "hubspot", name: "HubSpot", desc: "Portal & contacts", help: "HubSpot → Settings → Integrations → Private apps", fields: [{ key: "token", label: "Private app token", secret: true, placeholder: "pat-…" }] },
  { id: "shopify", name: "Shopify", desc: "Store, products & orders", help: "Shopify admin → Apps → Develop apps → Admin API token", fields: [{ key: "shop", label: "Store domain", placeholder: "mystore.myshopify.com" }, { key: "token", label: "Admin API token", secret: true, placeholder: "shpat_…" }] },
  { id: "youtube", name: "YouTube", desc: "Channel stats", help: "Google Cloud Console → Credentials → API key (YouTube Data API v3)", fields: [{ key: "token", label: "API key", secret: true }, { key: "channel", label: "Channel ID", placeholder: "UC…" }] },
  { id: "airtable", name: "Airtable", desc: "Bases & account", help: "airtable.com/create/tokens → Personal access token", fields: [{ key: "token", label: "Personal access token", secret: true, placeholder: "pat…" }] },
  { id: "elevenlabs", name: "ElevenLabs", desc: "Voice credits & plan", help: "elevenlabs.io → Profile → API keys", fields: [{ key: "token", label: "API key", secret: true }] },
];

export type Metric = { label: string; value: string };
