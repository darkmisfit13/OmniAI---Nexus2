import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { notificationSettingsSchema, notificationPayload, validateWebhook } from "./notifications";

export const getNotifications = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const settings = await context.supabase.from("notification_settings").select("*").eq("user_id", context.userId).maybeSingle();
  const logs = await context.supabase.from("notification_deliveries").select("id,payload,status,http_status,created_at").eq("user_id", context.userId).order("created_at", { ascending: false }).limit(40);
  if (settings.error || logs.error) throw new Error("Notification settings could not be loaded.");
  return { settings: settings.data, logs: logs.data ?? [] };
});
export const saveNotifications = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => notificationSettingsSchema.parse(input)).handler(async ({ data, context }) => {
  const url = data.webhook_url ? validateWebhook(data.webhook_url) : "";
  const old = await context.supabase.from("notification_settings").select("webhook_url,verified_at").eq("user_id", context.userId).maybeSingle();
  if (old.error) throw new Error("Settings could not be checked.");
  const saved = await context.supabase.from("notification_settings").upsert({ ...data, webhook_url: url, user_id: context.userId, verified_at: old.data?.webhook_url === url ? old.data.verified_at : null, updated_at: new Date().toISOString() });
  if (saved.error) throw new Error("Notification settings could not be saved.");
  return { saved: true };
});
export const testNotificationWebhook = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({ webhook_url: z.string().max(2048) }).parse(input)).handler(async ({ data, context }) => {
  const url = validateWebhook(data.webhook_url);
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const recent = await context.supabase.from("notification_deliveries").select("id").eq("user_id", context.userId).gte("created_at", new Date(Date.now() - 60000).toISOString()).limit(10);
  if (recent.error || (recent.data?.length ?? 0) >= 10) throw new Error("Please wait a minute before testing again.");
  const payload = notificationPayload(context.userId, "webhook_test", 0);
  const log = await supabaseAdmin.from("notification_deliveries").insert({ user_id: context.userId, event_key: `test:${crypto.randomUUID()}`, payload }).select("id").single();
  if (log.error) throw new Error("Test could not be recorded.");
  const { sendWebhook } = await import("./notifications.server");
  let result = { ok: false, status: 0 };
  try { result = await sendWebhook(url, payload); } catch { /* failure recorded below */ }
  await supabaseAdmin.from("notification_deliveries").update({ status: result.ok ? "delivered" : "failed", http_status: result.status || null }).eq("id", log.data.id).eq("user_id", context.userId);
  if (!result.ok) throw new Error(result.status ? `Webhook rejected the test (HTTP ${result.status}).` : "Webhook timed out or could not be reached.");
  const saved = await context.supabase.from("notification_settings").update({ verified_at: new Date().toISOString() }).eq("user_id", context.userId).eq("webhook_url", url).select("user_id");
  if (saved.error || !saved.data?.length) throw new Error("Payload delivered. Save this endpoint, then test again to link it.");
  return { delivered: true };
});
export const notifyWorkstationEvent = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({ event: z.enum(["security", "compilation"]), key: z.string().uuid() }).parse(input)).handler(async ({ data, context }) => {
  const { dispatchNotification } = await import("./notifications.server");
  await dispatchNotification(context.userId, data.event, `client:${data.key}`, data.event === "security" ? "authenticated_session" : "compilation_failure_or_self_healing_trigger");
  return { accepted: true };
});