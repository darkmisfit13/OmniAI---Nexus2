import {
  Clapperboard, Music, Image, Palette, AppWindow, Globe, Workflow, Plug, MessageSquare,
  Mic, Box, Code2, PenLine, Search, Film, Wand2, ScrollText, Shirt, PenTool, Smartphone,
  Database, Component, Webhook, SquareTerminal, LibraryBig, ScanSearch, Inbox, type LucideIcon,
} from "lucide-react";

export type Studio = {
  id: string;
  name: string;
  subLabel: string;
  tagline: string;
  like: string;
  icon: LucideIcon;
  category: string;
  placeholder: string;
  tools: string[];
};

export const studios: Studio[] = [
  { id: "video", name: "Omni Motion", subLabel: "Video Studio", tagline: "Timeline editing, auto-captions, effects", like: "CapCut, Runway, Descript", icon: Clapperboard, category: "Create", placeholder: "Cut my clips into a 30s reel with captions and beat-synced transitions", tools: ["Auto captions", "Beat sync", "Background removal", "Smart cut", "Templates"] },
  { id: "music", name: "Omni Wave", subLabel: "Music Studio", tagline: "Songs, paired variations and your private music library", like: "Suno, Udio, Soundraw", icon: Music, category: "Create", placeholder: "An upbeat synthwave anthem about city lights, female vocals", tools: ["Lyrics", "Vocals", "Styles", "Masters preview", "Library"] },
  { id: "music-video", name: "Omni Beat", subLabel: "Music Video Studio", tagline: "Turn any track into a visual story", like: "Freebeat.ai, Kaiber, Neural Frames", icon: Film, category: "Create", placeholder: "Neon cyberpunk music video synced to my uploaded track", tools: ["Beat detection", "Lip sync", "Style packs", "Scene builder"] },
  { id: "video-gen", name: "Omni Video Gen", subLabel: "Video Generation", tagline: "Cinematic clips from text or images", like: "Sora, Veo, Kling, Pika", icon: Wand2, category: "Create", placeholder: "A drone shot over misty mountains at sunrise, cinematic", tools: ["Text to video", "Image to video", "Camera control", "Upscale"] },
  { id: "image", name: "Omni Imagine", subLabel: "Image Studio", tagline: "Generate, edit, expand and upscale", like: "Firefly, Midjourney, Imagine Art, DALL·E", icon: Image, category: "Create", placeholder: "Portrait of an astronaut in a field of sunflowers, film photo", tools: ["Generative fill", "Expand", "Upscale", "Style reference", "Remove BG"] },
  { id: "style", name: "Omni Style", subLabel: "Outfit & Appearance", tagline: "Wardrobe swaps, face identity and look matching", like: "Facetune, Remini, Reface", icon: Shirt, category: "Create", placeholder: "Swap the outfit for a tailored midnight-blue suit, keep the pose", tools: ["Wardrobe swap", "Face identity anchor", "Expression", "Skin blend", "Light match"] },
  { id: "storyboard", name: "Omni Storyboard", subLabel: "Scripts & Scenes", tagline: "Scripts broken into shot-by-shot scenes", like: "Boords, StudioBinder, Plot", icon: ScrollText, category: "Create", placeholder: "A 60-second product launch video for a smart water bottle", tools: ["Script writer", "Scene split", "Shot list", "Beat sheet"] },
  { id: "3d", name: "Omni 3D Spatial Studio", subLabel: "3D Modeling & Textures", tagline: "Live 3D viewport, materials and texture inpainting", like: "Meshy, Spline, Blender", icon: Box, category: "Create", placeholder: "A chrome hover-bike with neon trim and matte obsidian panels", tools: ["Mesh styles", "Material AI", "Texture deck", "Export .obj/.gltf/.usdz"] },
  { id: "vector", name: "Omni Vector & Brand Lab", subLabel: "Vector Graphics & Branding", tagline: "Logos, brand kits and vector artwork", like: "Looka, Brandmark, Illustrator", icon: PenTool, category: "Create", placeholder: "Minimal geometric logo for a coffee brand called Northbeam", tools: ["Logo gen", "Brand kit", "Palette", "Wordmark"] },
  { id: "mockup", name: "Omni Viral Mockup", subLabel: "Social Feed Simulator", tagline: "Preview assets inside real platform feeds", like: "Mockuuups, Previewed, Rotato", icon: Smartphone, category: "Create", placeholder: "Drop my cover art into a TikTok feed mockup", tools: ["Phone viewport", "Safe zones", "Platforms", "Vault drag"] },
  { id: "design", name: "Omni Design", subLabel: "Design Canvas", tagline: "Posters, social posts, decks, brand kits", like: "Canva, Figma AI, Adobe Express", icon: Palette, category: "Create", placeholder: "Instagram carousel announcing my summer sale, bold and bright", tools: ["Templates", "Brand kit", "Magic resize", "Presentations"] },
  { id: "app-builder", name: "Omni App Builder", subLabel: "App Builder", tagline: "Describe an app, get a working product", like: "Lovable, Bolt, Replit", icon: AppWindow, category: "Build", placeholder: "A habit tracker with streaks, reminders and a dark theme", tools: ["Full-stack", "Database", "Auth", "Deploy"] },
  { id: "website", name: "Omni Site", subLabel: "AI Website & App Builder", tagline: "Tell Omni AI what to build and watch it come alive", like: "Framer, Wix AI, Durable", icon: Globe, category: "Build", placeholder: "Landing page for my barbershop with booking and gallery", tools: ["Pages", "SEO", "Domains", "Forms"] },
  { id: "backend", name: "Omni Backend Architect", subLabel: "Database & API Design", tagline: "Visual schema mapping, auth logic and live API docs", like: "Supabase, Prisma, Postman", icon: Database, category: "Build", placeholder: "Design a marketplace schema with users, products and orders", tools: ["Schema canvas", "API docs", "Auth pipeline", "Webhooks", "Mock data"] },
  { id: "cosmic-ui", name: "Omni Cosmic UI Lab", subLabel: "UI Components", tagline: "Interface components, variants and snippets", like: "shadcn, Storybook, v0", icon: Component, category: "Build", placeholder: "A glassmorphic pricing card with a glowing CTA", tools: ["Component gen", "Variants", "Copy code", "Themes"] },
  { id: "api-lab", name: "Omni API & Webhook Lab", subLabel: "Build & Simulate Integrations", tagline: "Compose requests and simulate webhook flows", like: "Postman, Hoppscotch, ngrok", icon: Webhook, category: "Build", placeholder: "Simulate a Stripe payment.succeeded webhook into my endpoint", tools: ["Request builder", "Webhook sim", "cURL export", "Mock responses"] },
  { id: "code", name: "Omni Code", subLabel: "Code Assistant", tagline: "Write, explain and fix code", like: "Cursor, Copilot, Claude Code", icon: Code2, category: "Build", placeholder: "Write a Python script that renames photos by date taken", tools: ["Generate", "Explain", "Debug", "Refactor"] },
  { id: "automations", name: "Omni Automations", subLabel: "Automations", tagline: "AI agents that work while you sleep", like: "Zapier, Make, n8n", icon: Workflow, category: "Automate", placeholder: "When I get a new email from a client, summarize it and post to Slack", tools: ["Triggers", "AI steps", "Schedules", "Agents"] },
  { id: "connectors", name: "Omni Connect", subLabel: "Connections", tagline: "Plug in the apps you already use", like: "Google, Slack, Notion, Shopify, Stripe", icon: Plug, category: "Automate", placeholder: "Connect my Google Drive and Notion", tools: ["Google", "Slack", "Notion", "Shopify", "Stripe", "YouTube"] },
  { id: "inbox", name: "Omni Inbox Prioritizer", subLabel: "Email Follow-Ups", tagline: "Triages email and drafts the follow-ups", like: "Superhuman, SaneBox, Shortwave", icon: Inbox, category: "Automate", placeholder: "Prioritize these emails and draft follow-ups for the urgent ones", tools: ["Triage", "Follow-up drafts", "Snooze", "Summaries"] },
  { id: "chat", name: "Omni Chat", subLabel: "AI Chat", tagline: "Every top model in one conversation", like: "ChatGPT, Claude, Gemini, Grok", icon: MessageSquare, category: "Think", placeholder: "Help me plan a 7-day trip to Japan on a budget", tools: ["Model switch", "Files", "Memory", "Web"] },
  { id: "research", name: "Omni Research", subLabel: "Research", tagline: "Answers with sources, deep reports", like: "Perplexity, NotebookLM", icon: Search, category: "Think", placeholder: "Deep report on the electric bike market in 2026", tools: ["Web search", "Citations", "Reports", "Podcasts"] },
  { id: "writing", name: "Omni Writer", subLabel: "Writing", tagline: "Copy, scripts, blogs, emails", like: "Jasper, Grammarly, Copy.ai", icon: PenLine, category: "Think", placeholder: "Write a YouTube script hook for my cooking channel", tools: ["Rewrite", "Tone", "Grammar", "Translate"] },
  { id: "prompt", name: "Omni Prompt Studio", subLabel: "Prompt Engineering", tagline: "Craft, enhance and test prompts across models", like: "PromptPerfect, FlowGPT", icon: SquareTerminal, category: "Think", placeholder: "A prompt that turns meeting notes into action items", tools: ["Enhance", "Test run", "Model compare", "Library"] },
  { id: "website-analyzer", name: "Omni Website Analyzer", subLabel: "Audit Site Structure", tagline: "Audit websites and social profiles for fixes", like: "Ahrefs, Lighthouse, Screaming Frog", icon: ScanSearch, category: "Think", placeholder: "https://mysite.com — full audit", tools: ["SEO audit", "Structure", "Speed", "Social profiles"] },
  { id: "voice", name: "Omni Voice", subLabel: "Voice, Audio & Dubbing", tagline: "Voiceovers, cloning and multi-language dubbing", like: "ElevenLabs, Murf, Adobe Podcast", icon: Mic, category: "Create", placeholder: "Deep, warm narrator voice reading my intro script", tools: ["Text to speech", "Voice clone", "Dubbing", "Enhance"] },
  { id: "media-library", name: "Omni Media Library", subLabel: "Media Vault", tagline: "Everything you've made, in one vault", like: "Google Drive, Dropbox", icon: LibraryBig, category: "Create", placeholder: "Show everything I made this week", tools: ["All media", "Filter", "Download", "Reuse"] },
];

export const categories = ["Create", "Build", "Automate", "Think"];
