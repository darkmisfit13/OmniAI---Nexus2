import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { requireMusicAccess } from "./omniwave-plans";
export async function assertOmniWaveAccess(client: SupabaseClient<Database>, userId: string, operation: string, preview = false) {
  const result = await client.rpc("has_omniwave_pro", { p_user: userId });
  if (result.error) throw new Error("OmniWave subscription access could not be verified.");
  requireMusicAccess(result.data === true, operation, preview);
}