export const OMNI_PLANS = [
  { id: 'free', name: 'Omni Free', monthlyUsd: 0, monthlyCredits: 100, pro: false, priority: 'Standard' },
  { id: 'plus', name: 'Omni Plus', monthlyUsd: 19, monthlyCredits: 1200, pro: false, priority: 'Standard' },
  { id: 'pro', name: 'Omni Pro', monthlyUsd: 49, monthlyCredits: 4500, pro: true, priority: 'Standard' },
  { id: 'ultra', name: 'Omni Ultra', monthlyUsd: 99, monthlyCredits: 10000, pro: true, priority: 'Maximum' },
] as const;
export const OMNI_BOOSTERS = ['Omni Spark', 'Omni Pulse', 'Omni Surge', 'Omni Infinity'] as const;
export function omniPlan(row: { plan: string; status: string; period_start: string; period_end: string } | null, now = Date.now()) {
  return row?.status === 'active' && Date.parse(row.period_start) <= now && Date.parse(row.period_end) > now ? OMNI_PLANS.find(p => p.id === row.plan) ?? OMNI_PLANS[0] : OMNI_PLANS[0];
}
export function pipelineCredits(seconds: number, images: number) { return 5 + 3 * images + 8 * seconds; }
export function escrowRemaining(r: { reserved: number; spent: number; pending: number; released: number }) { return r.reserved - r.spent - r.pending - r.released; }
