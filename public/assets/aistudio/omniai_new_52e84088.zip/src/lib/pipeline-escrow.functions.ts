import { createServerFn } from '@tanstack/react-start';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
export const getPipelineEscrow = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator((d: { projectId: string }) => d).handler(async ({ data, context }) => {
  const r = await context.supabase.from('omni_pipeline_reservations').select('*').eq('project_id', data.projectId).eq('user_id', context.userId).order('created_at', { ascending: false }).limit(1).maybeSingle();
  if (r.error) throw new Error('Reservation unavailable.'); return r.data;
});
export const reservePipeline = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator((d: { projectId: string }) => d).handler(async ({ data, context }) => {
  const r = await context.supabase.rpc('reserve_omni_pipeline', { p_project: data.projectId }); if (r.error) throw new Error(r.error.message); return r.data;
});
export const extendPipeline = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator((d: { id: string }) => d).handler(async ({ data, context }) => {
  const r = await context.supabase.rpc('extend_omni_pipeline', { p_id: data.id }); if (r.error) throw new Error(r.error.message); return r.data;
});
export const settlePipeline = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator((d: { projectId: string; completed?: boolean }) => d).handler(async ({ data, context }) => {
  const { pipelineReservation } = await import('./pipeline-escrow.server');
  const r = await pipelineReservation(context.supabase, context.userId, data.projectId);
  if (data.completed) {
    const saved = await context.supabase.from('studio_projects').select('state').eq('id', data.projectId).single();
    const state = saved.data?.state as { final?: { projectId?: string }[] } | undefined;
    const id = state?.final?.at(-1)?.projectId;
    if (!id || r.pending > 0) throw new Error('Saved final film and completed jobs required.');
    const final = await context.supabase.from('studio_projects').select('asset_path').eq('id', id).eq('kind','video').single();
    if (final.error || !final.data.asset_path) throw new Error('Saved final film required.');
  }
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
  const release = await supabaseAdmin.rpc('release_omni_pipeline', { p_id: r.id, p_user: context.userId });
  if (release.error) throw new Error('Unused credit release unavailable.'); return release.data;
});
