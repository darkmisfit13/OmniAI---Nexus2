import { describe, expect, it } from "vitest";
import { joinSite, splitSite } from "./site-files";

const doc = `<html><head><style>body{color:red}</style></head><body><h1>Hi</h1><script src="x.js"></script><script>console.log(1)</script></body></html>`;

describe("site files", () => {
  it("splits inline css and js into their own files", () => {
    const f = splitSite(doc);
    expect(f["styles.css"]).toBe("body{color:red}");
    expect(f["script.js"]).toBe("console.log(1)");
    expect(f["index.html"]).toContain('<script src="x.js"></script>');
  });
  it("joins edited files back into one working document", () => {
    const f = splitSite(doc);
    const out = joinSite({ ...f, "styles.css": "body{color:blue}" });
    expect(out).toContain("<style>\nbody{color:blue}\n</style>");
    expect(out).toContain("console.log(1)");
  });
});
