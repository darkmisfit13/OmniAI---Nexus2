export type CreditOperation = "analysis" | "image" | "video" | "correction" | "music-teaser" | "music-song" | "music-pair";
export type CreditRequest = { operation: CreditOperation; target: string; prompt?: string; seconds?: number; projectId?: string; refUrls?: string[]; preview?: boolean };
export const MUSIC_PRICES = { "music-teaser": 12, "music-song": 24, "music-pair": 48 } as const;
export function creditLineItem(r: CreditRequest) {
  if (r.preview) return "Generate High-Tier Preview";
  if (r.operation === "music-teaser") return "30-Second Track Teaser";
  if (r.operation === "music-song") return "Base Track Synthesis";
  if (r.operation === "music-pair") return "Dual-Song Compilation · 2 × 24 CR";
  return `${r.operation} · ${r.target}`;
}
export function creditCost(request: CreditRequest) {
  if (!["analysis", "image", "video", "correction", ...Object.keys(MUSIC_PRICES)].includes(request.operation)) throw new Error("Unknown credit operation.");
  if (request.operation in MUSIC_PRICES) return MUSIC_PRICES[request.operation as keyof typeof MUSIC_PRICES];
  if (request.operation === "video" && (!Number.isInteger(request.seconds) || (request.seconds ?? 0) < 3 || (request.seconds ?? 0) > 10)) throw new Error("Video duration must be 3–10 seconds.");
  return request.operation === "analysis" ? 5 : request.operation === "image" ? 3 : request.operation === "correction" ? 25 : 8 * (request.seconds ?? 0);
}
export function canonicalCreditRequest(r: CreditRequest) {
  creditCost(r);
  return JSON.stringify({ operation: r.operation, target: r.target, prompt: (r.prompt ?? "").slice(0, 6000), seconds: r.operation === "video" ? r.seconds : null, projectId: r.projectId ?? null, refUrls: r.refUrls ?? [], ...(r.preview ? { preview: true } : {}) });
}