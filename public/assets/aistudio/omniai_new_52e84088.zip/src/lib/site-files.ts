// Splits the builder's single HTML document into virtual files (index.html, styles.css, script.js)
// and joins them back, so the code view can show a file list while output stays one document.
export type SiteFiles = { "index.html": string; "styles.css": string; "script.js": string };
export const FILE_NAMES = ["index.html", "styles.css", "script.js"] as const;
const CSS_MARK = "<!--omni:styles-->";
const JS_MARK = "<!--omni:script-->";

export function splitSite(html: string): SiteFiles {
  const css: string[] = []; const js: string[] = [];
  let rest = html.replace(/<style[^>]*>([\s\S]*?)<\/style>/gi, (_m, body: string) => { css.push(body.trim()); return css.length === 1 ? CSS_MARK : ""; });
  rest = rest.replace(/<script(?![^>]*\bsrc=)(?![^>]*type=["']?(?:application\/json|importmap|module))[^>]*>([\s\S]*?)<\/script>/gi, (_m, body: string) => { js.push(body.trim()); return js.length === 1 ? JS_MARK : ""; });
  return { "index.html": rest, "styles.css": css.join("\n\n"), "script.js": js.join("\n\n") };
}

export function joinSite(f: SiteFiles): string {
  let html = f["index.html"];
  const style = f["styles.css"].trim() ? `<style>\n${f["styles.css"]}\n</style>` : "";
  const script = f["script.js"].trim() ? `<script>\n${f["script.js"]}\n</script>` : "";
  html = html.includes(CSS_MARK) ? html.replace(CSS_MARK, style) : /<\/head>/i.test(html) ? html.replace(/<\/head>/i, `${style}</head>`) : style + html;
  html = html.includes(JS_MARK) ? html.replace(JS_MARK, script) : /<\/body>/i.test(html) ? html.replace(/<\/body>/i, `${script}</body>`) : html + script;
  return html;
}
