import type { ProductionOutput } from "./music-video";
/** Browser-only rendering, using saved clip URLs and the original song. */
export async function renderMusicFilm(clips: ProductionOutput[], trackUrl: string, reverse = false): Promise<Blob> {
  if (!clips.length || clips.some((c) => !c.url)) throw new Error("All clips must be ready before merging.");
  const mimeType = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"].find((type) => MediaRecorder.isTypeSupported(type));
  if (!mimeType) throw new Error("This browser cannot render WebM. Open the clips in the video editor instead.");
  const canvas = document.createElement("canvas"); canvas.width = 1280; canvas.height = 720;
  const ctx = canvas.getContext("2d"); if (!ctx) throw new Error("Video rendering is unavailable.");
  const audio = document.createElement("audio"); audio.crossOrigin = "anonymous"; audio.preload = "auto";
  const audioCtx = new AudioContext(); const dest = audioCtx.createMediaStreamDestination(); const source = audioCtx.createMediaElementSource(audio); source.connect(dest); source.connect(audioCtx.destination);
  const stream = canvas.captureStream(30); dest.stream.getAudioTracks().forEach((t) => stream.addTrack(t));
  const recorder = new MediaRecorder(stream, { mimeType }); const chunks: Blob[] = [];
  const output = new Promise<Blob>((resolve, reject) => { recorder.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); }; recorder.onstop = () => resolve(new Blob(chunks, { type: "video/webm" })); recorder.onerror = () => reject(new Error("Render failed.")); });
  // Keep recorder errors handled even if media playback rejects first.
  void output.catch(() => {});
  const videos: HTMLVideoElement[] = [];
  async function load(media: HTMLMediaElement, url: string, label: string) {
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => finish(new Error(`${label} took too long to load. Try rendering again.`)), 30000);
      function finish(error?: Error) { clearTimeout(timer); media.onloadeddata = null; media.onerror = null; if (error) reject(error); else resolve(); }
      media.onloadeddata = () => {
        if (!Number.isFinite(media.duration) || media.duration <= 0) finish(new Error(`${label} has no playable duration.`));
        else finish();
      };
      media.onerror = () => finish(new Error(`${label} could not be decoded. Try Chrome or Edge with video playback enabled.`));
      media.src = url; media.load();
    });
  }
  try {
    await audioCtx.resume();
    await load(audio, trackUrl, "Original song");
    for (const clip of reverse ? [...clips].reverse() : clips) {
      const v = document.createElement("video"); v.crossOrigin = "anonymous"; v.muted = true; v.playsInline = true; v.preload = "auto";
      videos.push(v); await load(v, clip.url ?? "", `Scene ${videos.length}`);
      if (!v.videoWidth || !v.videoHeight) throw new Error(`Scene ${videos.length} has no video frames.`);
    }
    let elapsed = 0;
    for (const v of videos) {
      // Draw the next scene before restarting the recorder: loading gaps never
      // become black/frozen frames, and the soundtrack shares the same boundary.
      ctx.drawImage(v, 0, 0, canvas.width, canvas.height);
      audio.currentTime = Math.min(elapsed, audio.duration);
      await new Promise<void>((resolve, reject) => {
        let raf = 0, finished = false;
        const timer = setTimeout(() => finish(new Error("Scene playback stalled. Keep this page visible and try again.")), Math.max(60000, v.duration * 3000));
        function finish(error?: Error) {
          if (finished) return; finished = true; clearTimeout(timer); cancelAnimationFrame(raf);
          v.onended = null; v.onerror = null; v.onwaiting = null; v.onplaying = null;
          v.pause(); audio.pause(); if (recorder.state === "recording") recorder.pause();
          if (error) reject(error); else resolve();
        }
        const tick = () => {
          try { ctx.drawImage(v, 0, 0, canvas.width, canvas.height); }
          catch { finish(new Error("A scene could not be captured. Reload the saved scenes and try again.")); return; }
          if (v.ended) { finish(); return; }
          raf = requestAnimationFrame(tick);
        };
        v.onended = () => finish(); v.onerror = () => finish(new Error("Scene playback failed."));
        v.onwaiting = () => { if (recorder.state === "recording") recorder.pause(); audio.pause(); };
        v.onplaying = () => {
          if (finished) return;
          if (recorder.state === "inactive") recorder.start(250);
          else if (recorder.state === "paused") recorder.resume();
          audio.currentTime = Math.min(elapsed + v.currentTime, audio.duration);
          if (!audio.ended && audio.currentTime < audio.duration) void audio.play().catch(() => finish(new Error("Original song playback failed.")));
        };
        tick(); void v.play().catch(() => finish(new Error("Scene could not start playing. Try rendering again.")));
      });
      elapsed += v.duration;
    }
    recorder.stop(); const blob = await output;
    if (!blob.size) throw new Error("No video was recorded. Keep this page visible and try again.");
    const { default: fixWebmDuration } = await import("fix-webm-duration");
    return await fixWebmDuration(blob, elapsed * 1000, { logger: false });
  } finally {
    if (recorder.state !== "inactive") recorder.stop();
    for (const media of [audio, ...videos]) { media.pause(); media.removeAttribute("src"); media.load(); }
    stream.getTracks().forEach((t) => t.stop()); await audioCtx.close();
  }
}