import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
export const setOrbMotion = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((d: { enabled: boolean }) => { if (typeof d.enabled !== "boolean") throw new Error("Invalid motion setting."); return d; })
  .handler(async ({ data, context }) => {
    const access = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (access.error || !access.data) throw new Error("Administrator access required.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const saved = await supabaseAdmin.from("workspace_settings").upsert({ id: "global", orb_enabled: data.enabled });
    if (saved.error) throw new Error("Orb motion setting could not be saved.");
    return { enabled: data.enabled };
  });