export type Curve = "none" | "montage" | "hero" | "bullet";
export type Clip = {
  id: string; mediaId: string; in: number; out: number; speed: number; curve: Curve;
  volume: number; fadeIn: number; fadeOut: number; scale: number; x: number; y: number; rotate: number; opacity: number;
  bright: number; contrast: number; sat: number; hue: number; blur: number; filter: string;
  chroma: boolean; chromaColor: string; chromaSim: number; anim: "none" | "fade" | "zoom" | "slide";
};

export const CURVES: Record<Curve, string> = { none: "Normal", montage: "Montage", hero: "Hero-Time", bullet: "Bullet" };

/** Playback-rate multiplier at clip progress p (0..1) for each speed-ramp preset. */
export function curveRate(curve: Curve, p: number): number {
  const x = Math.min(1, Math.max(0, p));
  if (curve === "montage") return x < 0.25 || x > 0.75 ? 2 : 0.7;
  if (curve === "hero") return x > 0.4 && x < 0.6 ? 0.3 : 1.2;
  if (curve === "bullet") return x > 0.3 && x < 0.7 ? 0.2 : 2.5;
  return 1;
}

/** Nominal timeline length of a clip. */
export const clipDuration = (c: Pick<Clip, "in" | "out" | "speed">) => Math.max(0.1, (c.out - c.in) / Math.max(0.1, c.speed));

export const FILTERS: Record<string, string> = {
  None: "", Cinematic: "contrast(115%) saturate(85%) sepia(15%)", Noir: "grayscale(100%) contrast(130%)",
  Vintage: "sepia(55%) contrast(95%) brightness(105%)", Neon: "saturate(180%) hue-rotate(-15deg) contrast(110%)",
  Cool: "hue-rotate(15deg) saturate(110%)", Warm: "sepia(25%) saturate(130%)", Dream: "brightness(110%) saturate(120%) blur(0.6px)",
};
