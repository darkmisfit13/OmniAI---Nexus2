import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { creditCost, creditLineItem, type CreditRequest } from "./studio-credit";
export const quoteStudioCredits = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: CreditRequest) => { creditCost(data); if (!data.target || data.target.length > 80) throw new Error("Invalid studio."); return data; })
  .handler(async ({ data, context }) => {
    const music = data.operation.startsWith("music-");
    if (music) {
      const { assertOmniWaveAccess } = await import("./omniwave-access.server");
      await assertOmniWaveAccess(context.supabase, context.userId, data.operation, !!data.preview);
    }
    const { creditHash } = await import("./studio-credit.server");
    const amount = creditCost(data);
    const requestHash = await creditHash(data);
    // Privileged insert is needed: clients may read approvals but cannot author rates or balances.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const units = data.operation === "music-pair" ? 2 : data.operation === "video" ? data.seconds ?? 8 : 1;
    const row = await supabaseAdmin.from("studio_credit_approvals").insert({ user_id: context.userId, operation: data.operation, request_hash: requestHash, amount, units, wallet_scope: music ? "omniwave" : "omniai", music_preview: music && !!data.preview }).select("id,expires_at").single();
    if (row.error) throw new Error("Credit quote could not be created.");
    const wallet = await context.supabase.from("studio_credit_wallets").select("balance").eq("user_id", context.userId).maybeSingle();
    if (wallet.error) throw new Error("Credit balance unavailable.");
    return { id: row.data.id, amount, balance: wallet.data?.balance ?? 0, expiresAt: row.data.expires_at, operation: data.operation, units, target: data.target, lineItem: creditLineItem(data), preview: !!data.preview, walletName: "Omni Global", pricingVersion: "studio-cr-v4" };
  });
export const confirmStudioCredits = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data, context }) => {
    const r = await context.supabase.rpc("confirm_studio_credit_charge", { p_id: data.id });
    if (r.error) throw new Error(r.error.message);
    return { approvalId: data.id, balance: r.data };
  });