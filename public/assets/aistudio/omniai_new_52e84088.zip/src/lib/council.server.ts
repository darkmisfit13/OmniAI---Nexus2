import type { CouncilInput } from "./council";

async function encryptionKey() {
  const secret = process.env["COUNCIL_ENCRYPTION_SECRET"];
  if (!secret) throw new Error("Council secure storage is unavailable.");
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(secret));
  return crypto.subtle.importKey("raw", bytes, "AES-GCM", false, ["encrypt", "decrypt"]);
}
export async function encryptCouncilKey(value: string) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const result = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await encryptionKey(), new TextEncoder().encode(value));
  return `${btoa(String.fromCharCode(...iv))}.${btoa(String.fromCharCode(...new Uint8Array(result)))}`;
}
export async function decryptCouncilKey(value: string) {
  const [iv, data] = value.split(".");
  if (!iv || !data) throw new Error("Council credential is unavailable.");
  const bytes = (v: string) => Uint8Array.from(atob(v), (c) => c.charCodeAt(0));
  return new TextDecoder().decode(await crypto.subtle.decrypt({ name: "AES-GCM", iv: bytes(iv) }, await encryptionKey(), bytes(data)));
}

const endpoints = {
  openai: "https://api.openai.com/v1/chat/completions",
  openrouter: "https://openrouter.ai/api/v1/chat/completions",
  groq: "https://api.groq.com/openai/v1/chat/completions",
  xai: "https://api.x.ai/v1/chat/completions",
  deepseek: "https://api.deepseek.com/chat/completions",
};
export async function askCouncilMember(member: Pick<CouncilInput, "provider" | "model" | "apiKey">, question: string, signal?: AbortSignal) {
  const timeout = AbortSignal.timeout(45000);
  const requestSignal = signal ? AbortSignal.any([signal, timeout]) : timeout;
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  let url: string, body: unknown;
  if (member.provider === "anthropic") {
    url = "https://api.anthropic.com/v1/messages";
    headers["x-api-key"] = member.apiKey; headers["anthropic-version"] = "2023-06-01";
    body = { model: member.model, max_tokens: 1200, messages: [{ role: "user", content: question }] };
  } else if (member.provider === "google") {
    url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(member.model)}:generateContent`;
    headers["x-goog-api-key"] = member.apiKey;
    body = { contents: [{ parts: [{ text: question }] }], generationConfig: { maxOutputTokens: 1600 } };
  } else {
    url = endpoints[member.provider]; headers["Authorization"] = `Bearer ${member.apiKey}`;
    body = { model: member.model, messages: [{ role: "user", content: question }] };
  }
  const response = await fetch(url, { method: "POST", headers, body: JSON.stringify(body), signal: requestSignal, redirect: "error" });
  if (!response.ok) throw new Error(`Council provider rejected the request (${response.status}). Check its key, model and billing.`);
  const data = await response.json() as { content?: Array<{ text?: string }>; candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>; choices?: Array<{ message?: { content?: string } }> };
  const text = member.provider === "anthropic" ? data.content?.map((p) => p.text ?? "").join("") : member.provider === "google" ? data.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") : data.choices?.[0]?.message?.content;
  if (!text?.trim()) throw new Error("Council provider returned no answer.");
  return text.slice(0, 12000);
}

export async function configuredCouncil(question: string, signal: AbortSignal) {
  // Only called after the chat handler authenticates the user and owns the thread.
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const rows = await supabaseAdmin.from("council_members").select("label,provider,model,credential_ciphertext").eq("enabled", true);
  if (rows.error) throw new Error("Council configuration could not be read.");
  if (!rows.data.length) return null;
  const answers = await Promise.allSettled(rows.data.map(async (r) => {
    const provider = r.provider as CouncilInput["provider"];
    return askCouncilMember({ provider, model: r.model, apiKey: await decryptCouncilKey(r.credential_ciphertext) }, question, signal);
  }));
  if (signal.aborted) throw new Error("Council request cancelled.");
  const text = answers.flatMap((r) => r.status === "fulfilled" ? [r.value] : []);
  if (!text.length) throw new Error("No connected Council model answered. Ask the administrator to test the enabled connections.");
  return `Connected Council opinions (${text.length}/${rows.data.length} answered; evaluate critically and synthesize):\n${text.join("\n\n")}`;
}