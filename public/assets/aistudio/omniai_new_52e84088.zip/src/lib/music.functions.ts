import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { musicInput } from "./music";

export const createMusic = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => musicInput.parse(input))
  .handler(async ({ data, context }) => {
    const { runMusicGeneration } = await import("./music.server");
    return runMusicGeneration(context.supabase, context.userId, data);
  });