import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { omniwavePlan } from "./omniwave-plans";
export const getOmniWaveAccount = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const [subscription, wallet, pro] = await Promise.all([
    context.supabase.from("omniwave_subscriptions").select("plan,status,period_start,period_end").eq("user_id", context.userId).maybeSingle(),
    context.supabase.from("studio_credit_wallets").select("balance").eq("user_id", context.userId).maybeSingle(),
    context.supabase.rpc("has_omniwave_pro", { p_user: context.userId }),
  ]);
  if (subscription.error || wallet.error || pro.error) throw new Error("OmniWave account could not be loaded.");
  return { plan: omniwavePlan(subscription.data), pro: pro.data === true, balance: wallet.data?.balance ?? 0, periodEnd: subscription.data?.period_end ?? null };
});