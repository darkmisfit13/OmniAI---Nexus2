import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

export const listThreads = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { data, error } = await context.supabase.from("chat_threads").select("*").eq("user_id", context.userId).order("updated_at", { ascending: false });
  if (error) throw error;
  return data;
});
export const newThread = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { data, error } = await context.supabase.from("chat_threads").insert({ user_id: context.userId }).select().single();
  if (error) throw error;
  return data;
});
export const renameThread = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({ id: z.string().uuid(), title: z.string().trim().min(1).max(200) }).parse(input)).handler(async ({ context, data }) => {
  const { error } = await context.supabase.from("chat_threads").update({ title: data.title, updated_at: new Date().toISOString() }).eq("id", data.id).eq("user_id", context.userId);
  if (error) throw error;
});
export const deleteThread = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input)).handler(async ({ context, data }) => {
  const memories = await context.supabase.from("ai_memories").delete().eq("user_id", context.userId).eq("source_thread_id", data.id);
  if (memories.error) throw memories.error;
  const { error } = await context.supabase.from("chat_threads").delete().eq("id", data.id).eq("user_id", context.userId);
  if (error) throw error;
});
export const loadThread = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input)).handler(async ({ context, data }) => {
  const thread = await context.supabase.from("chat_threads").select("*").eq("id", data.id).eq("user_id", context.userId).single();
  if (thread.error) throw new Error("Conversation not found.");
  const messages = await context.supabase.from("chat_messages").select("message").eq("thread_id", data.id).eq("user_id", context.userId).order("created_at");
  if (messages.error) throw messages.error;
  return { thread: thread.data, messages: messages.data.map((r) => r.message) };
});
export const getMemories = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { data, error } = await context.supabase.from("ai_memories").select("*").eq("user_id", context.userId).order("created_at", { ascending: false });
  if (error) throw error;
  return data;
});
export const forgetMemory = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input)).handler(async ({ context, data }) => {
  const { error } = await context.supabase.from("ai_memories").delete().eq("id", data.id).eq("user_id", context.userId);
  if (error) throw error;
});
export const getProfile = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { data, error } = await context.supabase.from("profiles").select("*").eq("id", context.userId).single();
  if (error) throw error;
  return data;
});
export const saveProfile = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({ name: z.string().trim().max(200) }).parse(input)).handler(async ({ context, data }) => {
  const { error } = await context.supabase.from("profiles").update({ display_name: data.name }).eq("id", context.userId);
  if (error) throw error;
});
export const listProjects = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({ studio: z.string() }).parse(input)).handler(async ({ context, data }) => {
  const result = await context.supabase.from("studio_projects").select("*").eq("user_id", context.userId).eq("studio", data.studio).order("created_at", { ascending: false });
  if (result.error) throw result.error;
  return Promise.all(result.data.map(async (p) => {
    if (!p.asset_path) return { ...p, url: null };
    const signed = await context.supabase.storage.from("studio-assets").createSignedUrl(p.asset_path, 3600);
    if (signed.error) throw signed.error;
    return { ...p, url: signed.data.signedUrl };
  }));
});

export const listAllProjects = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const result = await context.supabase.from("studio_projects").select("*").eq("user_id", context.userId).order("created_at", { ascending: false }).limit(200);
  if (result.error) throw result.error;
  return Promise.all(result.data.map(async (p) => {
    if (!p.asset_path) return { ...p, url: null };
    const signed = await context.supabase.storage.from("studio-assets").createSignedUrl(p.asset_path, 3600);
    if (signed.error) throw signed.error;
    return { ...p, url: signed.data.signedUrl };
  }));
});

export const saveProject = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({ studio: z.string().max(40), title: z.string().trim().min(1).max(300), content: z.string().max(200000) }).parse(input)).handler(async ({ context, data }) => {
  const { error } = await context.supabase.from("studio_projects").insert({ user_id: context.userId, studio: data.studio, title: data.title, kind: "text", content: data.content });
  if (error) throw error;
});