import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { councilInput, isCouncilAdmin } from "./council";

export const councilAccess = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const r = await context.supabase.from("user_roles").select("role").eq("user_id", context.userId);
  if (r.error) throw new Error("Council permissions could not be checked.");
  return { admin: isCouncilAdmin(r.data) };
});
export const listCouncil = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const role = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
  if (role.error || !role.data) throw new Error("Council administrator access required.");
  const rows = await context.supabase.from("council_members").select("id,label,provider,model,enabled,last_checked").order("created_at");
  if (rows.error) throw new Error("Council models could not be loaded.");
  return rows.data;
});
export const saveCouncil = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => councilInput.parse(input)).handler(async ({ context, data }) => {
  const role = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
  if (role.error || !role.data) throw new Error("Council administrator access required.");
  const { encryptCouncilKey } = await import("./council.server");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const count = await supabaseAdmin.from("council_members").select("id", { count: "exact", head: true });
  if (count.error) throw new Error("Council could not be checked.");
  if ((count.count ?? 0) >= 20) throw new Error("Council supports up to 20 members. Remove a member first.");
  const r = await supabaseAdmin.from("council_members").insert({ label: data.label, provider: data.provider, model: data.model, credential_ciphertext: await encryptCouncilKey(data.apiKey), created_by: context.userId });
  if (r.error) throw new Error("Council connection could not be saved.");
  return { saved: true };
});
export const changeCouncil = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({ id: z.string().uuid(), action: z.enum(["enable", "disable", "remove", "test"]) }).parse(input)).handler(async ({ context, data }) => {
  const role = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
  if (role.error || !role.data) throw new Error("Council administrator access required.");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  if (data.action === "test") {
    const row = await supabaseAdmin.from("council_members").select("provider,model,credential_ciphertext").eq("id", data.id).single();
    if (row.error) throw new Error("Council member not found.");
    const { askCouncilMember, decryptCouncilKey } = await import("./council.server");
    const provider = councilInput.shape.provider.parse(row.data.provider);
    await askCouncilMember({ provider, model: row.data.model, apiKey: await decryptCouncilKey(row.data.credential_ciphertext) }, "Reply with OK.");
    const result = await supabaseAdmin.from("council_members").update({ last_checked: new Date().toISOString() }).eq("id", data.id);
    if (result.error) throw new Error("Connection answered, but its status could not be saved.");
    return { message: "Model answered successfully." };
  }
  const r = data.action === "remove" ? await supabaseAdmin.from("council_members").delete().eq("id", data.id) : await supabaseAdmin.from("council_members").update({ enabled: data.action === "enable" }).eq("id", data.id);
  if (r.error) throw new Error("Council change could not be saved.");
  return { message: data.action === "remove" ? "Connection removed." : "Council updated." };
});