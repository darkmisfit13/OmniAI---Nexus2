import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

export async function persistOutput<T extends { kind: string; text?: string; url?: string }>(client: SupabaseClient<Database>, userId: string, studio: string, prompt: string, result: T, projectId?: string) {
  let assetPath: string | null = null;
  if (result.url) {
    const res = await fetch(result.url);
    if (!res.ok) throw new Error("Generated file could not be saved.");
    const blob = await res.blob();
    const extension = blob.type.includes("video") ? "mp4" : blob.type.includes("wav") ? "wav" : blob.type.includes("audio") ? "mp3" : "png";
    assetPath = `${userId}/${crypto.randomUUID()}.${extension}`;
    const upload = await client.storage.from("studio-assets").upload(assetPath, blob, { contentType: blob.type });
    if (upload.error) throw new Error(`File saving failed: ${upload.error.message}`);
  }
  const values = { user_id: userId, studio, title: prompt, kind: result.kind, content: result.text ?? null, asset_path: assetPath };
  const saved = projectId ? await client.from("studio_projects").update(values).eq("id", projectId).eq("user_id", userId).select().single() : await client.from("studio_projects").insert(values).select().single();
  if (saved.error) throw new Error(`Project saving failed: ${saved.error.message}`);
  let url: string | undefined;
  if (assetPath) { const signed = await client.storage.from("studio-assets").createSignedUrl(assetPath, 3600); if (signed.error) throw signed.error; url = signed.data.signedUrl; }
  if (["image", "video", "audio"].includes(result.kind)) {
    const { dispatchNotification } = await import("./notifications.server");
    await dispatchNotification(userId, "generation", `output:${saved.data.id}`, `${result.kind}_generation_completed`);
  }
  return { ...result, url, projectId: saved.data.id };
}