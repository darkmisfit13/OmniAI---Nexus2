import { z } from "zod";
import type { CreditRequest } from "./studio-credit";
export const musicInput = z.object({
  package: z.enum(["teaser", "song", "pair"]).default("pair"),
  prompt: z.string().trim().min(1).max(4000),
  title: z.string().max(120).default("Untitled track"),
  preview: z.boolean().default(false),
  refs: z.array(z.object({ url: z.string().max(800000), mediaType: z.string(), filename: z.string().optional() })).max(8).default([]),
  approvalId: z.string().uuid().optional(),
});
export type MusicDraft = z.infer<typeof musicInput>;
export function musicCreditRequest(d: MusicDraft): CreditRequest {
  if (d.preview && d.package !== "song") throw new Error("Masters preview uses a separately authorized full-song synthesis.");
  return { operation: d.package === "teaser" ? "music-teaser" : d.package === "pair" ? "music-pair" : "music-song", target: "music", prompt: d.prompt, refUrls: d.refs.map(r => r.url), ...(d.preview ? { preview: true } : {}) };
}
export function musicModel(d: Pick<MusicDraft, "package">) {
  return d.package === "teaser" ? "google/lyria-3-clip-preview" : "google/lyria-3-pro-preview";
}
export function unfinishedMusicRefund(pack: MusicDraft["package"], completed: number) {
  const count = pack === "pair" ? 2 : 1;
  if (!Number.isInteger(completed) || completed < 0 || completed > count) throw new Error("Invalid completion count.");
  return (count - completed) * (pack === "teaser" ? 12 : 24);
}