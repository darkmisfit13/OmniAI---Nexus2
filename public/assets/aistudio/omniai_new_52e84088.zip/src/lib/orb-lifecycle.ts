export type WorkspacePhase = "idle" | "classified" | "routed" | "streaming" | "succeeded" | "failed";

export const orbDynamics: Record<WorkspacePhase, { pulse: number; rotation: number; turbulence: number; burst: number }> = {
  idle: { pulse: 1.2, rotation: 0.12, turbulence: 0.14, burst: 0 },
  classified: { pulse: 3.2, rotation: 0.28, turbulence: 0.3, burst: 0.12 },
  routed: { pulse: 4.4, rotation: 0.48, turbulence: 0.48, burst: 0.25 },
  streaming: { pulse: 5.5, rotation: 0.65, turbulence: 0.62, burst: 0.42 },
  succeeded: { pulse: 1.8, rotation: 0.2, turbulence: 0.2, burst: 0.65 },
  failed: { pulse: 0.7, rotation: 0.04, turbulence: 0.38, burst: 0.05 },
};