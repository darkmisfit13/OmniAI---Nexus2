import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { musicCreditRequest, musicModel, type MusicDraft } from "./music";
import { releaseCredit } from "./studio-credit.server";
import { persistOutput } from "./media.server";
import { assertOmniWaveAccess } from "./omniwave-access.server";

export async function synthesizeMusic(d: MusicDraft, variant: number) {
  const model = musicModel(d);
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const block = await supabaseAdmin.from("ai_processing_blocks").select("message").eq("model", model).maybeSingle();
  if (block.error) throw new Error("Music provider access could not be checked.");
  if (block.data) throw new Error(block.data.message);
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new Error("Music generation is not configured.");
  const text = `${d.prompt}\n${d.package === "teaser" ? "Compose a focused 30-second track." : "Compose a complete song up to 184 seconds with a resolved ending."}\n${variant === 1 ? "Variation A: stay faithful to the requested style, warm and melodic arrangement." : "Variation B: reinterpret the same theme with a contrasting rhythm and experimental instrumentation."}`;
  const content: ({ type: "text"; text: string } | { type: "image"; mime_type: string; data: string })[] = [{ type: "text", text }];
  for (const ref of d.refs) {
    const match = /^data:(image\/(?:png|jpeg|webp));base64,(.+)$/.exec(ref.url);
    if (!match?.[1] || !match[2]) throw new Error("Music inspiration supports PNG, JPEG or WebP images; audio and video conditioning are not available for this model.");
    content.push({ type: "image", mime_type: match[1], data: match[2] });
  }
  const body = JSON.stringify({ model, input: [{ type: "user_input", content }] });
  if (new TextEncoder().encode(body).length > 1024 * 1024) throw new Error("Image inspiration must fit within 1 MB in total. Use smaller images.");
  const res = await fetch("https://ai.gateway.lovable.dev/v1/music", { method: "POST", headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" }, body });
  if (!res.ok) {
    const json = await res.json().catch(() => ({})) as { message?: string; error?: { message?: string } };
    const message = json.message ?? json.error?.message ?? `Music generation failed (${res.status}).`;
    if (res.status === 402 || res.status === 403) {
      const saved = await supabaseAdmin.from("ai_processing_blocks").upsert({ model, status: res.status, message });
      if (saved.error) throw new Error(`${message} Access pause could not be saved; contact the administrator.`);
    }
    throw new Error(message);
  }
  if (!res.headers.get("content-type")?.includes("audio/")) throw new Error("The music model returned no playable audio.");
  const bytes = new Uint8Array(await res.arrayBuffer());
  if (!bytes.length) throw new Error("The music model returned an empty recording.");
  let binary = "";
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return `data:audio/mpeg;base64,${btoa(binary)}`;
}

export async function runMusicGeneration(client: SupabaseClient<Database>, userId: string, d: MusicDraft) {
  const request = musicCreditRequest(d);
  await assertOmniWaveAccess(client, userId, request.operation, d.preview);
  // Single-use owner/hash check happens before the first provider call.
  await releaseCredit(d.approvalId, userId, request);
  const approvalId = d.approvalId;
  if (!approvalId) throw new Error("Confirm & Authorize Stream before music generation.");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const job = await supabaseAdmin.from("music_generation_jobs").insert({ user_id: userId, approval_id: approvalId }).select("id").single();
  const tracks: { projectId: string; url?: string; kind: string }[] = [];
  try {
    if (job.error) throw new Error("Music generation could not be claimed.");
    const count = d.package === "pair" ? 2 : 1;
    for (let i = 1; i <= count; i++) {
      const url = await synthesizeMusic(d, i);
      const saved = await persistOutput(client, userId, "music", `${d.title || "Untitled track"}${count === 2 ? ` · ${i === 1 ? "A" : "B"}` : ""}${d.preview ? " · Masters preview" : ""}`, { kind: "audio", url });
      tracks.push(saved);
      const progress = await supabaseAdmin.from("music_generation_jobs").update({ completed_count: tracks.length }).eq("id", job.data.id);
      if (progress.error) throw new Error("Track saved, but progress could not be recorded.");
    }
    const done = await supabaseAdmin.from("music_generation_jobs").update({ status: "completed" }).eq("id", job.data.id);
    if (done.error) throw new Error("Tracks saved, but completion could not be recorded.");
    return { tracks, error: null };
  } catch (e) {
    const message = e instanceof Error ? e.message : "Music generation failed.";
    const refund = await supabaseAdmin.rpc("refund_unfinished_music", { p_id: approvalId, p_user: userId, p_completed: tracks.length });
    if (!job.error) await supabaseAdmin.from("music_generation_jobs").update({ status: tracks.length ? "partial" : "failed", error: message, completed_count: tracks.length }).eq("id", job.data.id);
    if (refund.error) throw new Error(`${message} Credit settlement needs administrator review.`);
    return { tracks, error: message };
  }
}