CREATE TABLE public.user_connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  provider text NOT NULL,
  credentials jsonb NOT NULL DEFAULT '{}'::jsonb,
  account_label text,
  metrics jsonb NOT NULL DEFAULT '[]'::jsonb,
  last_checked timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, provider)
);
GRANT SELECT (id, user_id, provider, account_label, metrics, last_checked, created_at) ON public.user_connections TO authenticated;
GRANT DELETE ON public.user_connections TO authenticated;
GRANT ALL ON public.user_connections TO service_role;
ALTER TABLE public.user_connections ENABLE ROW LEVEL SECURITY;
CREATE POLICY own_connections_select ON public.user_connections FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY own_connections_delete ON public.user_connections FOR DELETE TO authenticated USING (auth.uid() = user_id);