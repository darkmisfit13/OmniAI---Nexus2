CREATE TABLE public.studio_credit_wallets (user_id uuid PRIMARY KEY, balance bigint NOT NULL DEFAULT 0 CHECK (balance >= 0));
GRANT SELECT ON public.studio_credit_wallets TO authenticated;
GRANT ALL ON public.studio_credit_wallets TO service_role;
ALTER TABLE public.studio_credit_wallets ENABLE ROW LEVEL SECURITY;
CREATE POLICY wallet_owner_read ON public.studio_credit_wallets FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE TABLE public.studio_credit_approvals (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL, operation text NOT NULL CHECK (operation IN ('analysis','image','video','correction')), request_hash text NOT NULL, amount bigint NOT NULL CHECK (amount > 0), units integer NOT NULL CHECK (units > 0), status text NOT NULL DEFAULT 'quoted' CHECK (status IN ('quoted','confirmed','consumed','refunded')), created_at timestamptz NOT NULL DEFAULT now(), expires_at timestamptz NOT NULL DEFAULT now() + interval '10 minutes', confirmed_at timestamptz);
GRANT SELECT ON public.studio_credit_approvals TO authenticated;
GRANT ALL ON public.studio_credit_approvals TO service_role;
ALTER TABLE public.studio_credit_approvals ENABLE ROW LEVEL SECURITY;
CREATE POLICY approval_owner_read ON public.studio_credit_approvals FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE TABLE public.studio_credit_ledger (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL, approval_id uuid NOT NULL REFERENCES public.studio_credit_approvals(id), amount bigint NOT NULL, entry_type text NOT NULL CHECK (entry_type IN ('debit','refund')), created_at timestamptz NOT NULL DEFAULT now(), UNIQUE (approval_id, entry_type));
GRANT SELECT ON public.studio_credit_ledger TO authenticated;
GRANT ALL ON public.studio_credit_ledger TO service_role;
ALTER TABLE public.studio_credit_ledger ENABLE ROW LEVEL SECURITY;
CREATE POLICY ledger_owner_read ON public.studio_credit_ledger FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE INDEX studio_credit_approvals_owner ON public.studio_credit_approvals(user_id, created_at DESC);
CREATE INDEX studio_credit_ledger_owner ON public.studio_credit_ledger(user_id, created_at DESC);
CREATE FUNCTION public.confirm_studio_credit_charge(p_id uuid) RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE q public.studio_credit_approvals; remaining bigint;
BEGIN
 SELECT * INTO q FROM public.studio_credit_approvals WHERE id = p_id AND user_id = auth.uid() FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Approval not found'; END IF;
 IF q.status <> 'quoted' OR q.expires_at <= now() THEN RAISE EXCEPTION 'Approval expired or already used'; END IF;
 IF q.amount <> (CASE q.operation WHEN 'analysis' THEN 5 WHEN 'image' THEN 3 * q.units WHEN 'video' THEN 8 * q.units WHEN 'correction' THEN 25 END) THEN RAISE EXCEPTION 'Invalid rate card'; END IF;
 INSERT INTO public.studio_credit_wallets(user_id) VALUES (auth.uid()) ON CONFLICT DO NOTHING;
 UPDATE public.studio_credit_wallets SET balance = balance - q.amount WHERE user_id = auth.uid() AND balance >= q.amount RETURNING balance INTO remaining;
 IF NOT FOUND THEN RAISE EXCEPTION 'Insufficient OmniAI credits'; END IF;
 UPDATE public.studio_credit_approvals SET status = 'confirmed', confirmed_at = now() WHERE id = p_id;
 INSERT INTO public.studio_credit_ledger(user_id,approval_id,amount,entry_type) VALUES (auth.uid(),p_id,-q.amount,'debit');
 RETURN remaining;
END $$;
REVOKE ALL ON FUNCTION public.confirm_studio_credit_charge(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.confirm_studio_credit_charge(uuid) TO authenticated;
CREATE FUNCTION public.consume_studio_credit_charge(p_id uuid, p_user uuid, p_operation text, p_hash text) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
 UPDATE public.studio_credit_approvals SET status = 'consumed' WHERE id = p_id AND user_id = p_user AND operation = p_operation AND request_hash = p_hash AND status = 'confirmed' AND expires_at > now();
 IF NOT FOUND THEN RAISE EXCEPTION 'Explicit credit confirmation required; approval is missing, expired, used or mismatched'; END IF;
END $$;
REVOKE ALL ON FUNCTION public.consume_studio_credit_charge(uuid,uuid,text,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.consume_studio_credit_charge(uuid,uuid,text,text) TO service_role;
CREATE FUNCTION public.refund_studio_credit_charge(p_id uuid,p_user uuid) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE q public.studio_credit_approvals;
BEGIN
 SELECT * INTO q FROM public.studio_credit_approvals WHERE id=p_id AND user_id=p_user FOR UPDATE;
 IF NOT FOUND OR q.status NOT IN ('confirmed','consumed') THEN RETURN; END IF;
 UPDATE public.studio_credit_wallets SET balance=balance+q.amount WHERE user_id=p_user;
 UPDATE public.studio_credit_approvals SET status='refunded' WHERE id=p_id;
 INSERT INTO public.studio_credit_ledger(user_id,approval_id,amount,entry_type) VALUES(p_user,p_id,q.amount,'refund') ON CONFLICT DO NOTHING;
END $$;
REVOKE ALL ON FUNCTION public.refund_studio_credit_charge(uuid,uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.refund_studio_credit_charge(uuid,uuid) TO service_role;