ALTER TABLE public.studio_credit_approvals DROP CONSTRAINT studio_credit_approvals_operation_check;
ALTER TABLE public.studio_credit_approvals ADD CONSTRAINT studio_credit_approvals_operation_check CHECK (operation IN ('analysis','image','video','correction','music-teaser','music-song','music-pair'));
CREATE OR REPLACE FUNCTION public.confirm_studio_credit_charge(p_id uuid) RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE q public.studio_credit_approvals; remaining bigint; expected bigint;
BEGIN
 SELECT * INTO q FROM public.studio_credit_approvals WHERE id=p_id AND user_id=auth.uid() FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Approval not found'; END IF;
 IF q.status <> 'quoted' OR q.expires_at <= now() THEN RAISE EXCEPTION 'Approval expired or already used'; END IF;
 expected := CASE q.operation WHEN 'analysis' THEN 5 WHEN 'image' THEN 3*q.units WHEN 'video' THEN 8*q.units WHEN 'correction' THEN 25 WHEN 'music-teaser' THEN 12 WHEN 'music-song' THEN 24 WHEN 'music-pair' THEN 48 END;
 IF expected IS NULL OR q.amount <> expected OR (q.operation LIKE 'music-%' AND q.units <> CASE WHEN q.operation='music-pair' THEN 2 ELSE 1 END) THEN RAISE EXCEPTION 'Invalid rate card'; END IF;
 INSERT INTO public.studio_credit_wallets(user_id) VALUES(auth.uid()) ON CONFLICT DO NOTHING;
 UPDATE public.studio_credit_wallets SET balance=balance-q.amount WHERE user_id=auth.uid() AND balance>=q.amount RETURNING balance INTO remaining;
 IF NOT FOUND THEN RAISE EXCEPTION 'Insufficient OmniAI credits'; END IF;
 UPDATE public.studio_credit_approvals SET status='confirmed',confirmed_at=now() WHERE id=p_id;
 INSERT INTO public.studio_credit_ledger(user_id,approval_id,amount,entry_type) VALUES(auth.uid(),p_id,-q.amount,'debit');
 RETURN remaining;
END $$;
CREATE TABLE public.workspace_settings (id text PRIMARY KEY DEFAULT 'global' CHECK(id='global'), orb_enabled boolean NOT NULL DEFAULT true);
GRANT SELECT ON public.workspace_settings TO anon, authenticated;
GRANT ALL ON public.workspace_settings TO service_role;
ALTER TABLE public.workspace_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY workspace_setting_public_read ON public.workspace_settings FOR SELECT TO anon,authenticated USING(true);
CREATE TABLE public.music_generation_jobs (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL, approval_id uuid NOT NULL UNIQUE REFERENCES public.studio_credit_approvals(id), status text NOT NULL DEFAULT 'processing' CHECK(status IN('processing','completed','failed','partial')), completed_count integer NOT NULL DEFAULT 0, error text, created_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT ON public.music_generation_jobs TO authenticated;
GRANT ALL ON public.music_generation_jobs TO service_role;
ALTER TABLE public.music_generation_jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY music_job_owner_read ON public.music_generation_jobs FOR SELECT TO authenticated USING(user_id=auth.uid());
CREATE TABLE public.ai_processing_blocks (model text PRIMARY KEY, status integer NOT NULL, message text NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.ai_processing_blocks TO service_role;
ALTER TABLE public.ai_processing_blocks ENABLE ROW LEVEL SECURITY;
CREATE FUNCTION public.refund_unfinished_music(p_id uuid,p_user uuid,p_completed integer) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE q public.studio_credit_approvals; refund bigint;
BEGIN
 SELECT * INTO q FROM public.studio_credit_approvals WHERE id=p_id AND user_id=p_user FOR UPDATE;
 IF NOT FOUND OR q.status <> 'consumed' OR q.operation NOT IN ('music-teaser','music-song','music-pair') THEN RAISE EXCEPTION 'Invalid music settlement'; END IF;
 IF p_completed < 0 OR p_completed > q.units THEN RAISE EXCEPTION 'Invalid completion count'; END IF;
 refund := q.amount - p_completed * CASE WHEN q.operation='music-teaser' THEN 12 ELSE 24 END;
 IF refund <= 0 THEN RETURN; END IF;
 UPDATE public.studio_credit_wallets SET balance=balance+refund WHERE user_id=p_user;
 UPDATE public.studio_credit_approvals SET status='refunded' WHERE id=p_id;
 INSERT INTO public.studio_credit_ledger(user_id,approval_id,amount,entry_type) VALUES(p_user,p_id,refund,'refund') ON CONFLICT DO NOTHING;
END $$;
REVOKE ALL ON FUNCTION public.refund_unfinished_music(uuid,uuid,integer) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.refund_unfinished_music(uuid,uuid,integer) TO service_role;