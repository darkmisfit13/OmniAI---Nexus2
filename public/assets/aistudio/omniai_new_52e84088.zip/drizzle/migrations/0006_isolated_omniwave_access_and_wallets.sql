CREATE TABLE public.omniwave_subscriptions (user_id uuid PRIMARY KEY, plan text NOT NULL CHECK(plan IN ('creators','masters')), status text NOT NULL DEFAULT 'inactive' CHECK(status IN ('active','inactive','cancelled')), period_start timestamptz NOT NULL, period_end timestamptz NOT NULL, payment_reference text UNIQUE, CHECK(period_end > period_start));
GRANT SELECT ON public.omniwave_subscriptions TO authenticated;
GRANT ALL ON public.omniwave_subscriptions TO service_role;
ALTER TABLE public.omniwave_subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY omniwave_subscription_owner_read ON public.omniwave_subscriptions FOR SELECT TO authenticated USING(user_id=auth.uid());
CREATE TABLE public.omniwave_credit_wallets (user_id uuid PRIMARY KEY, balance bigint NOT NULL DEFAULT 0 CHECK(balance>=0));
GRANT SELECT ON public.omniwave_credit_wallets TO authenticated;
GRANT ALL ON public.omniwave_credit_wallets TO service_role;
ALTER TABLE public.omniwave_credit_wallets ENABLE ROW LEVEL SECURITY;
CREATE POLICY omniwave_wallet_owner_read ON public.omniwave_credit_wallets FOR SELECT TO authenticated USING(user_id=auth.uid());
ALTER TABLE public.studio_credit_approvals ADD COLUMN wallet_scope text NOT NULL DEFAULT 'omniai' CHECK(wallet_scope IN ('omniai','omniwave'));
ALTER TABLE public.studio_credit_approvals ADD COLUMN music_preview boolean NOT NULL DEFAULT false;
CREATE FUNCTION public.has_omniwave_pro(p_user uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$ SELECT EXISTS(SELECT 1 FROM public.omniwave_subscriptions WHERE user_id=p_user AND status='active' AND period_start<=now() AND period_end>now()) $$;
REVOKE ALL ON FUNCTION public.has_omniwave_pro(uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.has_omniwave_pro(uuid) TO authenticated,service_role;
CREATE OR REPLACE FUNCTION public.confirm_studio_credit_charge(p_id uuid) RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE q public.studio_credit_approvals; remaining bigint; expected bigint;
BEGIN
 SELECT * INTO q FROM public.studio_credit_approvals WHERE id=p_id AND user_id=auth.uid() FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Approval not found'; END IF;
 IF q.status<>'quoted' OR q.expires_at<=now() THEN RAISE EXCEPTION 'Approval expired or already used'; END IF;
 expected:=CASE q.operation WHEN 'analysis' THEN 5 WHEN 'image' THEN 3*q.units WHEN 'video' THEN 8*q.units WHEN 'correction' THEN 25 WHEN 'music-teaser' THEN 12 WHEN 'music-song' THEN 24 WHEN 'music-pair' THEN 48 END;
 IF expected IS NULL OR q.amount<>expected OR (q.operation LIKE 'music-%' AND q.units<>CASE WHEN q.operation='music-pair' THEN 2 ELSE 1 END) THEN RAISE EXCEPTION 'Invalid rate card'; END IF;
 IF q.wallet_scope='omniwave' THEN
  IF q.operation NOT IN ('music-teaser','music-song','music-pair') THEN RAISE EXCEPTION 'Music credits cannot fund other studios'; END IF;
  IF q.music_preview AND q.operation<>'music-song' THEN RAISE EXCEPTION 'Invalid Masters preview'; END IF;
  IF q.operation IN ('music-song','music-pair') AND NOT q.music_preview AND NOT public.has_omniwave_pro(auth.uid()) THEN RAISE EXCEPTION 'Active OmniWave Creators or OmniWave Masters required'; END IF;
  INSERT INTO public.omniwave_credit_wallets(user_id) VALUES(auth.uid()) ON CONFLICT DO NOTHING;
  UPDATE public.omniwave_credit_wallets SET balance=balance-q.amount WHERE user_id=auth.uid() AND balance>=q.amount RETURNING balance INTO remaining;
 ELSE
  INSERT INTO public.studio_credit_wallets(user_id) VALUES(auth.uid()) ON CONFLICT DO NOTHING;
  UPDATE public.studio_credit_wallets SET balance=balance-q.amount WHERE user_id=auth.uid() AND balance>=q.amount RETURNING balance INTO remaining;
 END IF;
 IF NOT FOUND THEN RAISE EXCEPTION 'Insufficient credits in the selected wallet'; END IF;
 UPDATE public.studio_credit_approvals SET status='confirmed',confirmed_at=now() WHERE id=p_id;
 INSERT INTO public.studio_credit_ledger(user_id,approval_id,amount,entry_type) VALUES(auth.uid(),p_id,-q.amount,'debit');
 RETURN remaining;
END $$;
CREATE OR REPLACE FUNCTION public.refund_studio_credit_charge(p_id uuid,p_user uuid) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE q public.studio_credit_approvals;
BEGIN
 SELECT * INTO q FROM public.studio_credit_approvals WHERE id=p_id AND user_id=p_user FOR UPDATE;
 IF NOT FOUND OR q.status NOT IN ('confirmed','consumed') THEN RETURN; END IF;
 IF q.wallet_scope='omniwave' THEN UPDATE public.omniwave_credit_wallets SET balance=balance+q.amount WHERE user_id=p_user;
 ELSE UPDATE public.studio_credit_wallets SET balance=balance+q.amount WHERE user_id=p_user; END IF;
 UPDATE public.studio_credit_approvals SET status='refunded' WHERE id=p_id;
 INSERT INTO public.studio_credit_ledger(user_id,approval_id,amount,entry_type) VALUES(p_user,p_id,q.amount,'refund') ON CONFLICT DO NOTHING;
END $$;
CREATE OR REPLACE FUNCTION public.refund_unfinished_music(p_id uuid,p_user uuid,p_completed integer) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE q public.studio_credit_approvals; refund bigint;
BEGIN
 SELECT * INTO q FROM public.studio_credit_approvals WHERE id=p_id AND user_id=p_user FOR UPDATE;
 IF NOT FOUND OR q.status<>'consumed' OR q.operation NOT IN ('music-teaser','music-song','music-pair') THEN RAISE EXCEPTION 'Invalid music settlement'; END IF;
 IF p_completed<0 OR p_completed>q.units THEN RAISE EXCEPTION 'Invalid completion count'; END IF;
 refund:=q.amount-p_completed*CASE WHEN q.operation='music-teaser' THEN 12 ELSE 24 END;
 IF refund<=0 THEN RETURN; END IF;
 IF q.wallet_scope='omniwave' THEN UPDATE public.omniwave_credit_wallets SET balance=balance+refund WHERE user_id=p_user;
 ELSE UPDATE public.studio_credit_wallets SET balance=balance+refund WHERE user_id=p_user; END IF;
 UPDATE public.studio_credit_approvals SET status='refunded' WHERE id=p_id;
 INSERT INTO public.studio_credit_ledger(user_id,approval_id,amount,entry_type) VALUES(p_user,p_id,refund,'refund') ON CONFLICT DO NOTHING;
END $$;
COMMENT ON TABLE public.omniwave_subscriptions IS 'Verified music subscription periods only. Owner read-only; payment integration must activate and allocate credits idempotently after verified settlement. No checkout is currently connected.';
COMMENT ON TABLE public.omniwave_credit_wallets IS 'Music-only credits, isolated from OmniAI balances. No automatic seed or funding on page load.';