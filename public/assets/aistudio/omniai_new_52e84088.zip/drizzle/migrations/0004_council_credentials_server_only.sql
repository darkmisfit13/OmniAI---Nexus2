REVOKE ALL ON TABLE public.council_members FROM anon,authenticated;
GRANT SELECT(id,label,provider,model,enabled,created_by,last_checked,created_at) ON public.council_members TO authenticated;
GRANT ALL ON public.council_members TO service_role;