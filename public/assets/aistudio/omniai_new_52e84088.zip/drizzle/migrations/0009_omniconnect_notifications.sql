CREATE TABLE public.notification_settings (
 user_id uuid PRIMARY KEY, webhook_url text NOT NULL DEFAULT '', generation_enabled boolean NOT NULL DEFAULT false, security_enabled boolean NOT NULL DEFAULT false, compilation_enabled boolean NOT NULL DEFAULT false, verified_at timestamptz, updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notification_settings TO authenticated;
GRANT ALL ON public.notification_settings TO service_role;
ALTER TABLE public.notification_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owner notification settings" ON public.notification_settings FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE TABLE public.notification_deliveries (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL, event_key text NOT NULL, payload jsonb NOT NULL, status text NOT NULL DEFAULT 'pending', http_status integer, created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(user_id, event_key)
);
GRANT SELECT ON public.notification_deliveries TO authenticated;
GRANT ALL ON public.notification_deliveries TO service_role;
ALTER TABLE public.notification_deliveries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owner delivery logs" ON public.notification_deliveries FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE INDEX notification_deliveries_owner_time ON public.notification_deliveries(user_id, created_at DESC);