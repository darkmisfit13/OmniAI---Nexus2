<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Use Cloud Auth profiles and owner-scoped RLS for saved studio work and conversations; no browser-only persistence for private work.
- OmniConnect notification settings and delivery logs are owner-scoped; server dispatch uses trusted webhook host allowlists, no redirects, bounded timeouts and unique event keys so webhook URLs cannot target private networks or repeat on polling. Client auth/compiler events are telemetry, not authoritative security audits.
- Chat pages derive their active thread from /chat/$threadId and stream through an authenticated AI SDK endpoint; this prevents thread mixing and keeps provider credentials server-side.
- Cross-thread memory stores user-provided context separately from assistant responses and supports forgetting; this avoids treating generated claims as personal facts.
- Store generated media in private Cloud storage and sign access URLs on read; temporary generation URLs are not durable saved work.
- HoloOrb is the shared R3F shader identity, mounted client-only with a local rendering boundary; graphics failure must never replace the application route.
- Shared orbs obey the public admin-owned motion setting and render continuously while enabled; local play/pause controls appear only for reduced-motion accessibility, which pauses by default.
- Council configuration is admin-only via protected user_roles checks, fixed provider endpoints and AES-GCM encrypted credentials; authenticated chat loads enabled members server-side and synthesizes successful opinions without exposing keys.
- WorkspaceStateProvider drives orb phases from chat input acceptance, request dispatch, SDK streaming and completion events; never simulate progress phases with timers.
- Unconfirmed accounts recover through the public auth page using Cloud Auth signup resend; keep email confirmation enabled rather than bypassing account verification.
- Editor and builder projects save through the browser client into studio_projects (kind edit/build) under owner RLS, with media in the private studio-assets bucket under the user's folder; builder output is one self-contained HTML document rendered in a sandboxed iframe whose console is bridged to the terminal.
- Studios expose AI-operable controls via useStudioActions (src/lib/studio-actions.ts); the AICompanion lists registered actions in its prompt and runs the model's JSON action calls client-side, so the AI uses the same code paths as the buttons.
- WorkspaceLayout owns the shared header, directory and docked Director using fluid grid tracks; studio internals respond to their container width rather than the viewport so panel toggles do not squeeze fixed tool columns into the canvas.
- All studios use the protected global credit wallet with monthly allocations spent before booster credits; owner-only atomic CR confirmation and single-use release prevent client-authored charges. Verified grants are idempotent and never provision on page load.
- All image/video/film/music provider boundaries enforce credit release; studio action calls use the same confirmation dialog. Chat Director routes paid requests to studios rather than bypassing their credit gate. Local editor exports and final browser merges do not incur AI generation charges.
- OmniWave uses owner-scoped claimed music jobs and private stored recordings; pair failures settle only unfinished work, so replay and downloads never synthesize again.
- General and music catalogs stay distinct but their allocations share the global wallet; protected general or music subscription periods determine Lyria Pro access at quote, confirmation and dispatch. Unconnected purchases remain disabled.
- OmniBeat provider work claims server-owned escrow steps before dispatch and settles only saved/completed outputs; asynchronous video jobs retain pending credit holds until reconciled, preventing stop or polling failures from refunding in-flight work. Local merge completion releases unused escrow without AI charges.
- Personalized previews use separately hash-bound explicit approvals; preview synthesis never starts automatically, and unavailable subscription entitlements stay disabled rather than fabricated.
- Music films persist staged production state and asset paths in owner-scoped studio_projects; pauses stop at request boundaries, generated clips are stored before expiry, and editor handoff uses a saved project ID rather than transient URLs.
- Final-film browser merges preload and validate all media, pause recording and the song at scene/buffering boundaries, and finalize WebM duration; this prevents black loading gaps and soundtrack drift without AI charges.
